"""Upstream model providers.

``Provider`` is the structural interface the inference service depends on. Two
implementations ship here: ``NullProvider`` (fail-closed when nothing is
configured) and ``OpenAICompatibleProvider`` (Ollama / vLLM / TGI over HTTP with
bounded timeouts and retries).
"""

from __future__ import annotations

import json
import logging
import re
import shutil
from collections.abc import AsyncIterator
from typing import Protocol

import httpx

from app.errors import UpstreamError, UpstreamNotConfiguredError, UpstreamRejectedError
from app.schemas import (
    ChatChoice,
    ChatChoiceMessage,
    ChatCompletionRequest,
    ChatCompletionResponse,
    EmbeddingItem,
    EmbeddingRequest,
    EmbeddingResponse,
    Usage,
)

_logger = logging.getLogger("dmt_ai.providers")

_USAGE_KEYS = ("prompt_tokens", "completion_tokens", "total_tokens")


def _parse_upstream_sse(line: str) -> str | None:
    """Extract the text delta from one upstream SSE `data:` line (OpenAI chunks)."""
    if not line.startswith("data:"):
        return None
    payload = line[5:].strip()
    if payload == "[DONE]":
        return None
    try:
        chunk = json.loads(payload)
    except ValueError:
        return None
    choices = chunk.get("choices")
    if not isinstance(choices, list) or not choices:
        return None
    delta = choices[0].get("delta", {})
    content = delta.get("content")
    return content if isinstance(content, str) and content else None


def _parse_upstream_chunk(line: str) -> tuple[str | None, dict[str, int] | None]:
    """Extract (text delta, usage) from one upstream SSE ``data:`` line.

    ``usage`` is only present on the final chunk when ``stream_options.include_usage``
    was requested; it lets a streamed call still report tokens for the cost audit.
    """
    if not line.startswith("data:"):
        return None, None
    payload = line[5:].strip()
    if payload == "[DONE]":
        return None, None
    try:
        chunk = json.loads(payload)
    except ValueError:
        return None, None
    raw_usage = chunk.get("usage")
    usage = (
        {k: int(v) for k, v in raw_usage.items() if isinstance(v, int)}
        if isinstance(raw_usage, dict)
        else None
    )
    choices = chunk.get("choices")
    if not isinstance(choices, list) or not choices:
        return None, usage
    content = choices[0].get("delta", {}).get("content")
    return (content if isinstance(content, str) and content else None), usage


# Reasoning models (e.g. qwen3) emit a <think>...</think> trace before the answer;
# strip it so callers (and the council) receive only the final response. Parity
# with dmt-backend's strip_reasoning.
_THINK_RE = re.compile(r"<think>.*?</think>\s*", re.DOTALL | re.IGNORECASE)
_UNCLOSED_THINK_RE = re.compile(r"<think>.*\Z", re.DOTALL | re.IGNORECASE)


def _strip_reasoning(text: str) -> str:
    """Remove closed or truncated <think> blocks from a model's answer."""
    return _UNCLOSED_THINK_RE.sub("", _THINK_RE.sub("", text)).strip()


class _ThinkStreamFilter:
    """Stateful filter that drops <think>…</think> reasoning from a token stream.

    Reasoning models emit the think trace incrementally, so a plain regex (which
    needs the whole string) cannot be applied per-delta. This tracks whether the
    stream is inside a <think> block and suppresses those deltas, buffering a
    partial tag that spans chunks. Only the final answer reaches the caller.
    """

    _OPEN = "<think>"
    _CLOSE = "</think>"

    def __init__(self) -> None:
        self._in_think = False
        self._buf = ""

    def feed(self, delta: str) -> str:
        """Return the visible part of a delta (empty while inside a think block)."""
        self._buf += delta
        out: list[str] = []
        while self._buf:
            if self._in_think:
                end = self._buf.find(self._CLOSE)
                if end == -1:
                    self._buf = self._buf[-len(self._CLOSE) :]  # keep a partial close tag
                    break
                self._buf = self._buf[end + len(self._CLOSE) :]
                self._in_think = False
                continue
            start = self._buf.lower().find(self._OPEN)
            if start == -1:
                # No full open tag; keep a possible partial tag tail buffered.
                tail = self._buf.lower()
                keep = max(
                    (
                        len(self._OPEN[:i])
                        for i in range(1, len(self._OPEN))
                        if tail.endswith(self._OPEN[:i])
                    ),
                    default=0,
                )
                out.append(self._buf[: len(self._buf) - keep])
                self._buf = self._buf[len(self._buf) - keep :]
                break
            out.append(self._buf[:start])
            self._buf = self._buf[start + len(self._OPEN) :]
            self._in_think = True
        return "".join(out)

    def flush(self) -> str:
        """Drain any buffered visible text at end of stream."""
        if self._in_think:
            self._buf = ""
            return ""
        rest = self._buf
        self._buf = ""
        return rest


class Provider(Protocol):
    """The upstream inference interface used by the gateway."""

    async def chat(self, request: ChatCompletionRequest, model: str) -> ChatCompletionResponse: ...

    def chat_stream(self, request: ChatCompletionRequest, model: str) -> AsyncIterator[str]:
        """Stream the answer token-by-token (the interactive path). Providers that
        cannot stream raise; callers fall back to `chat`."""
        ...

    async def embeddings(self, request: EmbeddingRequest, model: str) -> EmbeddingResponse: ...


class NullProvider:
    """Fail-closed provider used when no upstream is configured."""

    async def chat(self, request: ChatCompletionRequest, model: str) -> ChatCompletionResponse:
        del request, model
        raise UpstreamNotConfiguredError("no model upstream configured")

    async def embeddings(self, request: EmbeddingRequest, model: str) -> EmbeddingResponse:
        del request, model
        raise UpstreamNotConfiguredError("no model upstream configured")


def _usage_from(data: dict[str, object]) -> Usage:
    raw = data.get("usage")
    if not isinstance(raw, dict):
        return Usage()
    return Usage(**{key: int(raw.get(key, 0) or 0) for key in _USAGE_KEYS})


class OpenAICompatibleProvider:
    """Call an OpenAI-compatible upstream (Ollama / vLLM / TGI)."""

    def __init__(
        self,
        base_url: str,
        api_key: str = "",
        timeout_s: float = 30.0,
        max_retries: int = 2,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        self._timeout = httpx.Timeout(timeout_s)
        self._max_retries = max(0, max_retries)
        self._transport = transport

    async def _post(self, path: str, payload: dict[str, object]) -> dict[str, object]:
        url = f"{self._base_url}{path}"
        last_exc: Exception | None = None
        async with httpx.AsyncClient(
            timeout=self._timeout, headers=self._headers, transport=self._transport
        ) as client:
            for _ in range(self._max_retries + 1):
                try:
                    response = await client.post(url, json=payload)
                    response.raise_for_status()
                except httpx.HTTPStatusError as exc:
                    if exc.response.status_code < 500:
                        raise UpstreamRejectedError(
                            f"upstream rejected the request ({exc.response.status_code})"
                        ) from exc
                    last_exc = exc
                    continue
                except httpx.HTTPError as exc:
                    last_exc = exc
                    continue
                try:
                    return response.json()
                except ValueError as exc:
                    raise UpstreamError("upstream returned invalid JSON") from exc
        raise UpstreamError("upstream request failed") from last_exc

    async def chat(self, request: ChatCompletionRequest, model: str) -> ChatCompletionResponse:
        payload = request.model_dump(exclude={"require_grounding"}, exclude_none=True)
        payload["model"] = model
        return _chat_choices(await self._post("/v1/chat/completions", payload), model)

    async def chat_stream(
        self, request: ChatCompletionRequest, model: str, usage_out: dict[str, int] | None = None
    ) -> AsyncIterator[str]:
        """Stream the answer from the upstream as text deltas (interactive path)."""
        payload = request.model_dump(exclude={"require_grounding"}, exclude_none=True)
        payload["model"] = model
        payload["stream"] = True
        if usage_out is not None:
            payload["stream_options"] = {"include_usage": True}
        url = f"{self._base_url}/v1/chat/completions"
        think = _ThinkStreamFilter()
        async with (
            httpx.AsyncClient(
                timeout=self._timeout, headers=self._headers, transport=self._transport
            ) as client,
            client.stream("POST", url, json=payload) as response,
        ):
            if response.status_code >= 400:
                raise UpstreamRejectedError(
                    f"upstream rejected the stream ({response.status_code})"
                )
            async for line in response.aiter_lines():
                delta, usage = _parse_upstream_chunk(line)
                if usage and usage_out is not None:
                    usage_out.update(usage)
                if delta:
                    visible = think.feed(delta)
                    if visible:
                        yield visible
        tail = think.flush()
        if tail:
            yield tail

    async def embeddings(self, request: EmbeddingRequest, model: str) -> EmbeddingResponse:
        payload = request.model_dump(exclude_none=True)
        payload["model"] = model
        data = await self._post("/v1/embeddings", payload)
        return EmbeddingResponse(model=model, data=_embedding_items(data), usage=_usage_from(data))


def _chat_choices(data: dict[str, object], model: str) -> ChatCompletionResponse:
    """Parse an OpenAI-style chat response into our schema (shared by providers)."""
    raw_choices = data.get("choices")
    choices = [
        ChatChoice(
            index=index,
            message=ChatChoiceMessage(
                role=str(choice.get("message", {}).get("role", "assistant")),
                content=_strip_reasoning(str(choice.get("message", {}).get("content", ""))),
            ),
            finish_reason=str(choice.get("finish_reason") or "stop"),
        )
        for index, choice in enumerate(raw_choices if isinstance(raw_choices, list) else [])
    ]
    return ChatCompletionResponse(
        id=str(data.get("id", "chatcmpl-dmt")),
        model=model,
        choices=choices,
        usage=_usage_from(data),
    )


def _embedding_items(data: dict[str, object]) -> list[EmbeddingItem]:
    """Parse an OpenAI-style embeddings response into our schema."""
    raw_items = data.get("data")
    return [
        EmbeddingItem(
            index=int(item.get("index", index)),
            embedding=[float(value) for value in item.get("embedding", [])],
        )
        for index, item in enumerate(raw_items if isinstance(raw_items, list) else [])
    ]


def _azure_chat_payload(request: ChatCompletionRequest) -> dict[str, object]:
    """Build the Azure chat body, compatible across model families.

    Newer Azure chat models (gpt-5.x, o-series) require ``max_completion_tokens``
    and reject ``max_tokens`` and non-default ``temperature``/``top_p``; the
    reasoning ``dmt-brain`` accepts the modern contract too. Emit that shape so any
    deployment — the fast expert tier or the Director — works from one code path.
    """
    payload = request.model_dump(
        exclude={"require_grounding", "model", "temperature", "top_p"}, exclude_none=True
    )
    if "max_tokens" in payload:
        payload["max_completion_tokens"] = payload.pop("max_tokens")
    # Grounding context is injected as role="tool" messages, but modern Azure models
    # (gpt-5.x / o-series) reject a 'tool' message that is not a reply to a preceding
    # tool_call. These passages were already screened by the guardrails, so forward
    # them as user-role context (universally accepted) instead of dropping evidence.
    messages = payload.get("messages")
    if isinstance(messages, list):
        for message in messages:
            if isinstance(message, dict) and message.get("role") == "tool":
                message["role"] = "user"
    return payload


class AzureOpenAIProvider:
    """Sovereign Azure OpenAI (native REST): /openai/deployments/{dep}/...

    Azure OpenAI is not OpenAI-compatible at the path level. Authentication is
    keyless by default (an Entra ID bearer token passed in by the deployment) with
    an ``api-key`` as the explicit fallback. The logical model maps to the
    deployment name (e.g. ``dmt-brain``). Exactly one of ``bearer_token`` /
    ``api_key`` must be set.
    """

    def __init__(
        self,
        endpoint: str,
        *,
        api_key: str = "",
        bearer_token: str = "",
        api_version: str = "2024-10-21",
        timeout_s: float = 30.0,
        max_retries: int = 2,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        if not endpoint.startswith("https://"):
            raise ValueError("AZURE endpoint must be an https URL")
        if bool(api_key) == bool(bearer_token):
            raise ValueError("exactly one of api_key or bearer_token is required")
        self._endpoint = endpoint.rstrip("/")
        self._api_version = api_version
        if bearer_token:
            self._headers = {
                "Authorization": f"Bearer {bearer_token}",
                "Content-Type": "application/json",
            }
        else:
            self._headers = {"api-key": api_key, "Content-Type": "application/json"}
        self._uses_bearer = bool(bearer_token)
        self._timeout = httpx.Timeout(timeout_s)
        self._max_retries = max(0, max_retries)
        self._transport = transport

    def _refresh_bearer_token(self) -> bool:
        """Refresh the Entra ID bearer token via the local Azure CLI (sovereign, keyless).

        A managed identity / Azure CLI session on the host can mint a fresh token for
        the Cognitive Services scope; this keeps the gateway from wedging on an expired
        token. Returns True when a new token was applied.
        """
        if not self._uses_bearer:
            return False
        # 1) Managed identity on the host (the sovereign path on Azure VMs).
        token = self._mint_via_azure_identity()
        if token:
            self._set_bearer(token)
            _logger.info("azure_bearer_token_refreshed", extra={"via": "managed_identity"})
            return True
        # 2) Local Azure CLI (the developer path).
        az = shutil.which("az")
        if not az:
            return False
        try:
            import subprocess

            result = subprocess.run(  # noqa: S603 - fixed, trusted `az` command
                [
                    az,
                    "account",
                    "get-access-token",
                    "--scope",
                    "https://cognitiveservices.azure.com/.default",
                    "--query",
                    "accessToken",
                    "-o",
                    "tsv",
                ],
                capture_output=True,
                text=True,
                timeout=15,
                check=False,
            )
            token = result.stdout.strip()
        except Exception:  # noqa: BLE001 - a refresh failure must not break the request
            return False
        if result.returncode != 0 or not token:
            return False
        self._set_bearer(token)
        _logger.info("azure_bearer_token_refreshed", extra={"via": "azure_cli"})
        return True

    def _mint_via_azure_identity(self) -> str:
        """Mint a Cognitive Services token via the host's managed identity (keyless)."""
        try:
            from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        except ImportError:
            return ""
        try:
            provider = get_bearer_token_provider(
                DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default"
            )
            return provider() or ""
        except Exception:  # noqa: BLE001 - identity unavailable -> try the CLI path
            return ""

    def _set_bearer(self, token: str) -> None:
        """Apply a bearer token to the request headers."""
        self._headers["Authorization"] = f"Bearer {token}"

    def warm(self) -> bool:
        """Pre-mint the Entra bearer at startup so the first turn skips the 401 refresh."""
        return self._refresh_bearer_token()

    async def _post(self, path: str, payload: dict[str, object]) -> dict[str, object]:
        url = f"{self._endpoint}{path}"
        last_exc: Exception | None = None
        async with httpx.AsyncClient(timeout=self._timeout, transport=self._transport) as client:
            for _ in range(self._max_retries + 1):
                try:
                    # Snapshot the headers per attempt so a token refresh takes effect
                    # on the retry (the client's default headers are fixed at creation).
                    response = await client.post(url, json=payload, headers=dict(self._headers))
                    response.raise_for_status()
                except httpx.HTTPStatusError as exc:
                    # A 401 on a bearer-authed deployment means the Entra token expired;
                    # refresh it once and retry (sovereign, keyless path).
                    if exc.response.status_code == 401 and self._refresh_bearer_token():
                        continue
                    if exc.response.status_code < 500:
                        raise UpstreamRejectedError(
                            f"azure openai rejected the request ({exc.response.status_code})"
                        ) from exc
                    last_exc = exc
                    continue
                except httpx.HTTPError as exc:
                    last_exc = exc
                    continue
                try:
                    return response.json()
                except ValueError as exc:
                    raise UpstreamError("azure openai returned invalid JSON") from exc
        raise UpstreamError("azure openai request failed") from last_exc

    async def chat(self, request: ChatCompletionRequest, model: str) -> ChatCompletionResponse:
        payload = _azure_chat_payload(request)
        # Azure keys the deployment in the URL, not the body.
        path = f"/openai/deployments/{model}/chat/completions?api-version={self._api_version}"
        return _chat_choices(await self._post(path, payload), model)

    async def chat_stream(
        self, request: ChatCompletionRequest, model: str, usage_out: dict[str, int] | None = None
    ) -> AsyncIterator[str]:
        """Stream the answer from the Azure deployment as text deltas (interactive).

        When ``usage_out`` is given, request a final usage chunk and populate it so a
        streamed call (e.g. the Director synthesis) still contributes to the cost audit.
        """
        payload = _azure_chat_payload(request)
        payload["stream"] = True
        if usage_out is not None:
            payload["stream_options"] = {"include_usage": True}
        url = (
            f"{self._endpoint}/openai/deployments/{model}/chat/completions"
            f"?api-version={self._api_version}"
        )
        for _attempt in range(2):  # one token-refresh retry on an expired token
            think = _ThinkStreamFilter()
            async with (
                httpx.AsyncClient(
                    timeout=self._timeout, headers=dict(self._headers), transport=self._transport
                ) as client,
                client.stream("POST", url, json=payload) as response,
            ):
                if response.status_code == 401 and self._refresh_bearer_token():
                    continue  # token refreshed — retry the stream once
                if response.status_code >= 400:
                    raise UpstreamRejectedError(
                        f"azure openai rejected the stream ({response.status_code})"
                    )
                async for line in response.aiter_lines():
                    delta, usage = _parse_upstream_chunk(line)
                    if usage and usage_out is not None:
                        usage_out.update(usage)
                    if delta:
                        visible = think.feed(delta)
                        if visible:
                            yield visible
            tail = think.flush()
            if tail:
                yield tail
            return

    async def embeddings(self, request: EmbeddingRequest, model: str) -> EmbeddingResponse:
        payload = request.model_dump(exclude={"model"}, exclude_none=True)
        path = f"/openai/deployments/{model}/embeddings?api-version={self._api_version}"
        data = await self._post(path, payload)
        return EmbeddingResponse(model=model, data=_embedding_items(data), usage=_usage_from(data))
