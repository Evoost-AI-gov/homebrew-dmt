"""DMT AI services — FastAPI gateway application factory.

The gateway exposes an OpenAI-compatible ``/v1`` API in front of the sovereign
model server. It is fail-closed by default: without an upstream configured it
serves a fail-closed provider, and in production it refuses to start without
authentication and an upstream (enforced in :class:`app.settings.Settings`).
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.council.chat_routes import router as chat_router
from app.council.chat_store import ChatStore
from app.council.custom_store import CustomAgentStore
from app.council.external import ExternalCapture
from app.council.graph_routes import router as graph_router
from app.council.graph_service import PersonalGraphService
from app.council.metrics import CouncilMetricsStore
from app.council.pricing_routes import router as pricing_router
from app.council.registry import CouncilRegistry
from app.council.service import CouncilService
from app.council.tools import (
    ArchetypeDemandTool,
    BackendReadTool,
    BriefTool,
    ForesightTool,
    GeopoliticalTool,
    LandScoreTool,
    PricingTool,
    ScenariosTool,
)
from app.council.user_context import UserContextStore
from app.council.user_context_routes import router as user_context_router
from app.errors import AppError, app_error_handler
from app.inference import InferenceService
from app.logging_utils import configure_logging
from app.middleware import RequestContextMiddleware, SecurityHeadersMiddleware
from app.providers import (
    AzureOpenAIProvider,
    NullProvider,
    OpenAICompatibleProvider,
    Provider,
)
from app.rate_limit import FixedWindowRateLimiter
from app.retrieval import RetrievalService, build_embedder, load_index
from app.routes import health_router, v1_router
from app.routing import Router
from app.security import enforce_rate_limit, require_api_key
from app.settings import Settings

_logger = logging.getLogger("dmt_ai.startup")


@asynccontextmanager
async def _lifespan(app: FastAPI):
    """Warm the upstream token on startup; release long-lived resources on shutdown."""
    # Pre-mint the sovereign Entra bearer so the FIRST turn after a deploy/restart does
    # not pay the 401 -> refresh -> retry penalty (a slow cold start for demos). Non-fatal.
    provider = getattr(app.state, "provider", None)
    warm = getattr(provider, "warm", None)
    if warm is not None:
        try:
            await asyncio.to_thread(warm)
        except Exception:  # noqa: BLE001 - a cold-start warm failure must never block startup
            _logger.warning("provider_warm_failed")
    yield
    retrieval_service = getattr(app.state, "retrieval_service", None)
    if retrieval_service is not None:
        await retrieval_service.aclose()


def _build_routes(settings: Settings) -> dict[str, list[str]]:
    """Build the logical->deployment routing table from config (fail-closed names)."""
    chat = settings.chat_model
    embed = settings.embed_model
    # The fast expert tier, with the strong model as an ordered fallback. When no
    # expert deployment is configured, experts reuse the single chat model.
    expert = [settings.expert_chat_model, chat] if settings.expert_chat_model else [chat]
    return {
        "dmt-brain": [chat],
        "general": expert,
        "fast": expert,
        "translate": [chat],
        "embed": [embed],
    }


def _build_provider(settings: Settings) -> Provider:
    """Build the upstream provider, or a fail-closed one if none is configured."""
    if not settings.upstream_base_url:
        return NullProvider()
    if settings.upstream_kind == "azure":
        # Sovereign Azure OpenAI (native REST). Keyless Entra bearer by default;
        # api-key as the explicit fallback. The logical model routes to the
        # deployment name (e.g. dmt-brain).
        return AzureOpenAIProvider(
            endpoint=settings.upstream_base_url,
            api_key=settings.upstream_api_key,
            bearer_token=settings.upstream_bearer_token,
            api_version=settings.azure_api_version,
            timeout_s=settings.request_timeout_s,
            max_retries=settings.max_retries,
        )
    return OpenAICompatibleProvider(
        base_url=settings.upstream_base_url,
        api_key=settings.upstream_api_key,
        timeout_s=settings.request_timeout_s,
        max_retries=settings.max_retries,
    )


def _build_retrieval_service(settings: Settings) -> RetrievalService:
    """Build the retrieval service from configured index + query embedder."""
    embedder = build_embedder(
        base_url=settings.retrieval_embed_url,
        model=settings.retrieval_embed_model,
        query_prefix=settings.retrieval_query_prefix,
        api_key=settings.retrieval_embed_api_key,
        timeout_s=settings.retrieval_timeout_s,
        local=settings.retrieval_embed_local,
    )
    index = load_index(settings.retrieval_embeddings_path, settings.retrieval_chunks_path)
    return RetrievalService(
        embedder,
        index,
        default_top_k=settings.retrieval_top_k,
        default_min_score=settings.retrieval_min_score,
    )


def create_app(
    settings: Settings | None = None,
    provider: Provider | None = None,
    retrieval_service: RetrievalService | None = None,
) -> FastAPI:
    """Create and wire the FastAPI application."""
    settings = settings or Settings()
    configure_logging()
    provider = provider or _build_provider(settings)
    retrieval_service = retrieval_service or _build_retrieval_service(settings)

    docs_enabled = settings.enable_docs and settings.is_development
    app = FastAPI(
        title="DMT AI Services",
        version="0.3.0",
        docs_url="/docs" if docs_enabled else None,
        redoc_url="/redoc" if docs_enabled else None,
        openapi_url="/openapi.json" if docs_enabled else None,
        lifespan=_lifespan,
    )

    app.state.settings = settings
    app.state.provider = provider
    app.state.router = Router(routes=_build_routes(settings))
    app.state.rate_limiter = FixedWindowRateLimiter(settings.rate_limit_per_minute)
    app.state.inference_service = InferenceService(provider, app.state.router)
    app.state.retrieval_service = retrieval_service

    # Council Chat (ADR-0003): compile the governed roster and wire the service.
    # Fail-closed: with no agents dir the registry is empty and /v1/council/* 400s.
    app.state.council_registry = CouncilRegistry.from_directory(settings.council_agents_dir)
    # Custom-agent builder (F4): load the store (when configured) and merge approved
    # custom agents into the effective registry used for routing.
    app.state.council_custom_store = (
        CustomAgentStore(settings.council_custom_store_path)
        if settings.council_custom_store_path
        else None
    )
    effective_registry = (
        app.state.council_registry.with_custom(app.state.council_custom_store.approved_specs())
        if app.state.council_custom_store is not None
        else app.state.council_registry
    )
    app.state.council_service = CouncilService(
        registry=effective_registry,
        inference=app.state.inference_service,
        retrieval=retrieval_service,
        require_grounding=settings.council_require_grounding,
        pricing=PricingTool(),
        brief=BriefTool(),
        demand=ArchetypeDemandTool(),
        land=LandScoreTool(),
        geopolitical=GeopoliticalTool(),
        scenarios=ScenariosTool(),
        foresight=ForesightTool(),
        backend=BackendReadTool(
            settings.backend_base_url,
            settings.backend_token,
            entra_tenant_id=settings.backend_entra_tenant_id,
            client_id=settings.backend_client_id,
            client_secret=settings.backend_client_secret,
            scope=settings.backend_scope,
        ),
        metrics=CouncilMetricsStore(settings.council_metrics_path)
        if settings.council_metrics_path
        else None,
    )
    # The governed pricing tool (shared with the council) — for the conflicts endpoint.
    app.state.pricing_tool = app.state.council_service.pricing
    # External-capture (F5): allow-listed, tagged external fetches. Disabled (fail
    # closed) when no allowlist is configured.
    app.state.council_external_capture = (
        ExternalCapture(settings.external_allowlist_set)
        if settings.external_allowlist_set
        else None
    )
    # Chat persistence (advisory conversation state). Available when configured;
    # mounted below at the app level (not by mutating the shared v1_router).
    app.state.chat_store = ChatStore(settings.chat_store_path) if settings.chat_store_path else None
    # Per-user work context (the Director-as-coworker substrate). Mounted when a
    # store path is configured; scoped per Entra user.
    app.state.user_context_store = (
        UserContextStore(settings.user_context_path) if settings.user_context_path else None
    )
    # Personal Graph (Semantica ContextGraph, per user) — provenance + decisions.
    app.state.graph_service = (
        PersonalGraphService(settings.graph_store_path) if settings.graph_store_path else None
    )

    # RequestContext is added last so it is the outermost layer (assigns the
    # request id before anything else runs and logs after everything completes).
    # CSP is only relaxed for docs paths when docs are actually served.
    docs_paths = ("/docs", "/redoc", "/openapi.json", "/docs/oauth2-redirect")
    csp_exempt = docs_paths if docs_enabled else ()
    app.add_middleware(SecurityHeadersMiddleware, csp_exempt_paths=csp_exempt)
    app.add_middleware(RequestContextMiddleware)

    # CORS for browser front-ends — only when an explicit origin list is set.
    # Off by default (service-to-service); never "*".
    if settings.cors_origin_list:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.cors_origin_list,
            allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            allow_headers=["Authorization", "Content-Type", "X-API-Key", "X-Reviewer"],
        )

    app.add_exception_handler(AppError, app_error_handler)

    app.include_router(health_router)
    app.include_router(v1_router)
    if app.state.chat_store is not None:
        # Chat persistence gets the same auth + rate limiting as the /v1 surface,
        # applied per-app so the shared router is never mutated across instances.
        app.include_router(
            chat_router,
            prefix="/v1",
            dependencies=[Depends(require_api_key), Depends(enforce_rate_limit)],
        )
    if app.state.user_context_store is not None:
        # Per-user context (Director coworker) — same auth + rate limiting.
        app.include_router(
            user_context_router,
            prefix="/v1",
            dependencies=[Depends(require_api_key), Depends(enforce_rate_limit)],
        )
    if app.state.graph_service is not None:
        # Personal Graph (Semantica) — per-user, provenance-tracked, decision store.
        app.include_router(
            graph_router,
            prefix="/v1",
            dependencies=[Depends(require_api_key), Depends(enforce_rate_limit)],
        )
    # Governed pricing (conflict surface) — same auth + rate limiting.
    app.include_router(
        pricing_router,
        prefix="/v1",
        dependencies=[Depends(require_api_key), Depends(enforce_rate_limit)],
    )
    return app


app = create_app()
