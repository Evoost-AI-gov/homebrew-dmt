"""HTTP routers: health probes and the OpenAI-compatible ``/v1`` surface.

The ``/v1`` router requires a valid API key and enforces the rate limit on every
route via router-level dependencies, so no individual handler can forget them.
"""

from __future__ import annotations

import json
from collections.abc import AsyncGenerator

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse

from app.council.routes import router as council_router
from app.errors import AppError, RetrievalNotConfiguredError
from app.inference import InferenceService, build_grounded_request
from app.retrieval import RetrievalService
from app.routing import DEFAULT_ROUTES, TASK_MODELS
from app.schemas import (
    AnswerRequest,
    AnswerResponse,
    ChatCompletionRequest,
    ChatCompletionResponse,
    EmbeddingRequest,
    EmbeddingResponse,
    ModelCard,
    ModelList,
    RetrieveRequest,
    RetrieveResponse,
)
from app.security import enforce_rate_limit, require_api_key

health_router = APIRouter(tags=["health"])

v1_router = APIRouter(
    prefix="/v1",
    tags=["inference"],
    dependencies=[Depends(require_api_key), Depends(enforce_rate_limit)],
)

# Council Chat (ADR-0003) lives under /v1/council and inherits the same auth and
# rate limiting as the rest of the governed /v1 surface.
v1_router.include_router(council_router)


@health_router.get("/health")
def health() -> dict[str, str]:
    """Liveness probe."""
    return {"status": "ok"}


@health_router.get("/ready")
def ready() -> dict[str, str]:
    """Readiness probe."""
    return {"status": "ready"}


def get_service(request: Request) -> InferenceService:
    """Return the app-scoped inference service."""
    return request.app.state.inference_service


def get_retrieval_service(request: Request) -> RetrievalService:
    """Return the app-scoped retrieval service."""
    return request.app.state.retrieval_service


@v1_router.get("/models", response_model=ModelList)
def list_models() -> ModelList:
    """List the logical models the gateway can route to."""
    cards = [ModelCard(id=alias, task=task) for task, alias in TASK_MODELS.items()]
    known = {card.id for card in cards}
    cards.extend(ModelCard(id=alias, task=alias) for alias in DEFAULT_ROUTES if alias not in known)
    return ModelList(data=cards)


@v1_router.post("/chat/completions", response_model=ChatCompletionResponse)
async def chat_completions(
    payload: ChatCompletionRequest,
    service: InferenceService = Depends(get_service),
) -> ChatCompletionResponse | StreamingResponse:
    """Create a governed chat completion (SSE when ``stream=true``)."""
    if payload.stream:
        return StreamingResponse(
            _stream_chat(service, payload),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )
    return await service.chat(payload)


async def _stream_chat(
    service: InferenceService, payload: ChatCompletionRequest
) -> AsyncGenerator[bytes]:
    """Stream OpenAI-compatible chat chunks for a governed completion.

    Each delta is a ``chat.completion.chunk``; the stream ends with ``[DONE]``.
    A governed failure ends the stream cleanly (an SSE ``error`` frame), not a hang.
    """
    try:
        # Immediate role chunk so the client opens the stream at once (TTFB ~0s),
        # while the reasoning model warms up (its <think> trace is stripped).
        role_chunk = {
            "id": "chatcmpl-stream",
            "object": "chat.completion.chunk",
            "model": payload.model,
            "choices": [{"index": 0, "delta": {"role": "assistant"}, "finish_reason": None}],
        }
        yield f"data: {json.dumps(role_chunk)}\n\n".encode()
        async for delta in service.chat_stream(payload):
            chunk = {
                "id": "chatcmpl-stream",
                "object": "chat.completion.chunk",
                "model": payload.model,
                "choices": [{"index": 0, "delta": {"content": delta}, "finish_reason": None}],
            }
            yield f"data: {json.dumps(chunk)}\n\n".encode()
        yield b"data: [DONE]\n\n"
    except AppError as exc:
        payload = json.dumps({"error": exc.message, "code": exc.code})
        yield f"event: error\ndata: {payload}\n\n".encode()


@v1_router.post("/embeddings", response_model=EmbeddingResponse)
async def create_embeddings(
    payload: EmbeddingRequest,
    service: InferenceService = Depends(get_service),
) -> EmbeddingResponse:
    """Create embeddings for the given input."""
    return await service.embeddings(payload)


@v1_router.post("/retrieve", response_model=RetrieveResponse)
async def retrieve(
    payload: RetrieveRequest,
    retrieval: RetrievalService = Depends(get_retrieval_service),
) -> RetrieveResponse:
    """Retrieve ranked, cited evidence from the governed corpus."""
    if not retrieval.configured:
        raise RetrievalNotConfiguredError("retrieval is not configured")
    citations = await retrieval.retrieve(
        payload.query,
        tier=payload.tier,
        top_k=payload.top_k,
        min_score=payload.min_score,
    )
    return RetrieveResponse(query=payload.query, tier=payload.tier, citations=citations)


@v1_router.post("/answer", response_model=AnswerResponse)
async def answer(
    payload: AnswerRequest,
    retrieval: RetrievalService = Depends(get_retrieval_service),
    service: InferenceService = Depends(get_service),
) -> AnswerResponse:
    """Retrieve evidence and answer only from it, or abstain if there is none."""
    if not retrieval.configured:
        raise RetrievalNotConfiguredError("retrieval is not configured")
    citations = await retrieval.retrieve(
        payload.query,
        tier=payload.tier,
        top_k=payload.top_k,
        min_score=payload.min_score,
    )
    # Only citations carrying text are usable evidence; keep the returned
    # citations consistent with what the model actually saw.
    usable = [citation for citation in citations if citation.text]
    if not usable:
        return AnswerResponse(
            answer=(
                "I don't have enough grounded evidence to answer that. "
                "No approved source matched the question."
            ),
            grounded=False,
            abstained=True,
            citations=[],
        )
    grounded_request = build_grounded_request(
        payload.query, usable, model=payload.model, max_tokens=payload.max_tokens
    )
    completion = await service.chat(grounded_request)
    return AnswerResponse(
        answer=completion.choices[0].message.content,
        grounded=completion.grounded,
        abstained=completion.abstained,
        citations=usable,
    )
