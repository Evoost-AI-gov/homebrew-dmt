"""Structured JSON logging with PII masking.

The gateway never logs request or response bodies. These helpers provide a JSON
log formatter and a defensive ``mask_pii`` utility for any free-text that must be
logged (e.g. error context), so emails, phone numbers and long digit runs are
redacted before they reach the log sink.
"""

from __future__ import annotations

import json
import logging
import re

_EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
_PHONE = re.compile(r"\+?\d[\d\s().-]{7,}\d")
_LONG_DIGITS = re.compile(r"\b\d{6,}\b")

_EXTRA_FIELDS = ("request_id", "method", "path", "status", "duration_ms", "count", "model")

_configured = False


def mask_pii(text: str) -> str:
    """Redact emails, phone numbers and long digit runs from a string."""
    text = _EMAIL.sub("[email]", text)
    text = _PHONE.sub("[phone]", text)
    return _LONG_DIGITS.sub("[redacted]", text)


class JsonFormatter(logging.Formatter):
    """Render log records as single-line JSON objects."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, object] = {
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for field in _EXTRA_FIELDS:
            value = getattr(record, field, None)
            if value is not None:
                payload[field] = value
        return json.dumps(payload, ensure_ascii=False)


def configure_logging(level: int = logging.INFO) -> None:
    """Install the JSON formatter on the root logger exactly once."""
    global _configured
    if _configured:
        return
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(level)
    _configured = True
