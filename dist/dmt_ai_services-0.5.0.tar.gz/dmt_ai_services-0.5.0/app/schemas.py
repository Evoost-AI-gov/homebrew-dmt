"""OpenAI-compatible request/response schemas (an explicit allow-list subset).

The gateway deliberately uses ``extra="forbid"`` so unknown fields are rejected
rather than silently forwarded — a safer default for a government service. Two
DMT governance extensions are added to the chat contract: ``require_grounding``
(input) and ``grounded`` / ``abstained`` (output).
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

Role = Literal["system", "user", "assistant", "tool"]


class Usage(BaseModel):
    """Token accounting for a completion."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ChatMessage(BaseModel):
    """A single chat message. ``tool`` messages carry retrieved context."""

    model_config = ConfigDict(extra="forbid")

    role: Role
    content: str = Field(max_length=100_000)
    name: str | None = Field(default=None, max_length=128)


class ChatCompletionRequest(BaseModel):
    """An OpenAI-compatible chat completion request."""

    model_config = ConfigDict(extra="forbid")

    model: str = Field(min_length=1, max_length=128)
    messages: list[ChatMessage] = Field(min_length=1, max_length=100)
    temperature: float = Field(default=0.2, ge=0.0, le=2.0)
    top_p: float = Field(default=1.0, ge=0.0, le=1.0)
    max_tokens: int = Field(default=512, ge=1, le=8192)
    stream: bool = False
    # Thinking effort (instant/medium/high) -> a token budget (cost + latency).
    # Omitted = the request's max_tokens. Mirrors the council's effort control.
    effort: Literal["instant", "medium", "high"] | None = None
    # DMT governance: when true and no retrieved context (a ``tool`` message)
    # is present, the gateway abstains instead of allowing an ungrounded answer.
    require_grounding: bool = False


class ChatChoiceMessage(BaseModel):
    """The assistant message returned in a choice."""

    role: str
    content: str


class ChatChoice(BaseModel):
    """A single completion choice."""

    index: int
    message: ChatChoiceMessage
    finish_reason: str


class ChatCompletionResponse(BaseModel):
    """An OpenAI-compatible chat completion response with governance flags."""

    id: str
    object: str = "chat.completion"
    model: str
    choices: list[ChatChoice]
    usage: Usage = Field(default_factory=Usage)
    grounded: bool = True
    abstained: bool = False


class EmbeddingRequest(BaseModel):
    """An OpenAI-compatible embeddings request."""

    model_config = ConfigDict(extra="forbid")

    model: str = Field(min_length=1, max_length=128)
    input: str | list[str]


class EmbeddingItem(BaseModel):
    """A single embedding vector."""

    index: int
    embedding: list[float]
    object: str = "embedding"


class EmbeddingResponse(BaseModel):
    """An OpenAI-compatible embeddings response."""

    object: str = "list"
    model: str
    data: list[EmbeddingItem]
    usage: Usage = Field(default_factory=Usage)


class ModelCard(BaseModel):
    """Metadata for a logical model exposed by the gateway."""

    id: str
    object: str = "model"
    owned_by: str = "dmt"
    task: str


class ModelList(BaseModel):
    """The response for ``GET /v1/models``."""

    object: str = "list"
    data: list[ModelCard]


Tier = Literal["authoritative", "reference", "all"]
ChunkTier = Literal["authoritative", "reference"]


class Citation(BaseModel):
    """A retrieved evidence chunk with its provenance and similarity score."""

    chunk_id: str
    canonical_file: str
    domain: str
    tier: ChunkTier
    score: float
    text: str = ""


class RetrieveRequest(BaseModel):
    """A governed retrieval request over the tier-aware corpus."""

    model_config = ConfigDict(extra="forbid")

    query: str = Field(min_length=1, max_length=8_000)
    tier: Tier = "all"
    top_k: int = Field(default=5, ge=1, le=50)
    min_score: float = Field(default=0.0, ge=-1.0, le=1.0)


class RetrieveResponse(BaseModel):
    """Ranked citations for a retrieval request (empty = abstention)."""

    query: str
    tier: Tier
    citations: list[Citation]


class AnswerRequest(BaseModel):
    """A grounded-answer request: retrieve evidence, then answer only from it."""

    model_config = ConfigDict(extra="forbid")

    query: str = Field(min_length=1, max_length=8_000)
    model: str = Field(default="dmt-brain", min_length=1, max_length=128)
    tier: Tier = "all"
    top_k: int = Field(default=5, ge=1, le=50)
    min_score: float = Field(default=0.0, ge=-1.0, le=1.0)
    max_tokens: int = Field(default=512, ge=1, le=8192)


class AnswerResponse(BaseModel):
    """A grounded answer with its supporting citations, or an abstention."""

    answer: str
    grounded: bool
    abstained: bool
    citations: list[Citation]
