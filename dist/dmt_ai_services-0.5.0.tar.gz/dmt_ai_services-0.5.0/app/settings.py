"""Runtime configuration for the DMT AI gateway.

Settings load from environment variables (prefix ``DMT_AI_``) and enforce
fail-closed defaults suitable for a government-grade deployment: in production
the service refuses to start unless authentication and a model upstream are
configured.
"""

from __future__ import annotations

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Typed configuration for the AI gateway."""

    model_config = SettingsConfigDict(
        env_prefix="DMT_AI_",
        env_file=".env",
        extra="ignore",
    )

    app_env: str = "development"

    # Comma-separated list of accepted API keys (service-to-service auth).
    api_keys: str = ""
    # Allow unauthenticated access. Only permitted outside production.
    allow_unauthenticated: bool = False
    # Entra ID (workforce) user auth: validate bearer JWTs issued to the SPA.
    # When entra_tenant_id + entra_audience are set, an Authorization: Bearer <jwt>
    # from a signed-in DMT user is accepted (in addition to the service API key).
    entra_tenant_id: str = ""
    entra_audience: str = ""  # the API app registration client id (api://<id>)
    # Google sign-in: the OAuth 2.0 client id whose id_tokens the gateway accepts.
    # Empty = Google sign-in disabled. Validated against accounts.google.com JWKS.
    google_client_id: str = ""
    # Comma-separated email domains permitted to sign in (workforce gate). A
    # signed-in Entra/Google user whose email domain is not listed is rejected
    # (403), regardless of provider. Empty = no domain restriction. Fail-closed
    # default for the DMT sovereign platform.
    allowed_email_domains: str = "evoost.ai,dmt.gov.ae,evoost-ai.ae"

    # Upstream OpenAI-compatible model server (Ollama / vLLM / TGI).
    upstream_base_url: str = ""
    upstream_api_key: str = ""
    # Provider kind: "openai" = OpenAI-compatible path (/v1/chat/completions,
    # Bearer auth); "azure" = sovereign Azure OpenAI native REST
    # (/openai/deployments/{dep}/..., api-key or Entra bearer). Choose by deployment.
    upstream_kind: str = "openai"
    # Entra ID bearer token for the sovereign Azure deployment (keyless path). When
    # set, takes precedence over upstream_api_key for the azure provider.
    upstream_bearer_token: str = ""
    # Azure OpenAI API version (only used when upstream_kind="azure").
    azure_api_version: str = "2024-10-21"
    # Azure tenant id (for the Entra issuer validation).
    azure_tenant_id: str = ""
    # Deployment names for the sovereign model server. Chat defaults to dmt-brain;
    # embeddings to dmt-embed. Config-driven so each environment names its own.
    chat_model: str = "dmt-brain"
    embed_model: str = "dmt-embed"
    # Fast expert tier: the deployment council experts answer on (the Director keeps
    # the strong reasoning model for synthesis). Empty -> experts reuse chat_model
    # (single-model deployments). Set to a fast non-reasoning deployment (e.g.
    # gpt-4o-mini) to cut multi-agent turn latency without touching the code.
    expert_chat_model: str = ""
    request_timeout_s: float = 30.0
    max_retries: int = 2

    # Fixed-window rate limiting (per API key / client).
    rate_limit_enabled: bool = True
    rate_limit_per_minute: int = 100

    # Interactive API docs. Forced off unless the environment is development.
    enable_docs: bool = False

    # Online retrieval (RAG). Enabled only when an index and a query embedder are
    # configured; otherwise the retrieval endpoints fail closed.
    retrieval_embeddings_path: str = ""
    retrieval_chunks_path: str = ""
    retrieval_embed_url: str = ""
    retrieval_embed_api_key: str = ""
    retrieval_embed_model: str = "intfloat/multilingual-e5-base"
    # Local, in-process embedder (sentence-transformers). Sovereign: no egress. Used
    # when set; takes precedence over the HTTP embedder. Must match the index model.
    retrieval_embed_local: bool = False
    retrieval_query_prefix: str = "query: "
    retrieval_top_k: int = 5
    retrieval_min_score: float = 0.0
    retrieval_timeout_s: float = 15.0

    # Council Chat (ADR-0003). The registry compiles personas from the versioned
    # ``.agent.md`` corpus; empty -> council is not configured (empty roster).
    council_agents_dir: str = ""
    # When true and retrieval is live, a council answer must be grounded (else the
    # turn abstains). Defaults to true to keep the advisory surface hallucination-free.
    council_require_grounding: bool = True
    # Custom-agent builder (F4): JSON store of DMT-custom agents with Compliance
    # approval. Empty -> the builder is disabled and no custom agents are served.
    council_custom_store_path: str = ""
    # External-capture agents (F5): comma-separated allowlist of domains the council
    # may fetch for external (unverified) context. Empty -> external capture off.
    council_external_allowlist: str = ""

    # CORS (browser front-ends). Off by default: a government service is
    # service-to-service. Only when a comma-separated origin list is set does the
    # gateway emit CORS headers (local dev / a known SPA origin). Never "*".
    cors_allowed_origins: str = ""

    # Chat persistence (advisory conversation state). Empty -> /v1/chats not mounted
    # and the frontend keeps its local (offline) state.
    chat_store_path: str = ""
    # Per-user work context (the Director-as-coworker substrate). Empty -> /v1/me
    # not mounted and the Director answers from generic domain knowledge only.
    user_context_path: str = ""
    # Personal Graph (Semantica ContextGraph, per user). Empty -> /v1/me/graph not
    # mounted. Provenance-tracked, temporal, with decision recording.
    graph_store_path: str = ""
    # Council metrics (per-turn governance KPI log). Empty -> /v1/council/metrics
    # reports available:false; when set, each completed turn is appended and the
    # per-expert KPIs are aggregated from it.
    council_metrics_path: str = ""
    # Live governed backend (enterprise mode). When set, the council consults the
    # platform's live decision surface (GET /v1/demand, /v1/recommendation) instead
    # of the offline snapshots, so a chat/CLI answer reflects the current governed
    # state. Empty -> the council serves the committed offline snapshots.
    backend_base_url: str = ""
    # Optional bearer token for the backend reads (service-to-service). Empty ->
    # unauthenticated (only for a local/trusted backend).
    backend_token: str = ""

    @property
    def cors_origin_list(self) -> list[str]:
        """The allow-listed CORS origins (empty = CORS disabled)."""
        return [o.strip() for o in self.cors_allowed_origins.split(",") if o.strip()]

    @property
    def external_allowlist_set(self) -> frozenset[str]:
        """The allow-listed domains for external capture (F5)."""
        return frozenset(
            d.strip().lower() for d in self.council_external_allowlist.split(",") if d.strip()
        )

    @property
    def allowed_email_domain_set(self) -> frozenset[str]:
        """Email domains permitted to sign in (empty = no restriction)."""
        return frozenset(
            d.strip().lower().lstrip("@")
            for d in self.allowed_email_domains.split(",")
            if d.strip()
        )

    @property
    def is_production(self) -> bool:
        """Whether the service runs in the production environment."""
        return self.app_env.lower() == "production"

    @property
    def is_development(self) -> bool:
        """Whether the service runs in the development environment."""
        return self.app_env.lower() == "development"

    @property
    def api_key_set(self) -> frozenset[str]:
        """The set of accepted API keys, parsed from ``api_keys``."""
        return frozenset(k.strip() for k in self.api_keys.split(",") if k.strip())

    @model_validator(mode="after")
    def _enforce_secure_production(self) -> Settings:
        """Fail closed: refuse insecure configuration in production."""
        if self.is_production:
            if self.allow_unauthenticated:
                raise ValueError("allow_unauthenticated must be false in production")
            if not self.api_key_set:
                raise ValueError("at least one API key is required in production")
            if not self.upstream_base_url:
                raise ValueError("upstream_base_url is required in production")
        return self
