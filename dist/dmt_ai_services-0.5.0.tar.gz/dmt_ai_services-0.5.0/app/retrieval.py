"""Online retrieval (RAG) read path for the gateway.

Loads a prebuilt, tier-aware vector index (produced by ``ml/retrieval/``), embeds
the query with the *same* model used to build the index, and returns ranked,
cited evidence — or nothing (a retrieval abstention) when no hit clears the
score threshold. Fail-closed: without an index and a query embedder configured,
the service raises :class:`RetrievalNotConfiguredError`.
"""

from __future__ import annotations

import json
import logging
import math
from pathlib import Path
from typing import Protocol

import httpx
import numpy as np

from app.errors import RetrievalNotConfiguredError, UpstreamError
from app.schemas import Citation

_logger = logging.getLogger("dmt_ai.retrieval")

_CHUNK_TIERS = frozenset({"authoritative", "reference"})


class Embedder(Protocol):
    """Embeds query text into a dense vector using the index's model."""

    async def embed(self, text: str) -> list[float]: ...


class NullEmbedder:
    """Fail-closed embedder used when no query embedder is configured."""

    async def embed(self, text: str) -> list[float]:
        del text
        raise RetrievalNotConfiguredError("no query embedder configured")


class HttpEmbedder:
    """Embed queries via an OpenAI-compatible ``/v1/embeddings`` endpoint.

    Point this at a server hosting the *same* embedding model as the index
    (e.g. ``intfloat/multilingual-e5-base``). The configured ``query_prefix`` is
    prepended, matching how passages were embedded offline.
    """

    def __init__(
        self,
        base_url: str,
        model: str,
        query_prefix: str = "",
        api_key: str = "",
        timeout_s: float = 15.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._model = model
        self._query_prefix = query_prefix
        headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        # Reuse one client so connection pooling / keep-alive apply across queries.
        self._client = httpx.AsyncClient(timeout=httpx.Timeout(timeout_s), headers=headers)

    async def embed(self, text: str) -> list[float]:
        payload = {"model": self._model, "input": f"{self._query_prefix}{text}"}
        try:
            response = await self._client.post(f"{self._base_url}/v1/embeddings", json=payload)
            response.raise_for_status()
            data = response.json()
        except httpx.HTTPError as exc:
            raise UpstreamError("query embedding request failed") from exc
        except ValueError as exc:
            raise UpstreamError("query embedder returned invalid JSON") from exc
        try:
            return [float(v) for v in data["data"][0]["embedding"]]
        except (KeyError, IndexError, TypeError) as exc:
            raise UpstreamError("query embedder returned an unexpected shape") from exc

    async def aclose(self) -> None:
        """Close the pooled HTTP client (called on app shutdown)."""
        await self._client.aclose()


def _l2_normalise(vector: np.ndarray) -> np.ndarray:
    norm = np.linalg.norm(vector)
    if norm == 0:
        return vector
    return vector / norm


class VectorIndex:
    """An in-memory, tier-aware dense index loaded from JSONL artifacts."""

    def __init__(
        self,
        chunk_ids: list[str],
        metadata: list[dict[str, object]],
        matrix: np.ndarray,
        texts: dict[str, str],
    ) -> None:
        self._chunk_ids = chunk_ids
        self._metadata = metadata
        self._matrix = matrix  # shape (N, D), rows L2-normalised
        self._texts = texts

    @property
    def size(self) -> int:
        return len(self._chunk_ids)

    @classmethod
    def load(cls, embeddings_path: Path, chunks_path: Path | None = None) -> VectorIndex:
        """Load vectors + metadata (and optionally chunk text) from JSONL files."""
        chunk_ids: list[str] = []
        metadata: list[dict[str, object]] = []
        vectors: list[list[float]] = []
        with embeddings_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                row = json.loads(line)
                chunk_ids.append(row["chunk_id"])
                # Unknown/missing tiers are coerced to the LESS privileged tier
                # so a malformed index can never mislabel content as authoritative
                # (and never raise on the strict Citation.tier allow-list).
                tier = row.get("tier", "reference")
                if tier not in _CHUNK_TIERS:
                    tier = "reference"
                metadata.append(
                    {
                        "canonical_file": row.get("canonical_file", ""),
                        "domain": row.get("domain", ""),
                        "tier": tier,
                        "access_scope": row.get("access_scope"),
                    }
                )
                vectors.append(row["embedding"])

        if not vectors:
            raise RetrievalNotConfiguredError("retrieval index is empty")

        matrix = np.asarray(vectors, dtype=np.float32)
        norms = np.linalg.norm(matrix, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        matrix = matrix / norms

        texts: dict[str, str] = {}
        if chunks_path is not None and chunks_path.exists():
            with chunks_path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    line = line.strip()
                    if not line:
                        continue
                    row = json.loads(line)
                    texts[row["chunk_id"]] = row.get("text", "")

        return cls(chunk_ids, metadata, matrix, texts)

    def search(
        self,
        query_vector: list[float],
        *,
        top_k: int,
        tier: str,
        min_score: float,
        access_scopes: frozenset[str] | None = None,
    ) -> list[Citation]:
        """Return the top matching citations, filtered by tier, scope and score."""
        query = _l2_normalise(np.asarray(query_vector, dtype=np.float32))
        if query.shape[0] != self._matrix.shape[1]:
            raise UpstreamError(
                f"query embedding dim {query.shape[0]} does not match index dim "
                f"{self._matrix.shape[1]} (embedder model must match the index model)"
            )
        scores = self._matrix @ query

        candidates: list[tuple[float, int]] = []
        for index, score in enumerate(scores):
            meta = self._metadata[index]
            if tier != "all" and meta["tier"] != tier:
                continue
            if not self._scope_allows(meta.get("access_scope"), access_scopes):
                continue
            value = float(score)
            if value < min_score:
                continue
            candidates.append((value, index))

        candidates.sort(key=lambda item: item[0], reverse=True)
        citations: list[Citation] = []
        for value, index in candidates[:top_k]:
            chunk_id = self._chunk_ids[index]
            meta = self._metadata[index]
            citations.append(
                Citation(
                    chunk_id=chunk_id,
                    canonical_file=str(meta["canonical_file"]),
                    domain=str(meta["domain"]),
                    tier=str(meta["tier"]),
                    score=round(value, 6),
                    text=self._texts.get(chunk_id, ""),
                )
            )
        return citations

    @staticmethod
    def _scope_allows(chunk_scope: object, caller_scopes: frozenset[str] | None) -> bool:
        """A chunk with no scope is broadly accessible; otherwise the caller must
        hold the chunk's scope. Reserved for tenant/jurisdiction scoping."""
        if not chunk_scope:
            return True
        if caller_scopes is None:
            return False
        return str(chunk_scope) in caller_scopes


class RetrievalService:
    """Embed a query and search the governed index for grounded evidence."""

    def __init__(
        self,
        embedder: Embedder,
        index: VectorIndex | None,
        *,
        default_top_k: int = 5,
        default_min_score: float = 0.0,
    ) -> None:
        self._embedder = embedder
        self._index = index
        self._default_top_k = default_top_k
        self._default_min_score = default_min_score

    @property
    def configured(self) -> bool:
        return self._index is not None and not isinstance(self._embedder, NullEmbedder)

    async def aclose(self) -> None:
        """Release embedder resources (e.g. a pooled HTTP client) on shutdown."""
        close = getattr(self._embedder, "aclose", None)
        if close is not None:
            await close()

    async def retrieve(
        self,
        query: str,
        *,
        tier: str = "all",
        top_k: int | None = None,
        min_score: float | None = None,
        access_scopes: frozenset[str] | None = None,
    ) -> list[Citation]:
        """Return ranked citations for ``query`` (possibly empty = abstain)."""
        if self._index is None:
            raise RetrievalNotConfiguredError("retrieval index is not configured")
        query_vector = await self._embedder.embed(query)
        return self._index.search(
            query_vector,
            top_k=top_k if top_k is not None else self._default_top_k,
            tier=tier,
            min_score=min_score if min_score is not None else self._default_min_score,
            access_scopes=access_scopes,
        )


class LocalEmbedder:
    """Embed queries in-process with sentence-transformers (sovereign, no egress).

    Used when ``retrieval_embed_local`` is set. The model must match the one that
    embedded the index (e.g. ``intfloat/multilingual-e5-base``). The model is loaded
    lazily on first use so app startup stays fast when retrieval is not called.
    """

    def __init__(self, model: str, query_prefix: str = "") -> None:
        self._model_name = model
        self._query_prefix = query_prefix
        self._model = None  # lazy

    def _load(self) -> None:
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError as exc:
                raise RetrievalNotConfiguredError(
                    "sentence-transformers is not installed (local embedder unavailable)"
                ) from exc
            self._model = SentenceTransformer(self._model_name)

    async def embed(self, text: str) -> list[float]:
        self._load()
        import asyncio

        vector = await asyncio.to_thread(
            lambda: self._model.encode(
                f"{self._query_prefix}{text}", normalize_embeddings=True
            ).tolist()
        )
        return [float(v) for v in vector]


def build_embedder(
    *,
    base_url: str,
    model: str,
    query_prefix: str,
    api_key: str,
    timeout_s: float,
    local: bool = False,
) -> Embedder:
    """Build the query embedder, or a fail-closed one if none is configured."""
    if local:
        return LocalEmbedder(model=model, query_prefix=query_prefix)
    if base_url:
        return HttpEmbedder(
            base_url=base_url,
            model=model,
            query_prefix=query_prefix,
            api_key=api_key,
            timeout_s=timeout_s,
        )
    return NullEmbedder()


def load_index(embeddings_path: str, chunks_path: str) -> VectorIndex | None:
    """Load the vector index from configured paths, or None if unset/unusable.

    A missing or malformed index disables retrieval (fail-closed at the endpoint)
    rather than crashing app startup.
    """
    if not embeddings_path:
        return None
    embeddings = Path(embeddings_path)
    if not embeddings.exists():
        return None
    chunks = Path(chunks_path) if chunks_path else None
    try:
        return VectorIndex.load(embeddings, chunks)
    except (OSError, ValueError, KeyError, RetrievalNotConfiguredError) as exc:
        _logger.warning("retrieval_index_load_failed: %s", type(exc).__name__)
        return None


def cosine(a: list[float], b: list[float]) -> float:
    """Cosine similarity helper (used in tests and diagnostics)."""
    dot = sum(x * y for x, y in zip(a, b, strict=True))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)
