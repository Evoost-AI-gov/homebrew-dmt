"""Pure-ASGI middleware: security response headers and request context.

Both are implemented as pure ASGI apps (not ``BaseHTTPMiddleware``) so they add
negligible overhead and interoperate cleanly with streaming responses.
"""

from __future__ import annotations

import logging
import time
import uuid

from starlette.types import ASGIApp, Message, Receive, Scope, Send

_access_logger = logging.getLogger("dmt_ai.access")

_REQUEST_ID_HEADER = b"x-request-id"

_SECURITY_HEADERS: dict[bytes, bytes] = {
    b"x-content-type-options": b"nosniff",
    b"x-frame-options": b"DENY",
    b"referrer-policy": b"no-referrer",
    b"x-permitted-cross-domain-policies": b"none",
    b"cache-control": b"no-store",
    b"strict-transport-security": b"max-age=63072000; includeSubDomains; preload",
    b"content-security-policy": b"default-src 'none'; frame-ancestors 'none'; base-uri 'none'",
}


class SecurityHeadersMiddleware:
    """Attach hardened security headers to every HTTP response.

    ``csp_exempt_paths`` lists paths for which the restrictive CSP is skipped
    (interactive docs need inline assets). It is empty unless docs are served,
    so disabled-docs paths (which 404) still receive the full CSP.
    """

    def __init__(self, app: ASGIApp, csp_exempt_paths: tuple[str, ...] = ()) -> None:
        self.app = app
        self._csp_exempt_paths = csp_exempt_paths

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        skip_csp = scope.get("path", "") in self._csp_exempt_paths

        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers: list[tuple[bytes, bytes]] = message.setdefault("headers", [])
                present = {key for key, _ in headers}
                for key, value in _SECURITY_HEADERS.items():
                    if key == b"content-security-policy" and skip_csp:
                        continue
                    if key not in present:
                        headers.append((key, value))
            await send(message)

        await self.app(scope, receive, send_wrapper)


def _safe_request_id(raw: bytes | None) -> str:
    """Sanitise an inbound request id to prevent log injection."""
    if not raw:
        return uuid.uuid4().hex
    cleaned = "".join(c for c in raw.decode("ascii", "ignore") if c.isalnum() or c in "-_")
    return cleaned[:64] or uuid.uuid4().hex


class RequestContextMiddleware:
    """Assign a request id, echo it back, and emit a body-free access log."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        headers = dict(scope.get("headers", []))
        request_id = _safe_request_id(headers.get(_REQUEST_ID_HEADER))
        scope.setdefault("state", {})["request_id"] = request_id

        start = time.perf_counter()
        response_status = {"code": 500}

        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                response_status["code"] = message["status"]
                out_headers: list[tuple[bytes, bytes]] = message.setdefault("headers", [])
                if not any(key.lower() == _REQUEST_ID_HEADER for key, _ in out_headers):
                    out_headers.append((_REQUEST_ID_HEADER, request_id.encode()))
            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            _access_logger.info(
                "request",
                extra={
                    "request_id": request_id,
                    "method": scope.get("method"),
                    "path": scope.get("path"),
                    "status": response_status["code"],
                    "duration_ms": round((time.perf_counter() - start) * 1000, 2),
                },
            )
