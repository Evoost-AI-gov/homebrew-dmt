"""In-process fixed-window rate limiter.

This is a per-replica limiter used as defense-in-depth. Production multi-replica
deployments must also enforce limits at the API gateway or a shared store
(Redis); this guards a single instance and keeps abusive callers from exhausting
the upstream model server.
"""

from __future__ import annotations

import time


class FixedWindowRateLimiter:
    """Count requests per identity within a one-minute fixed window."""

    def __init__(self, limit_per_minute: int) -> None:
        self._limit = max(1, limit_per_minute)
        self._counters: dict[str, tuple[int, int]] = {}

    def allow(self, identity: str) -> bool:
        """Record a request for ``identity`` and report whether it is allowed."""
        window = int(time.time() // 60)
        count, seen_window = self._counters.get(identity, (0, window))
        if seen_window != window:
            count = 0
        count += 1
        self._counters[identity] = (count, window)
        return count <= self._limit
