"""Deterministic logical-model routing with ordered fallback.

A request names a *logical* model or task alias; the router resolves it to an
ordered list of concrete upstream model tags. The table is small, explicit and
config-driven so routing decisions stay auditable. Unknown names pass through
unchanged, so callers may also target a concrete tag directly.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

# Logical alias -> ordered concrete upstream tags (primary first, then fallback).
# On the sovereign Azure deployment the only chat deployment is `dmt-brain`, so
# every chat route resolves there (the deployment name is the upstream model).
DEFAULT_ROUTES: dict[str, list[str]] = {
    "dmt-brain": ["dmt-brain"],
    "general": ["dmt-brain"],
    "fast": ["dmt-brain"],
    "translate": ["dmt-brain"],
    "embed": ["dmt-embed"],
}

# Task name -> logical alias (used by ``GET /v1/models`` for discoverability).
TASK_MODELS: dict[str, str] = {
    "domain_chat": "dmt-brain",
    "general_chat": "general",
    "fast_classify": "fast",
    "translate": "translate",
    "embedding": "embed",
}

# Council role -> task alias. The Director (synthesis/orchestration) uses the
# strongest reasoning model; experts answering interactively use the fast chat
# model so the conversation feels responsive. Overridable via settings.
ROLE_TASKS: dict[str, str] = {
    "director": "domain_chat",  # reasoning tier (synthesis quality matters)
    "expert": "general_chat",  # fast tier (interactive answers)
    "gate": "general_chat",
}


class Router(BaseModel):
    """Resolve a logical model name to ordered upstream candidates."""

    routes: dict[str, list[str]] = Field(default_factory=lambda: dict(DEFAULT_ROUTES))
    role_tasks: dict[str, str] = Field(default_factory=lambda: dict(ROLE_TASKS))
    task_models: dict[str, str] = Field(default_factory=lambda: dict(TASK_MODELS))

    def resolve(self, model: str) -> list[str]:
        """Return the ordered candidate list for a logical model or alias."""
        if model in self.routes:
            return list(self.routes[model])
        return [model]

    def resolve_for_role(self, role: str) -> list[str]:
        """Resolve the model candidates for a council role (director/expert/gate).

        Hops role -> task alias -> logical model -> deployment candidates, so the
        provider is always given a concrete deployment name (never a task alias).
        """
        task = self.role_tasks.get(role, "general_chat")
        logical = self.task_models.get(task, task)
        return self.resolve(logical)
