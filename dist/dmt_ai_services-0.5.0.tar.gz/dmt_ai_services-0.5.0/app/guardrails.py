"""Input guardrails: grounding detection and prompt-injection screening.

Retrieved evidence is delivered to the model as ``tool`` messages and is treated
as untrusted data, not instructions. These helpers let the gateway (a) abstain
when grounding is required but absent, and (b) flag context that tries to
override the system prompt (indirect prompt injection).
"""

from __future__ import annotations

import re

from app.schemas import ChatCompletionRequest

CONTEXT_ROLES = {"tool"}

_INJECTION_PATTERNS = (
    re.compile(r"ignore (all|any|previous|the above)", re.IGNORECASE),
    re.compile(r"disregard[\w\s]*instructions", re.IGNORECASE),
    re.compile(r"you are now", re.IGNORECASE),
    re.compile(r"system prompt", re.IGNORECASE),
    re.compile(r"reveal[\w\s]*(secret|api key|password|token)", re.IGNORECASE),
)


def scan_for_injection(text: str) -> bool:
    """Return True if the text matches a known prompt-injection pattern."""
    return any(pattern.search(text) for pattern in _INJECTION_PATTERNS)


def has_grounding_context(request: ChatCompletionRequest) -> bool:
    """Return True if the request carries at least one retrieved-context message."""
    return any(message.role in CONTEXT_ROLES for message in request.messages)


def flag_injection(request: ChatCompletionRequest) -> list[int]:
    """Return the indices of context messages that look like injection attempts."""
    return [
        index
        for index, message in enumerate(request.messages)
        if message.role in CONTEXT_ROLES and scan_for_injection(message.content)
    ]
