"""Structured application errors and the JSON error envelope.

All handled errors are rendered as ``{"error": {"code", "message"}}`` so the
envelope is consistent with the rest of the DMT platform and never leaks stack
traces or internal detail to callers.
"""

from __future__ import annotations

from fastapi import Request
from fastapi.responses import JSONResponse


class AppError(Exception):
    """Base class for errors rendered as a structured JSON envelope."""

    status_code: int = 500
    code: str = "internal_error"

    def __init__(self, message: str | None = None) -> None:
        self.message = message or self.code
        super().__init__(self.message)


class UnauthorizedError(AppError):
    """Authentication is missing or invalid."""

    status_code = 401
    code = "unauthorized"


class ForbiddenError(AppError):
    """The caller is authenticated but not allowed."""

    status_code = 403
    code = "forbidden"


class InvalidRequestError(AppError):
    """The request is well-formed but semantically rejected."""

    status_code = 400
    code = "invalid_request"


class RateLimitedError(AppError):
    """The caller exceeded its rate limit."""

    status_code = 429
    code = "rate_limited"


class UpstreamNotConfiguredError(AppError):
    """No model upstream is configured; the gateway cannot serve inference."""

    status_code = 503
    code = "upstream_not_configured"


class RetrievalNotConfiguredError(AppError):
    """No retrieval index / query embedder is configured."""

    status_code = 503
    code = "retrieval_not_configured"


class UpstreamRejectedError(AppError):
    """The upstream rejected the request (4xx): not retryable, no fallback."""

    status_code = 502
    code = "upstream_rejected"


class UpstreamError(AppError):
    """The upstream model server failed: 5xx, network error, or an unusable/invalid
    response body. Retryable and may trigger fallback to the next candidate model."""

    status_code = 502
    code = "upstream_error"


def app_error_handler(request: Request, exc: AppError) -> JSONResponse:
    """Render an :class:`AppError` (or subclass) as the JSON envelope."""
    del request  # unused; the envelope never echoes request data
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": {"code": exc.code, "message": exc.message}},
    )
