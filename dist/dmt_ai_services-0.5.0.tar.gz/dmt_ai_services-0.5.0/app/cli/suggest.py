"""Deterministic follow-up suggestion chips for the council CLI.

After each governed turn the REPL offers 3 contextual next actions the user can
pick with arrow keys (rich path) or by typing. Suggestions are derived
**deterministically** from the turn's outcome (which agents spoke, abstentions,
veto, tools used) plus the rotating generic set — never invented per query, so
they stay honest and cheap (no extra model call). The last entry is always an
explicit opt-out to free text.
"""

from __future__ import annotations

import re
from typing import Any

FREE_TEXT = "✎  Type your own follow-up…"

# The Director's "Next Actions" section: a heading followed by numbered items
# (markdown or plain). Matched case-insensitively; the section ends at a blank
# line or the next heading.
_NEXT_ACTIONS_HEADING = re.compile(
    r"^#{0,4}\s*(?:\*\*)?next actions(?:\*\*)?[ \t]*:?[ \t]*$", re.IGNORECASE | re.MULTILINE
)
_NUMBERED_ITEM = re.compile(r"^\s*(?:[-*]|\d+[.)]?)\s+(.+?)\s*$")

# Agent id (short or full) -> a natural next-step suggestion for that expert.
_BY_AGENT = {
    "valuation": "Model the IRR / yield on that benchmark",
    "market-intelligence": "Show the supporting market evidence",
    "sequencing": "Sequence the release into phases",
    "sustainability": "Check the Estidama / ESG implications",
    "deal-structuring": "Compare Musataha vs long-lease structures",
    "geopolitical": "Screen the geopolitical / sanctions angle",
    "urban-planning": "Check this against Plan Abu Dhabi 2030 land use",
    "investment": "Stress-test the investment case",
    "investor-archetypes": "Which investor archetypes does this fit?",
    "government-affairs": "What approvals / stakeholders does this need?",
    "product": "How would this be packaged commercially?",
    "director": "Go deeper on the Director's reasoning",
}

_GENERIC = [
    "Explain that in more detail",
    "What are the risks?",
    "Summarise it in 3 bullets",
]

_ON_ABSTAIN = "What CAN you answer from the governed sources?"
_ON_VETO = "Why was that blocked by governance?"


def _next_actions(content: str) -> list[str]:
    """Extract the numbered items under the Director's 'Next Actions' heading.
    Inline code/backticks are stripped so the chip is a clean, actionable line.
    """
    if not content:
        return []
    match = _NEXT_ACTIONS_HEADING.search(content)
    if match is None:
        return []
    actions: list[str] = []
    for line in content[match.end() :].splitlines():
        if not line.strip():
            if actions:
                break  # a blank line ends the section
            continue  # skip the blank right after the heading
        item = _NUMBERED_ITEM.match(line)
        if item is None:
            break  # the section ended (new paragraph / heading)
        action = item.group(1).replace("`", "").strip()
        if action:
            actions.append(action)
    return actions


def suggest(final: dict[str, Any]) -> list[str]:
    """Return up to 3 contextual follow-ups + the free-text opt-out.

    ``final`` is the CouncilChatResponse-shaped dict (messages, synthesis, veto).
    The Director's own "Next Actions" always lead the picker — they are the
    governed, turn-specific recommendations; the deterministic chips fill the
    remaining slots.
    """
    if not final:
        return [FREE_TEXT]
    out: list[str] = []

    if final.get("veto"):
        out.append(_ON_VETO)

    # The Director's proposed Next Actions become selectable options.
    seen: set[str] = set()
    synthesis = final.get("synthesis") or {}
    for content in [synthesis.get("content", "")] + [
        m.get("content", "") for m in final.get("messages", []) or []
    ]:
        for action in _next_actions(str(content)):
            if action not in seen and len(out) < 3:
                out.append(action)
                seen.add(action)

    for message in final.get("messages", []) or []:
        if message.get("abstained") and _ON_ABSTAIN not in out:
            out.append(_ON_ABSTAIN)
        agent_id = str(message.get("agent_id", ""))
        for key, chip in _BY_AGENT.items():
            if key in agent_id and chip not in seen:
                out.append(chip)
                seen.add(chip)

    for key, chip in _BY_AGENT.items():
        if key in str(synthesis.get("agent_id", "")) and chip not in seen:
            out.append(chip)
            seen.add(chip)

    for chip in _GENERIC:
        if len(out) >= 3:
            break
        if chip not in seen:
            out.append(chip)
            seen.add(chip)

    out = out[:3]
    out.append(FREE_TEXT)
    return out
