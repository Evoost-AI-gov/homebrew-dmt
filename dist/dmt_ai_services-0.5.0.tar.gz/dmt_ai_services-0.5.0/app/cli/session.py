"""Chat session state + turn execution, shared by the REPL and one-shot mode.

The session owns the conversation id, message history and roster settings, and
drives the client through one governed turn — streaming to the renderer (or as
NDJSON when ``--json``), recording the transcript, and folding the assistant
reply back into history so follow-ups carry context. A governance veto sets
``last_veto`` and maps to exit code 2; the user turn stays in history so the
conversation can continue (matching the web assistant's behaviour).
"""

from __future__ import annotations

import json
import sys
import uuid
from typing import Any, TextIO

from app.cli.client import CliError, CouncilClient
from app.cli.config import CliConfig
from app.cli.render import build_renderer
from app.cli.transcript import Transcript

DEFAULT_AGENTS = ["director-program-orchestrator"]


class ChatSession:
    """One governed conversation from the terminal."""

    def __init__(
        self,
        config: CliConfig,
        client: CouncilClient,
        *,
        conversation_id: str | None = None,
        agents: list[str] | None = None,
        effort: str | None = None,
        delegate: bool = False,
        deliberate: bool = False,
        user_context: str = "",
        json_mode: bool = False,
        stream: bool = True,
        out: TextIO | None = None,
    ) -> None:
        self.config = config
        self.client = client
        self.conversation_id = conversation_id or uuid.uuid4().hex[:12]
        self.agents = list(agents or DEFAULT_AGENTS)
        self.effort = effort
        self.delegate = delegate
        self.deliberate = deliberate
        self.user_context = user_context
        self.json_mode = json_mode
        self.stream = stream
        self.messages: list[dict[str, str]] = []
        self.last_veto: dict[str, Any] | None = None
        self.last_final: dict[str, Any] = {}
        self.renderer = build_renderer(color=config.color and not json_mode, out=out)
        self._out = out or sys.stdout
        self.transcript = Transcript(
            config.state_dir, self.conversation_id, enabled=config.transcript
        )

    def ask(self, text: str) -> int:
        """Run one governed turn. Returns 0 on success, 2 on a governance veto,
        or the error's exit code (1) on transport/config/server failure."""
        self.last_veto = None
        self.messages.append({"role": "user", "content": text})
        self.transcript.record("user", content=text, agents=self.agents)
        if not self.json_mode:
            # Codex-style prompt echo. Never in --json mode: stdout stays NDJSON.
            self.renderer.user_prompt(text)
        final: dict[str, Any] = {}
        try:
            for event in self.client.chat(
                messages=self.messages,
                agents=self.agents,
                conversation_id=self.conversation_id,
                stream=self.stream and not self.json_mode,
                deliberate=self.deliberate,
                delegate=self.delegate,
                effort=self.effort,
                user_context=self.user_context,
            ):
                self._handle(event.kind, event.payload)
                if event.kind == "message_done":
                    final = event.payload
        except CliError as exc:
            self._emit("error", {"error": str(exc)})
            if not self.json_mode:
                self.renderer.error(str(exc))
            self.messages.pop()  # a failed turn leaves no half-state behind
            return exc.exit_code
        finally:
            self.renderer.end_turn()  # stop any live region, even on Ctrl-C
        self._fold_assistant(final)
        self.last_final = final
        return 2 if self.last_veto is not None else 0

    # --- event handling ---------------------------------------------------------

    def _handle(self, kind: str, payload: dict[str, Any]) -> None:
        if self.json_mode:
            self._emit(kind, payload)
            return
        if kind == "turn_started":
            self.renderer.turn_started(list(payload.get("agents", [])))
        elif kind == "agent_started":
            self.renderer.agent_started(str(payload.get("agent_id", "")))
        elif kind == "synthesis_started":
            # The Director's synthesis is a distinct panel (streamed fan-out).
            self.renderer.agent_started(str(payload.get("agent_id", "")), synthesis=True)
        elif kind == "token":
            self.renderer.token(str(payload.get("agent_id", "")), str(payload.get("delta", "")))
        elif kind == "agent_message":
            self.renderer.message(payload)
        elif kind == "synthesis_done":
            self.renderer.message(payload, synthesis=True)
        elif kind == "veto":
            self.last_veto = payload
            self.renderer.veto(str(payload.get("gate", "")), str(payload.get("reason", "")))
        elif kind == "error":
            self.renderer.error(str(payload.get("error", "council error")))
        elif kind == "message_done":
            # Unary mode (--no-stream) yields ONLY this event: render the reply
            # bodies from the payload (streaming already rendered them).
            if not self.stream:
                for message in payload.get("messages", []) or []:
                    self.renderer.message(message)
                synthesis = payload.get("synthesis")
                if synthesis:
                    self.renderer.message(synthesis, synthesis=True)
            # Unary carries the veto inline (streaming emits a veto event first).
            veto = payload.get("veto") if isinstance(payload, dict) else None
            if veto and self.last_veto is None:
                self.last_veto = veto
                self.renderer.veto(str(veto.get("gate", "")), str(veto.get("reason", "")))
            meta = payload.get("meta", {}) if isinstance(payload, dict) else {}
            self.renderer.synthesis_done(meta, payload.get("conversation_id"))

    def _emit(self, kind: str, payload: dict[str, Any]) -> None:
        if kind == "veto":
            self.last_veto = payload
        self._out.write(json.dumps({"event": kind, **payload}, ensure_ascii=False) + "\n")
        self._out.flush()

    def _fold_assistant(self, final: dict[str, Any]) -> None:
        """Fold the governed reply into history + transcript."""
        if not final:
            return
        self.conversation_id = final.get("conversation_id") or self.conversation_id
        headline = ""
        synthesis = final.get("synthesis")
        if synthesis:
            headline = str(synthesis.get("content", ""))
        elif final.get("messages"):
            headline = str(final["messages"][-1].get("content", ""))
        if headline:
            self.messages.append({"role": "assistant", "content": headline})
        self.transcript.record(
            "assistant",
            conversation_id=self.conversation_id,
            headline=headline,
            veto=final.get("veto"),
            meta=final.get("meta", {}),
            auth=self.config.auth_fingerprint,
        )

    # --- portability (web <-> terminal) ------------------------------------------

    def sync_up(self, *, title: str) -> None:
        """Push the transcript to the server-side store the web app reads."""
        wire = [
            {"id": f"m{i}", "role": m["role"], "content": m["content"]}
            for i, m in enumerate(self.messages)
        ]
        self.client.upsert_chat(self.conversation_id, title=title, messages=wire)
        self.transcript.record("sync_up", title=title, messages=len(wire))

    def load_from(self, record: dict[str, Any]) -> None:
        """Adopt a server-side conversation (e.g. started in the web app)."""
        self.conversation_id = str(record.get("id", self.conversation_id))
        self.messages = [
            {"role": str(m.get("role", "user")), "content": str(m.get("content", ""))}
            for m in record.get("messages", [])
            if m.get("role") in ("user", "assistant", "system")
        ]
        self.transcript = Transcript(
            self.config.state_dir, self.conversation_id, enabled=self.config.transcript
        )
        self.transcript.record("resume", source="server", messages=len(self.messages))
