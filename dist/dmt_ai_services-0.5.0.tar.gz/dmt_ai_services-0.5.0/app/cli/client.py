"""HTTP client for the governed council surface.

Sync httpx against the same ``/v1/council`` + ``/v1/chats`` endpoints the web
assistant uses, with the platform's structured error envelope
(``{"error": {"code", "message"}}``) mapped to typed exceptions. Auth is either
an Entra bearer token (workforce sign-in) or the service ``X-API-Key`` — the
gateway accepts both; the CLI never invents its own credential path.
"""

from __future__ import annotations

import json
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from typing import Any

import httpx

from app.cli.config import CliConfig
from app.cli.sse import SseParser


class CliError(Exception):
    """A user-facing CLI failure. ``exit_code`` follows the governed contract:
    1 = generic/transport/config, 2 = governance veto."""

    def __init__(self, message: str, *, exit_code: int = 1) -> None:
        self.exit_code = exit_code
        super().__init__(message)


class ServerError(CliError):
    """The gateway returned the structured error envelope."""

    def __init__(self, status: int, code: str, message: str) -> None:
        self.status = status
        self.code = code
        hint = ""
        if status == 401:
            hint = " — run `dmt auth login` or set DMT_API_KEY"
        elif status == 429:
            hint = " — rate limited; retry shortly"
        super().__init__(f"{status} {code}: {message}{hint}")


@dataclass(frozen=True)
class StreamEvent:
    """One council SSE event with its decoded JSON payload."""

    kind: str
    payload: dict[str, Any]


class CouncilClient:
    """Thin, governed client for the council chat + chat-persistence surface."""

    def __init__(
        self,
        config: CliConfig,
        *,
        transport: httpx.BaseTransport | None = None,
        token_provider: Callable[[], str | None] | None = None,
    ) -> None:
        self._config = config
        self._token_provider = token_provider
        self._http = httpx.Client(
            base_url=config.base_url,
            timeout=httpx.Timeout(config.timeout_s),
            transport=transport,
            headers={"Accept": "application/json"},
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> CouncilClient:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # --- auth -----------------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        token = self._config.access_token
        if token is None and self._token_provider is not None:
            token = self._token_provider()
        if token:
            return {"Authorization": f"Bearer {token}"}
        if self._config.api_key:
            return {"X-API-Key": self._config.api_key}
        return {}

    # --- transport --------------------------------------------------------------

    def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        try:
            response = self._http.request(method, path, headers=self._headers(), **kwargs)
        except httpx.ConnectError as exc:
            raise CliError(
                f"cannot reach the DMT gateway at {self._config.base_url} ({exc})"
            ) from exc
        except httpx.TimeoutException as exc:
            raise CliError(f"request to {path} timed out ({self._config.timeout_s}s)") from exc
        except httpx.HTTPError as exc:
            # ReadError & co: the connection dropped mid-exchange (e.g. a tunnel
            # or the gateway restarting) — transient, safe to retry.
            raise CliError(f"connection to the gateway dropped ({exc}) — retry") from exc
        if response.status_code >= 400:
            raise self._server_error(response)
        return response

    @staticmethod
    def _server_error(response: httpx.Response) -> ServerError:
        try:
            envelope = response.json().get("error", {})
            code = str(envelope.get("code", "error"))
            message = str(envelope.get("message", response.text[:200]))
        except (ValueError, AttributeError):
            code, message = "http_error", response.text[:200]
        # A 404 on the council surface means the gateway is up but has no agents
        # dir configured (or is the wrong service) — say so, don't dump a raw 404.
        if response.status_code == 404 and "/council/" in str(response.url):
            message = (
                "this gateway has no council configured (no agents dir). "
                "Check --url / DMT_BASE_URL — the default is the public demo "
                "gateway; a local/tunneled one is an explicit override"
            )
            code = "council_not_configured"
        return ServerError(response.status_code, code, message)

    # --- council surface ---------------------------------------------------------

    def health(self) -> dict[str, Any]:
        return self._request("GET", "/health").json()

    def roster(self) -> list[dict[str, Any]]:
        payload = self._request("GET", "/v1/council/agents").json()
        return list(payload.get("data", []))

    def chat(
        self,
        *,
        messages: list[dict[str, str]],
        agents: list[str],
        conversation_id: str | None,
        stream: bool,
        deliberate: bool = False,
        delegate: bool = False,
        effort: str | None = None,
        user_context: str = "",
    ) -> Iterator[StreamEvent]:
        """Run one governed council turn.

        Streaming yields the SSE events as they arrive; unary mode yields a single
        ``message_done`` event carrying the full response, so callers share one
        event-driven code path.
        """
        body: dict[str, Any] = {
            "messages": messages,
            "agents": agents,
            "model": self._config.model,
            "stream": stream,
            "deliberate": deliberate,
            "delegate": delegate,
            "user_context": user_context,
        }
        if conversation_id:
            body["conversation_id"] = conversation_id
        if effort:
            body["effort"] = effort
        if not stream:
            response = self._request("POST", "/v1/council/chat", json=body)
            yield StreamEvent("message_done", response.json())
            return
        yield from self._stream_chat(body)

    def _stream_chat(self, body: dict[str, Any]) -> Iterator[StreamEvent]:
        parser = SseParser()
        try:
            with self._http.stream(
                "POST", "/v1/council/chat", json=body, headers=self._headers()
            ) as response:
                if response.status_code >= 400:
                    response.read()
                    raise self._server_error(response)
                for chunk in response.iter_text():
                    for event in parser.feed(chunk):
                        yield StreamEvent(event.event, json.loads(event.data))
        except httpx.ConnectError as exc:
            raise CliError(
                f"cannot reach the DMT gateway at {self._config.base_url} ({exc})"
            ) from exc
        except httpx.TimeoutException as exc:
            raise CliError("the council turn timed out — narrow the roster or retry") from exc
        except httpx.HTTPError as exc:
            raise CliError(f"the stream dropped mid-turn ({exc}) — retry") from exc
        for event in parser.close():
            yield StreamEvent(event.event, json.loads(event.data))

    # --- chat persistence (portability) ------------------------------------------

    def list_chats(self) -> list[dict[str, Any]]:
        return self._request("GET", "/v1/chats").json()

    def upsert_chat(
        self,
        conv_id: str,
        *,
        title: str,
        messages: list[dict[str, Any]],
        project_id: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"title": title, "messages": messages}
        if project_id:
            body["project_id"] = project_id
        return self._request("PUT", f"/v1/chats/{conv_id}", json=body).json()

    def delete_chat(self, conv_id: str) -> None:
        self._request("DELETE", f"/v1/chats/{conv_id}")
