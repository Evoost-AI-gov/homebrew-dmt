"""Splash banner for the DMT Council CLI.

A clean block-letter DMT monogram (red, the department's identity colour) with
the bilingual mark beside it. Shown once on REPL entry; never in
``--json``/one-shot/piped mode, where stdout stays machine-clean. ANSI-coloured
via rich markup so it renders on a real terminal and strips to plain text on a
pipe/test sink.
"""

from __future__ import annotations

# Block-letter DMT monogram. Kept compact so it sits beside the bilingual mark
# on an 80-col terminal. Each line is rich markup (red blocks).
# Block-letter DMT monogram in full blocks only (no box-drawing corners) —
# every glyph is single-width, so all rows share one geometry and the left
# edges can never drift. Two-space letter gap; trailing pads are invisible.
_MONOGRAM = [
    "[red]██████   ███   ███  ████████[/]",
    "[red]██   ██  ████ ████     ██   [/]",
    "[red]██   ██  ██ ███ ██     ██   [/]",
    "[red]██   ██  ██  █  ██     ██   [/]",
    "[red]██████   ██     ██     ██   [/]",
]


def falcon_lines() -> list[str]:
    """The DMT monogram as rich-markup lines (kept under the historical name)."""
    return list(_MONOGRAM)
