"""Terminal rendering for council turns — the governance contract, visible.

Two backends share one interface:

- ``RichRenderer`` — the default when the ``rich`` library (``dmt-ai-services[cli]``
  extra) is installed and colour is on: Codex-style rounded panel for the user's
  prompt, live-rendered markdown per agent, a spinner while the council
  deliberates, governance badges (confidence / abstention / sources) under each
  reply, and tables for roster/chat listings.
- ``PlainRenderer`` — ANSI/plain-text fallback for ``--no-color``, pipes, tests
  or a lean install without the cli extra.

Governance is part of the UX in both: a veto is a hard red banner (and maps to
process exit code 2 upstream), and every turn ends with a cost/orchestration
footer (tokens · agents · elapsed · conversation id) for audit correlation.
"""

from __future__ import annotations

import os
import sys
import time
from typing import Any, TextIO

try:  # The rich UX is an optional cli-extra dependency; the gateway stays lean.
    from rich import box
    from rich.console import Console
    from rich.live import Live
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.spinner import Spinner
    from rich.table import Table
    from rich.text import Text

    _HAS_RICH = True
except ImportError:  # pragma: no cover - exercised on lean installs
    _HAS_RICH = False

_RESET = "\x1b[0m"
_BOLD = "\x1b[1m"
_DIM = "\x1b[2m"
_ANSI_PALETTE = ["\x1b[36m", "\x1b[35m", "\x1b[34m", "\x1b[33m", "\x1b[32m", "\x1b[95m"]
_CONFIDENCE_ANSI = {"high": "\x1b[32m", "medium": "\x1b[33m", "low": "\x1b[31m"}

_RICH_PALETTE = ["cyan", "magenta", "blue", "yellow", "green", "bright_magenta"]
_CONFIDENCE_STYLE = {"high": "green", "medium": "yellow", "low": "red"}


def _short_name(agent_id: str) -> str:
    """'biz-valuation-expert' -> 'valuation-expert' for compact labels."""
    for prefix in ("biz-", "agent-"):
        if agent_id.startswith(prefix):
            return agent_id[len(prefix) :]
    return agent_id


def _badges(message: dict[str, Any]) -> list[tuple[str, str]]:
    """Governance badges for one message as (text, role) pairs.

    Roles: high|medium|low (confidence), abstain, dim (source/evidence counts).
    """
    badges: list[tuple[str, str]] = []
    confidence = message.get("confidence")
    if confidence:
        badges.append((f"confidence: {confidence}", str(confidence)))
    if message.get("abstained"):
        badges.append(("abstained", "abstain"))
    sources = message.get("sources") or []
    if sources:
        badges.append((f"sources: {len(sources)}", "dim"))
    evidence = message.get("evidence") or []
    if evidence:
        badges.append((f"evidence: {len(evidence)}", "dim"))
    return badges


def _footer_parts(
    meta: dict[str, Any], conversation_id: str | None, elapsed: float | None
) -> list[str]:
    parts: list[str] = []
    tokens = meta.get("total_tokens")
    if tokens is not None:  # show 0 too — the stream emits 0s for fast turns
        parts.append(f"{tokens:,} tokens")
    participants = meta.get("participants")
    if participants:
        parts.append(f"{len(participants)} agent(s)")
    if elapsed is not None:
        parts.append(f"{elapsed:.1f}s")
    if conversation_id:
        parts.append(f"conversation {conversation_id}")
    return parts


class Renderer:
    """Shared backend interface (session + REPL talk to this, never to ANSI/rich
    directly). ``color=False`` must always produce machine-safe plain text."""

    def __init__(self, *, color: bool = True, out: TextIO | None = None) -> None:
        self._color = color
        self._out = out or sys.stdout
        self._turn_t0: float | None = None

    # --- turn lifecycle --------------------------------------------------------

    def turn_started(self, agents: list[str]) -> None:
        self._turn_t0 = time.monotonic()

    def user_prompt(self, text: str) -> None:
        """Echo the user's question (Codex-style) before the council answers."""

    def agent_started(self, agent_id: str, *, synthesis: bool = False) -> None:
        pass

    def token(self, agent_id: str, delta: str) -> None:
        pass

    def message(self, message: dict[str, Any], *, synthesis: bool = False) -> None:
        pass

    def veto(self, gate: str, reason: str) -> None:
        pass

    def synthesis_done(self, meta: dict[str, Any], conversation_id: str | None) -> None:
        pass

    def end_turn(self) -> None:
        """Guaranteed cleanup after a turn (even on Ctrl-C): stop live regions."""

    # --- REPL furniture ----------------------------------------------------------

    def prompt(self) -> str:
        """Read one user input line with the styled prompt."""
        return input("\ndmt> ")

    def status_line(self, text: str) -> None:
        """Persistent one-line status (model · roster · session tokens)."""

    def multi_select(self, title: str, options: list[str]) -> list[int] | None:
        """Interactive multi-select (space toggles, Enter confirms). Returns the
        chosen indices, None on cancel / non-interactive."""
        return None

    def table(self, headers: list[str], rows: list[list[str]], *, title: str | None = None) -> None:
        """Render a listing (roster, chats)."""

    def select(self, title: str, options: list[str]) -> int | None:
        """Interactive single-select. Returns the chosen index, None on cancel.

        The default (no interaction available) returns None — the caller falls
        back to free text. Only meaningful on a real terminal."""
        return None

    def error(self, message: str) -> None:
        pass

    def info(self, message: str) -> None:
        pass

    def banner(self, art: list[str], *, title: str, subtitle: str, status: str) -> None:
        """Entry splash: emblem art + bilingual mark + a status strip."""

    # --- helpers -----------------------------------------------------------------

    def _elapsed(self) -> float | None:
        if self._turn_t0 is None:
            return None
        return time.monotonic() - self._turn_t0


class PlainRenderer(Renderer):
    """ANSI/plain-text fallback — the original minimal rendering."""

    def __init__(self, *, color: bool = True, out: TextIO | None = None) -> None:
        super().__init__(color=color, out=out)
        self._agent_colors: dict[str, str] = {}
        self._streaming_agent: str | None = None
        # ANSI only on a real terminal: a redirected/piped stdout (or an injected
        # StringIO in tests) must stay machine-clean even when colour is on.
        self._tty = bool(getattr(self._out, "isatty", lambda: False)())

    def _style(self, text: str, *codes: str) -> str:
        if not self._color or not codes or not self._tty:
            return text
        return "".join(codes) + text + _RESET

    def _agent_color(self, agent_id: str) -> str:
        if agent_id not in self._agent_colors:
            self._agent_colors[agent_id] = _ANSI_PALETTE[
                len(self._agent_colors) % len(_ANSI_PALETTE)
            ]
        return self._agent_colors[agent_id]

    def turn_started(self, agents: list[str]) -> None:
        super().turn_started(agents)
        names = ", ".join(_short_name(a) for a in agents)
        self._write(self._style(f"◆ council turn — {names}", _DIM))

    def user_prompt(self, text: str) -> None:
        self._write(self._style(f"you: {text}", _DIM))

    def agent_started(self, agent_id: str, *, synthesis: bool = False) -> None:
        self._streaming_agent = agent_id
        label = _short_name(agent_id) + (" — synthesis" if synthesis else "")
        color = "\x1b[32m" if synthesis else self._agent_color(agent_id)
        self._write("\n" + self._style(f"▶ {label}", _BOLD, color))
        self._write(" ", end="")  # no trailing newline before the streamed body

    def token(self, agent_id: str, delta: str) -> None:
        if agent_id != self._streaming_agent:
            self.agent_started(agent_id)
        self._write(delta, end="")

    def message(self, message: dict[str, Any], *, synthesis: bool = False) -> None:
        # Unary mode: no token events streamed, so render the body itself.
        content = str(message.get("content", ""))
        if content and not self._streaming_agent:
            agent_id = str(message.get("agent_id", ""))
            label = _short_name(agent_id) + (" — synthesis" if synthesis else "")
            color = "\x1b[32m" if synthesis else self._agent_color(agent_id)
            self._write("\n" + self._style(f"▶ {label}", _BOLD, color))
            self._write(content)
        marks: list[str] = []
        if synthesis:
            marks.append(self._style("synthesis", _DIM))
        for text, role in _badges(message):
            if role in _CONFIDENCE_ANSI:
                marks.append(self._style(text, _CONFIDENCE_ANSI[role]))
            elif role == "abstain":
                marks.append(self._style(text, "\x1b[33m"))
            else:
                marks.append(self._style(text, _DIM))
        if marks:
            self._write("\n" + self._style("  " + " · ".join(marks), _DIM))

    def veto(self, gate: str, reason: str) -> None:
        banner = f"⛔ GOVERNANCE VETO — {gate}: {reason}"
        self._write("\n" + self._style(banner, _BOLD, "\x1b[31m"))

    def synthesis_done(self, meta: dict[str, Any], conversation_id: str | None) -> None:
        parts = _footer_parts(meta, conversation_id, self._elapsed())
        if parts:
            self._write("\n" + self._style("─ " + " · ".join(parts), _DIM))

    def table(self, headers: list[str], rows: list[list[str]], *, title: str | None = None) -> None:
        if title:
            self._write(self._style(title, _BOLD))
        self._write(self._style("  ".join(headers), _BOLD, _DIM))
        for row in rows:
            self._write("  ".join(str(c) for c in row))

    def error(self, message: str) -> None:
        self._write("\n" + self._style(f"✗ {message}", "\x1b[31m"))

    def status_line(self, text: str) -> None:
        self._write(self._style(text, _DIM))

    def info(self, message: str) -> None:
        self._write(self._style(message, _DIM))

    def banner(self, art: list[str], *, title: str, subtitle: str, status: str) -> None:
        # Plain fallback: strip the rich colour markup and draw the monogram as
        # text — the block letters are legible without colour, so the plain
        # banner is still recognisably DMT (just not red).
        import re

        plain = [re.sub(r"\[/?[a-z ]+\]|\[/\]", "", line).rstrip() for line in art]
        self._write("")
        for line in plain:
            self._write(line)
        self._write("")
        self._write(self._style(title, _BOLD))
        self._write(self._style(subtitle, _DIM))
        self._write(self._style(status, _DIM))

    def _write(self, text: str, *, end: str = "\n") -> None:
        self._out.write(text + end)
        self._out.flush()


class RichRenderer(Renderer):
    """Codex-style rich UX: boxed prompt echo, live markdown, spinner, badges."""

    def __init__(self, *, color: bool = True, out: TextIO | None = None) -> None:
        super().__init__(color=color, out=out)
        # No force_terminal: on a non-TTY (pipe, test StringIO) rich strips
        # styling itself, so this backend degrades cleanly.
        self._console = Console(file=self._out, highlight=False)
        self._agent_styles: dict[str, str] = {}
        self._live: Live | None = None
        self._stream_agent: str | None = None
        self._buf = ""

    def _agent_style(self, agent_id: str) -> str:
        if agent_id not in self._agent_styles:
            self._agent_styles[agent_id] = _RICH_PALETTE[
                len(self._agent_styles) % len(_RICH_PALETTE)
            ]
        return self._agent_styles[agent_id]

    # --- turn lifecycle --------------------------------------------------------

    def turn_started(self, agents: list[str]) -> None:
        super().turn_started(agents)
        names = ", ".join(_short_name(a) for a in agents)
        self._console.print(f"[dim]◆ council turn — {names}[/]")

    def user_prompt(self, text: str) -> None:
        self._console.print(
            Panel(
                Text(text),
                title="[dim]you[/]",
                title_align="left",
                border_style="bright_black",
                box=box.ROUNDED,
                padding=(0, 1),
            )
        )

    def agent_started(self, agent_id: str, *, synthesis: bool = False) -> None:
        self._end_live()
        self._stream_agent = agent_id
        self._buf = ""
        style = "green" if synthesis else self._agent_style(agent_id)
        label = _short_name(agent_id) + (" — synthesis" if synthesis else "")
        self._console.print(f"\n[bold {style}]▶ {label}[/]")
        self._live = Live(self._thinking(), console=self._console, refresh_per_second=12)
        self._live.start()

    def token(self, agent_id: str, delta: str) -> None:
        if agent_id != self._stream_agent:
            self.agent_started(agent_id)
        self._buf += delta
        if self._live is not None:
            self._live.update(Markdown(self._buf))

    def message(self, message: dict[str, Any], *, synthesis: bool = False) -> None:
        agent_id = str(message.get("agent_id", ""))
        content = str(message.get("content", ""))
        if content and not self._buf:
            # Unary mode: nothing streamed, so render the full reply now.
            style = "green" if synthesis else self._agent_style(agent_id)
            label = _short_name(agent_id) + (" — synthesis" if synthesis else "")
            self._console.print(f"\n[bold {style}]▶ {label}[/]")
            self._console.print(Markdown(content))
        self._end_live()
        badges = _badges(message)
        if badges:
            line = Text("  ")
            for i, (text, role) in enumerate(badges):
                if i:
                    line.append("  ·  ", style="dim")
                line.append(text, style=self._badge_style(role))
            self._console.print(line)

    @staticmethod
    def _badge_style(role: str) -> str:
        if role in _CONFIDENCE_STYLE:
            return _CONFIDENCE_STYLE[role]
        if role == "abstain":
            return "bold yellow"
        return "dim"

    def veto(self, gate: str, reason: str) -> None:
        self._end_live()
        self._console.print(
            Panel(
                f"[bold red]⛔ GOVERNANCE VETO — {gate}[/]\n[red]{reason}[/]",
                border_style="red",
                box=box.HEAVY,
            )
        )

    def synthesis_done(self, meta: dict[str, Any], conversation_id: str | None) -> None:
        self._end_live()
        parts = _footer_parts(meta, conversation_id, self._elapsed())
        if parts:
            self._console.print("\n[dim]─ " + " · ".join(parts) + "[/]")

    def end_turn(self) -> None:
        self._end_live()

    # --- REPL furniture ----------------------------------------------------------

    def prompt(self) -> str:
        """Codex-style input: multi-line (Alt+Enter), persistent history, paste."""
        from app.cli.input import InputReader

        if not hasattr(self, "_reader"):
            interactive = self._color and sys.stdin.isatty() and self._out_is_tty()
            self._reader = InputReader(history_path=self._history_path(), interactive=interactive)
        result = self._reader.read("\ndmt ❯ ")
        if result is None:  # Ctrl-D on empty buffer -> EOF
            raise EOFError
        return result

    @staticmethod
    def _history_path():
        from pathlib import Path

        state = os.environ.get("DMT_STATE_DIR")
        base = Path(state) if state else Path.home() / ".local" / "state" / "dmt"
        return base / "input_history"

    def table(self, headers: list[str], rows: list[list[str]], *, title: str | None = None) -> None:
        # Contained, readable table: a title rule, a header, and a bounded
        # description column that never blows the terminal wide.
        table = Table(
            title=title,
            box=box.SIMPLE_HEAD,
            header_style="bold cyan",
            show_edge=False,
            pad_edge=False,
            title_justify="left",
        )
        widths = {"agent": 34, "kind": 9, "lens": 10, "description": 70}
        for header in headers:
            table.add_column(
                header,
                width=widths.get(header),
                overflow="ellipsis",
                no_wrap=header != "description",
            )
        for row in rows:
            table.add_row(*(str(c) for c in row))
        self._console.print(table)

    def select(self, title: str, options: list[str]) -> int | None:
        """Arrow-key menu: ↑/↓ move, Enter selects, Esc/typing dismisses."""
        if not (self._color and sys.stdin.isatty() and self._out_is_tty()):
            return None
        return _rich_select(self._console, title, options)

    def multi_select(self, title: str, options: list[str]) -> list[int] | None:
        """Arrow-key multi-select: space toggles, Enter confirms."""
        if not (self._color and sys.stdin.isatty() and self._out_is_tty()):
            return None
        return _rich_multi_select(self._console, title, options)

    def status_line(self, text: str) -> None:
        if self._color:
            self._console.print(f"[dim]{text}[/]")

    def _out_is_tty(self) -> bool:
        return bool(getattr(self._out, "isatty", lambda: False)())

    def error(self, message: str) -> None:
        self._console.print(f"\n[bold red]✗ {message}[/]")

    def info(self, message: str) -> None:
        self._console.print(f"[dim]{message}[/]")

    def banner(self, art: list[str], *, title: str, subtitle: str, status: str) -> None:
        from rich.columns import Columns

        mark = Text()
        mark.append(title + "\n", style="bold")
        mark.append(subtitle + "\n\n", style="dim")
        mark.append("DMT Council CLI", style="bold red")
        mark.append("  ·  governed chat from the terminal", style="dim")
        self._console.print(Columns([Text.from_markup("\n".join(art)), mark], padding=(0, 3)))
        self._console.print(f"[dim]{status}[/]")

    # --- internals -----------------------------------------------------------------

    @staticmethod
    def _thinking() -> Spinner:
        return Spinner("dots", text=Text("deliberating…", style="dim"), style="cyan")

    def _end_live(self) -> None:
        if self._live is not None:
            self._live.stop()
            self._live = None
        self._stream_agent = None
        self._buf = ""


def _read_key() -> str:
    """Read one keypress from stdin (raw mode), decoding arrows. POSIX-only;
    the caller guards on isatty() first."""
    import termios
    import tty

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
        if ch == "\x1b":  # escape sequence (arrow) or bare Esc
            seq = sys.stdin.read(2)
            return {"[A": "up", "[B": "down"}.get(seq, "esc")
        if ch in ("\r", "\n"):
            return "enter"
        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _rich_select(console, title: str, options: list[str]) -> int | None:
    """Arrow-key select menu. Returns the index, None on Esc/interrupt."""
    if not options:
        return None
    selected = 0

    def frame() -> Text:
        body = Text()
        body.append(title + "\n", style="bold cyan")
        for i, option in enumerate(options):
            marker = "❯" if i == selected else " "
            style = "bold cyan" if i == selected else "dim"
            body.append(f"{marker} {option}\n", style=style)
        body.append("↑/↓ move · Enter select · Esc dismiss", style="dim")
        return body

    n_lines = len(options) + 2
    console.print(frame())
    try:
        while True:
            key = _read_key()
            if key in ("esc", "\x03", "q"):  # Esc, Ctrl-C, q
                break
            if key == "enter":
                _clear(console, n_lines)
                return selected
            if key == "up" and selected > 0:
                selected -= 1
            elif key == "down" and selected < len(options) - 1:
                selected += 1
            else:
                continue
            _clear(console, n_lines)
            console.print(frame())
    except (KeyboardInterrupt, EOFError):
        pass
    _clear(console, n_lines)
    return None


def _clear(console, lines: int) -> None:
    """Erase the last ``lines`` terminal lines so the menu redraws in place."""
    for _ in range(lines):
        console.file.write("\x1b[1A\x1b[2K")  # up one line, clear it
    console.file.flush()


def _rich_multi_select(console, title: str, options: list[str]) -> list[int] | None:
    """Arrow-key multi-select: space toggles a checkbox, Enter confirms."""
    if not options:
        return None
    cursor = 0
    chosen: set[int] = set()

    def frame() -> Text:
        body = Text()
        body.append(title + "\n", style="bold cyan")
        for i, option in enumerate(options):
            mark = "◉" if i in chosen else "○"
            arrow = "❯" if i == cursor else " "
            style = "bold cyan" if i == cursor else "dim"
            body.append(f"{arrow} {mark} {option}\n", style=style)
        body.append("↑/↓ move · space toggle · Enter confirm · Esc dismiss", style="dim")
        return body

    n_lines = len(options) + 2
    console.print(frame())
    try:
        while True:
            key = _read_key()
            if key in ("esc", "\x03", "q"):
                break
            if key == "enter":
                _clear(console, n_lines)
                return sorted(chosen)
            if key == " ":
                chosen ^= {cursor}  # toggle
            elif key == "up" and cursor > 0:
                cursor -= 1
            elif key == "down" and cursor < len(options) - 1:
                cursor += 1
            else:
                continue
            _clear(console, n_lines)
            console.print(frame())
    except (KeyboardInterrupt, EOFError):
        pass
    _clear(console, n_lines)
    return None


def build_renderer(*, color: bool = True, out: TextIO | None = None) -> Renderer:
    """Pick the rich UX when available (cli extra + colour), else plain."""
    if color and _HAS_RICH:
        return RichRenderer(color=color, out=out)
    return PlainRenderer(color=color, out=out)
