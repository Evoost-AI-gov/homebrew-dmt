"""``dmt`` — the enterprise terminal client for the DMT governed council chat.

Usage:
  dmt                        Interactive REPL (claude/codex-style)
  dmt ask "question"         One governed turn, then exit
  dmt auth login             Sign in via the browser (Entra ID) — no API keys
  dmt auth status|logout     Inspect / clear the cached sign-in
  dmt chats                  List conversations in the shared store

Exit codes: 0 ok · 1 error (transport/config/server) · 2 governance veto.
"""

from __future__ import annotations

import argparse
import sys

from app.cli import __version__
from app.cli.auth import AuthError, acquire_token_silent, login, logout, status
from app.cli.client import CliError, CouncilClient
from app.cli.config import ConfigError, resolve
from app.cli.repl import Repl
from app.cli.session import ChatSession

_COMMANDS = ("ask", "chat", "auth", "chats")


def _global_args(parser: argparse.ArgumentParser, *, suppress: bool = False) -> None:
    """Connection flags. On subparsers (suppress=True) defaults are SUPPRESS so
    an absent subcommand flag never clobbers a value parsed at the top level."""
    default = argparse.SUPPRESS if suppress else None
    parser.add_argument(
        "--url",
        dest="base_url",
        default=default,
        help="gateway base URL (env DMT_BASE_URL; e.g. an SSH tunnel to the demo VM)",
    )
    parser.add_argument("--profile", default=default, help="config profile name (env DMT_PROFILE)")
    parser.add_argument(
        "--model", default=default, help="logical model (env DMT_MODEL, default dmt-brain)"
    )
    parser.add_argument(
        "--api-key",
        default=default,
        help="service API key (env DMT_API_KEY) — only when not signed in with Entra",
    )
    parser.add_argument(
        "--token",
        dest="access_token",
        default=default,
        help="explicit bearer token (env DMT_ACCESS_TOKEN); overrides the cached Entra sign-in",
    )
    parser.add_argument(
        "--timeout", type=float, dest="timeout_s", default=default, help="request timeout (s)"
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dmt",
        description="DMT Council CLI — the governed chat, in your terminal.",
    )
    parser.add_argument("--version", action="version", version=f"dmt {__version__}")
    _global_args(parser)
    parser.add_argument("--no-color", action="store_true", help="disable ANSI styling")
    parser.add_argument(
        "--no-transcript", action="store_true", help="do not keep a local JSONL transcript"
    )

    sub = parser.add_subparsers(dest="command")

    ask = sub.add_parser("ask", help="one governed turn, then exit")
    ask.add_argument("question", nargs="+", help="the question (joined with spaces)")
    _global_args(ask, suppress=True)
    _chat_args(ask)

    chat = sub.add_parser("chat", help="interactive REPL (default command)")
    _global_args(chat, suppress=True)
    _chat_args(chat)

    auth = sub.add_parser("auth", help="Entra sign-in (browser), status, logout")
    auth_sub = auth.add_subparsers(dest="auth_command", required=True)
    auth_login = auth_sub.add_parser("login", help="sign in via the browser")
    auth_login.add_argument(
        "--device-code",
        action="store_true",
        help="headless flow: code at microsoft.com/devicelogin",
    )
    auth_sub.add_parser("status", help="show the cached sign-in")
    auth_sub.add_parser("logout", help="clear the cached sign-in")

    sub.add_parser("chats", help="list conversations in the shared store")
    return parser


def _chat_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--agents", help="comma-separated roster (default: the Director)")
    parser.add_argument("--delegate", action="store_true", help="let the Director pick the experts")
    parser.add_argument(
        "--deliberate",
        action="store_true",
        help="one Director-mediated deliberation round (costlier)",
    )
    parser.add_argument(
        "--effort", choices=["instant", "medium", "high"], help="thinking-effort token budget"
    )
    parser.add_argument("--no-stream", action="store_true", help="wait for the full reply")
    parser.add_argument("--json", action="store_true", help="NDJSON events on stdout (scripting)")
    parser.add_argument("--conversation", dest="conversation_id", help="continue a conversation id")
    parser.add_argument(
        "--context",
        dest="user_context",
        default="",
        help="work-context snapshot (advisory; no record-level data)",
    )
    # Also accepted after the subcommand (claude/codex-style); SUPPRESS so an
    # absent subcommand flag never clobbers the global one in the namespace.
    parser.add_argument(
        "--no-color",
        action="store_true",
        default=argparse.SUPPRESS,
        help="disable ANSI styling",
    )
    parser.add_argument(
        "--no-transcript",
        action="store_true",
        default=argparse.SUPPRESS,
        help="do not keep a local JSONL transcript",
    )


def _resolve(args: argparse.Namespace):
    try:
        return resolve(
            base_url=getattr(args, "base_url", None),
            model=getattr(args, "model", None),
            api_key=getattr(args, "api_key", None),
            access_token=getattr(args, "access_token", None),
            profile=getattr(args, "profile", None),
            timeout_s=getattr(args, "timeout_s", None),
            color=False if getattr(args, "no_color", False) else None,
            transcript=False if getattr(args, "no_transcript", False) else None,
        )
    except ConfigError as exc:
        print(f"dmt: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc


def _cmd_auth(args: argparse.Namespace) -> int:
    try:
        if args.auth_command == "login":
            result = login(device_code=args.device_code)
            print(f"signed in as {result.username} (tenant {result.tenant_id})")
            return 0
        if args.auth_command == "logout":
            print("signed out" if logout() else "not signed in")
            return 0
        info = status()
        if not info.signed_in:
            print("not signed in — `dmt auth login`")
            return 1
        import time

        expiry = ""
        if info.expires_on:
            remaining = info.expires_on - int(time.time())
            expiry = " (expired — will refresh on next use)" if remaining <= 0 else ""
        print(
            f"signed in as {info.username}\ntenant  {info.tenant_id}\n"
            f"client  {info.client_id}\ncache   {info.source}{expiry}"
        )
        return 0
    except AuthError as exc:
        print(f"dmt auth: {exc}", file=sys.stderr)
        return 1


def _token_provider(config) -> object:
    """Documented auth precedence, one place: explicit --token/DMT_ACCESS_TOKEN →
    cached Entra sign-in (silent refresh) → --api-key/DMT_API_KEY. An explicit
    token short-circuits; otherwise the cached workforce identity wins so a stale
    DMT_API_KEY in the environment can never shadow `dmt auth login`."""
    if config.access_token:
        return None
    return lambda: acquire_token_silent(config)


def _make_session(args: argparse.Namespace) -> tuple[ChatSession, CouncilClient]:
    config = _resolve(args)
    client = CouncilClient(config, token_provider=_token_provider(config))
    agents = (
        [a.strip() for a in args.agents.split(",") if a.strip()]
        if getattr(args, "agents", None)
        else None
    )
    session = ChatSession(
        config,
        client,
        conversation_id=getattr(args, "conversation_id", None),
        agents=agents,
        effort=getattr(args, "effort", None),
        delegate=getattr(args, "delegate", False),
        deliberate=getattr(args, "deliberate", False),
        user_context=getattr(args, "user_context", ""),
        json_mode=getattr(args, "json", False),
        stream=not getattr(args, "no_stream", False),
    )
    return session, client


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    # Bare `dmt` IS the chat REPL: `dmt --no-stream` == `dmt chat --no-stream`.
    if (
        argv
        and not any(a in _COMMANDS for a in argv)
        and argv[0] not in ("-h", "--help", "--version")
    ):
        argv = ["chat", *argv]
    args = _parser().parse_args(argv)
    try:
        if args.command == "auth":
            return _cmd_auth(args)
        if args.command == "chats":
            config = _resolve(args)
            with CouncilClient(config, token_provider=_token_provider(config)) as client:
                chats = client.list_chats()
            if args.__dict__.get("json"):
                import json

                print(json.dumps(chats, ensure_ascii=False, indent=2))
            elif not chats:
                print("the shared store has no conversations")
            else:
                for c in chats:
                    print(f"{c['id']}  {c.get('updated_at', '')}  {c.get('title', '')}")
            return 0
        if args.command == "ask":
            session, client = _make_session(args)
            with client:
                return session.ask(" ".join(args.question))
        # Default: interactive REPL (`dmt` or `dmt chat`).
        session, client = _make_session(args)
        with client:
            return Repl(session, client).run()
    except CliError as exc:
        print(f"dmt: {exc}", file=sys.stderr)
        return exc.exit_code


if __name__ == "__main__":
    raise SystemExit(main())
