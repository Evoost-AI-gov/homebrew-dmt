"""Interactive REPL — the claude/codex-style terminal experience.

Slash commands manage the session; everything else is a governed council turn.
Readline gives history + editing when available; Ctrl-C cancels the current
turn (the partial reply is discarded, the user turn stays), Ctrl-D exits.
"""

from __future__ import annotations

from typing import TextIO

from app.cli.banner import falcon_lines
from app.cli.client import CliError, CouncilClient
from app.cli.session import ChatSession
from app.cli.suggest import FREE_TEXT, suggest

BANNER = """DMT Council CLI — governed chat from the terminal.
Type your question, or /help. Ctrl-C cancels a turn, Ctrl-D exits."""

HELP = """\
Conversation
  /agents                  List the governed roster (canon + approved custom)
  /use [id…]               Set the roster (max 4); no args = interactive multi-select
  /delegate [on|off]       Let the Director pick the experts itself
  /deliberate [on|off]     One Director-mediated deliberation round (costlier)
  /effort <instant|medium|high|off>   Thinking-effort token budget
  /new                     Start a fresh conversation
Portability (web <-> terminal)
  /sync [title]            Push this conversation to the shared store
  /chats                   List conversations in the shared store
  /resume <id>             Continue a conversation from the store
  /export [path]           Write the transcript (JSONL) path or a copy
Session
  /status                  Endpoint, auth, model, roster, conversation
  /help [command]          This help, or detail on one command
  /quit                    Exit

Keys: Enter submit · Alt+Enter newline · ↑/↓ history · Ctrl-R search history
      Ctrl-C cancel turn / clear buffer · Ctrl-D exit

Install on macOS: /help install"""

# macOS install guide, shown by `/help install`. The CLI ships as the `dmt`
# console script inside the dmt-ai-services package (cli extra = Entra login +
# the rich UX). Copy-paste block, copy-safe.
HELP_INSTALL = """\
Install the DMT Council CLI on macOS

  Prereqs: Python 3.13+ (uv or pyenv) and access to Evoost-AI-gov/dmt-ai-services.

  1. Get the source
     git clone git@github.com:Evoost-AI-gov/dmt-ai-services.git
     cd dmt-ai-services

  2. Install (editable, with the CLI extra)
     uv venv && uv pip install -e ".[cli]"
     # or: python -m venv .venv && .venv/bin/pip install -e ".[cli]"

  3. Put `dmt` on your PATH (choose one)
     uv tool install -e ".[cli]" --from .        # isolated, on PATH
     # or use the venv's binary directly:
     ln -sf \"$PWD/.venv/bin/dmt\" /usr/local/bin/dmt   # needs sudo on some Macs

  4. Sign in (browser, no API keys)
     dmt auth login          # Entra ID public client; --device-code for headless

  5. Point at a gateway
     dmt --url http://127.0.0.1:8000            # local
     ssh -L 18001:127.0.0.1:8001 <demo-vm> &    # demo via SSH tunnel
     dmt --url http://127.0.0.1:18001

  Upgrade: cd dmt-ai-services && git pull && uv pip install -e ".[cli]"
  Verify:  dmt --version && dmt auth status"""

# Per-command one-liners for `/help <cmd>` and the navigable help menu.
_HELP_DETAIL = {
    "agents": "List every governed agent the council can field (canon + approved custom).",
    "use": "Set the active roster. No args opens a multi-select picker (space toggles, up to 4).",
    "delegate": "When on and no roster is set, the Director routes the query to the right experts.",
    "deliberate": "One Director-mediated deliberation round across experts before synthesis.",
    "effort": "Thinking-effort token budget: instant (fast/concise) · medium · high (deep).",
    "new": "Abandon the current conversation id and start a fresh one.",
    "sync": "Push this conversation to the shared /v1/chats store so the web assistant sees it.",
    "chats": "List the conversations in the shared store (web <-> terminal).",
    "resume": "Pull a stored conversation into the terminal by id (see /chats).",
    "export": "Print (or copy) this conversation's local JSONL transcript.",
    "status": "Show endpoint, auth fingerprint, model, roster, conversation, transcript path.",
    "help": "Show help. /help <command> for detail on one command.",
    "quit": "Exit the REPL.",
    "install": "macOS install guide — /help install for the copy-paste steps.",
}


def _toggle(args: list[str], current: bool) -> bool:
    if not args:
        return not current
    return args[0].lower() in ("on", "true", "1", "yes")


class Repl:
    def __init__(
        self, session: ChatSession, client: CouncilClient, *, out: TextIO | None = None
    ) -> None:
        self.session = session
        self.client = client
        self.renderer = session.renderer
        self._out = out

    def run(self) -> int:
        self._enable_readline()
        self._banner()
        exit_code = 0
        while True:
            try:
                line = self.renderer.prompt().strip()
            except EOFError:
                self.renderer.info("")
                break
            except KeyboardInterrupt:
                self.renderer.info("^C")
                continue
            if not line:
                continue
            self._status_line()
            if line.startswith("/"):
                try:
                    if self._command(line) is False:
                        break
                except CliError as exc:
                    self.renderer.error(str(exc))
                    exit_code = exc.exit_code
            else:
                try:
                    exit_code = max(exit_code, self.session.ask(line))
                except KeyboardInterrupt:
                    self.renderer.info("\n— turn cancelled")
                else:
                    picked = self._suggest_followup()
                    if picked:
                        try:
                            exit_code = max(exit_code, self.session.ask(picked))
                        except KeyboardInterrupt:
                            self.renderer.info("\n— turn cancelled")
        return exit_code

    # --- entry banner --------------------------------------------------------------

    def _status_line(self) -> None:
        """One-line live status before each prompt (model · roster · tokens)."""
        s = self.session
        tokens = (s.last_final.get("meta") or {}).get("total_tokens")
        roster = ", ".join(a.replace("biz-", "") for a in s.agents)
        parts = [s.config.model, roster or "director"]
        if s.delegate:
            parts.append("delegate")
        if tokens:
            parts.append(f"{tokens:,} tok")
        self.renderer.status_line("  ·  ".join(parts))

    def _suggest_followup(self) -> str | None:
        """Offer contextual next-step chips (arrow keys). Returns the chosen
        prompt to chain, or None when dismissed / free text."""
        if self.session.json_mode:
            return None
        final = self.session.last_final
        chips = suggest(final)
        if len(chips) <= 1:  # only the free-text opt-out
            return None
        idx = self.renderer.select("What next?", chips)
        if idx is None or chips[idx] == FREE_TEXT:
            return None
        return chips[idx]

    def _banner(self) -> None:
        """8-bit DMT falcon + bilingual mark + a one-line status strip."""
        self.renderer.banner(
            falcon_lines(),
            title="DEPARTMENT OF MUNICIPALITIES AND TRANSPORT",
            subtitle="دائرة البلديات والنقل",
            status=(
                f"endpoint {self.session.config.base_url} · auth "
                f"{self.session.config.auth_fingerprint} · conversation "
                f"{self.session.conversation_id}"
            ),
        )
        self.renderer.info(BANNER)

    # --- commands --------------------------------------------------------------

    def _command(self, line: str) -> bool | None:
        parts = line[1:].split()
        cmd, args = parts[0].lower(), parts[1:]
        handler = getattr(self, f"_cmd_{cmd.replace('-', '_')}", None)
        if cmd in ("quit", "exit", "q"):
            return False
        if handler is None:
            self.renderer.error(f"unknown command /{cmd} — /help")
            return None
        handler(args)
        return None

    def _cmd_help(self, args: list[str]) -> None:
        topic = args[0].lstrip("/") if args else ""
        if topic == "install":
            self.renderer.info(HELP_INSTALL)
            return
        if topic and topic in _HELP_DETAIL:
            self.renderer.info(f"/{topic} — {_HELP_DETAIL[topic]}")
            return
        # Navigable help: pick a command to read its detail (rich, TTY only).
        options = [f"/{c}  — {d[:60]}" for c, d in _HELP_DETAIL.items()]
        idx = self.renderer.select("Help — pick a command", options)
        if idx is not None:
            cmd = list(_HELP_DETAIL)[idx]
            self.renderer.info(f"/{cmd} — {_HELP_DETAIL[cmd]}")
            return
        self.renderer.info(HELP)

    def _cmd_status(self, _args: list[str]) -> None:
        s = self.session
        self.renderer.info(
            f"endpoint      {s.config.base_url}\n"
            f"profile       {s.config.profile}\n"
            f"auth          {s.config.auth_fingerprint}\n"
            f"model         {s.config.model}\n"
            f"conversation  {s.conversation_id} ({len(s.messages)} messages)\n"
            f"roster        {', '.join(s.agents)}"
            f"{' · delegate' if s.delegate else ''}"
            f"{' · deliberate' if s.deliberate else ''}\n"
            f"effort        {s.effort or 'default'}\n"
            f"transcript    {s.transcript.path}"
        )

    def _cmd_agents(self, _args: list[str]) -> None:
        roster = self.client.roster()
        rows = [
            [a["agent_id"], a["kind"], ", ".join(a.get("lens", [])), a.get("description", "")[:80]]
            for a in roster
        ]
        self.renderer.table(["agent", "kind", "lens", "description"], rows, title="governed roster")

    def _cmd_use(self, args: list[str]) -> None:
        if not args:
            # Interactive multi-select picker: space toggles experts, Enter
            # confirms (graceful fallback to usage text when not a TTY).
            roster = self.client.roster()
            labels = [f"{a['agent_id']}  — {a.get('description', '')[:50]}" for a in roster]
            picked = self.renderer.multi_select(
                "Active roster (space to add, Enter to confirm, max 4)", labels
            )
            if picked is None:
                # Single-select fallback for narrower terminals, else usage.
                idx = self.renderer.select("Active agent (↑/↓, Enter)", labels)
                if idx is None:
                    self.renderer.error(
                        "usage: /use <agent-id> [id…]  (or pick interactively on a TTY)"
                    )
                    return
                picked = [idx]
            self.session.agents = [roster[i]["agent_id"] for i in picked][:4]
        else:
            self.session.agents = args[:4]
        self.session.delegate = False
        self.renderer.info(f"roster: {', '.join(self.session.agents)}")

    def _cmd_delegate(self, args: list[str]) -> None:
        self.session.delegate = _toggle(args, self.session.delegate)
        state = "on — the Director picks the experts" if self.session.delegate else "off"
        self.renderer.info(f"delegate {state}")

    def _cmd_deliberate(self, args: list[str]) -> None:
        self.session.deliberate = _toggle(args, self.session.deliberate)
        self.renderer.info(f"deliberate {'on' if self.session.deliberate else 'off'}")

    def _cmd_effort(self, args: list[str]) -> None:
        if args and args[0] in ("instant", "medium", "high"):
            self.session.effort = args[0]
        else:
            self.session.effort = None
        self.renderer.info(f"effort: {self.session.effort or 'default'}")

    def _cmd_new(self, _args: list[str]) -> None:
        import uuid

        self.session.conversation_id = uuid.uuid4().hex[:12]
        self.session.messages = []
        from app.cli.transcript import Transcript

        self.session.transcript = Transcript(
            self.session.config.state_dir,
            self.session.conversation_id,
            enabled=self.session.config.transcript,
        )
        self.renderer.info(f"new conversation {self.session.conversation_id}")

    def _cmd_sync(self, args: list[str]) -> None:
        title = " ".join(args) or f"cli {self.session.conversation_id}"
        self.session.sync_up(title=title)
        self.renderer.info(f"synced as '{title}' — open it from the web assistant sidebar")

    def _cmd_chats(self, _args: list[str]) -> None:
        chats = self.client.list_chats()
        if not chats:
            self.renderer.info("the shared store has no conversations")
            return
        rows = [
            [c["id"], c.get("updated_at", ""), c.get("title", ""), str(len(c.get("messages", [])))]
            for c in chats
        ]
        self.renderer.table(["id", "updated", "title", "msgs"], rows, title="shared conversations")

    def _cmd_resume(self, args: list[str]) -> None:
        if not args:
            self.renderer.error("usage: /resume <conversation-id>  (see /chats)")
            return
        chats = {c["id"]: c for c in self.client.list_chats()}
        record = chats.get(args[0])
        if record is None:
            self.renderer.error(f"unknown conversation '{args[0]}' — /chats to list")
            return
        self.session.load_from(record)
        self.renderer.info(
            f"resumed '{record.get('title', args[0])}' — "
            f"{len(self.session.messages)} messages in context"
        )

    def _cmd_export(self, args: list[str]) -> None:
        import shutil
        from pathlib import Path

        src = self.session.transcript.path
        if args:
            dest = Path(args[0]).expanduser()
            shutil.copyfile(src, dest)
            self.renderer.info(f"transcript copied to {dest}")
        else:
            self.renderer.info(f"transcript: {src}")

    @staticmethod
    def _enable_readline() -> None:
        import contextlib

        with contextlib.suppress(ImportError):
            import readline

            commands = [
                "/agents",
                "/chats",
                "/delegate",
                "/deliberate",
                "/effort",
                "/export",
                "/help",
                "/new",
                "/quit",
                "/resume",
                "/status",
                "/sync",
                "/use",
            ]

            def complete(text: str, state: int) -> str | None:
                matches = [c + " " for c in commands if c.startswith(text)]
                return matches[state] if state < len(matches) else None

            readline.set_completer(complete)
            readline.parse_and_bind("tab: complete")
            readline.set_completer_delims(" ")
