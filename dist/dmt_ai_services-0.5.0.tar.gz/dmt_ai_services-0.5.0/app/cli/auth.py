"""Entra ID sign-in for the CLI (``dmt auth login``) — browser flow, no API keys.

Mirrors the ``gh auth login`` / ``az login`` pattern: the CLI is an Entra
**public client** (MSAL ``PublicClientApplication``), the user signs in through
the browser (auth-code + PKCE against a localhost loopback redirect, with
device-code as the headless fallback), and the gateway validates the resulting
bearer JWT exactly like the web SPA's tokens — no API key anywhere.

Token cache lives at ``~/.config/dmt/msal_cache.json`` (0600, never committed);
after the first login the CLI refreshes silently. MSAL is an optional dependency
(``pip install dmt-ai-services[cli]``) so the lean gateway profile stays light.

App-registration note: the flow needs a public-client app with the platform API
scope. The DMT SPA registration works once "Allow public client flows" is
enabled and a ``http://localhost`` redirect (Mobile & desktop platform) is added;
otherwise point ``DMT_ENTRA_CLIENT_ID`` at a dedicated CLI app registration.
"""

from __future__ import annotations

import json
import os
import stat
import time
from contextlib import suppress
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from app.cli.config import CliConfig, config_dir

# Defaults match the DMT platform SPA/API registrations; overridable via env so
# a dedicated CLI app registration slots in without a code change.
_ENV_CLIENT_ID = "DMT_ENTRA_CLIENT_ID"
_ENV_AUTHORITY = "DMT_ENTRA_AUTHORITY"
_ENV_SCOPE = "DMT_ENTRA_SCOPE"
DEFAULT_CLIENT_ID = "1c3019f6-d703-4892-8e89-9c56a24a7be8"  # DMT platform SPA
DEFAULT_AUTHORITY = "https://login.microsoftonline.com/organizations"
DEFAULT_SCOPE = "api://22a5d74d-160b-4221-98c3-a14bf66522da/access_as_user"

CACHE_FILE = "msal_cache.json"


class AuthError(Exception):
    """A sign-in problem (user-facing, exit code 1)."""


@dataclass(frozen=True)
class AuthStatus:
    """Snapshot of the cached sign-in for ``dmt auth status``."""

    signed_in: bool
    username: str = ""
    tenant_id: str = ""
    client_id: str = ""
    expires_on: int = 0
    source: str = ""

    @property
    def expired(self) -> bool:
        return self.expires_on > 0 and self.expires_on <= int(time.time())


def _msal():
    try:
        import msal
    except ImportError as exc:
        raise AuthError(
            "Entra sign-in needs the MSAL extra: pip install 'dmt-ai-services[cli]'"
        ) from exc
    return msal


def cache_path() -> Path:
    return config_dir() / CACHE_FILE


def _load_cache():
    msal = _msal()
    cache = msal.SerializableTokenCache()
    path = cache_path()
    if path.exists():
        # A corrupt cache behaves as signed-out, never crashes the CLI.
        with suppress(OSError, ValueError):
            cache.deserialize(path.read_text(encoding="utf-8"))
    return cache


def _save_cache(cache: Any) -> None:
    if not cache.has_state_changed:
        return
    path = cache_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(cache.serialize(), encoding="utf-8")
    path.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0600 — the cache holds refresh tokens


def _authority() -> str:
    return os.environ.get(_ENV_AUTHORITY) or DEFAULT_AUTHORITY


def _scopes() -> list[str]:
    return [os.environ.get(_ENV_SCOPE) or DEFAULT_SCOPE]


def _client_id() -> str:
    return os.environ.get(_ENV_CLIENT_ID) or DEFAULT_CLIENT_ID


def _app(cache: Any):
    msal = _msal()
    return msal.PublicClientApplication(
        client_id=_client_id(), authority=_authority(), token_cache=cache
    )


def acquire_token_silent(_config: CliConfig) -> str | None:
    """Return a valid cached/refreshed access token, or None when signed out.

    Wired into the client as the token provider so every governed call carries
    the workforce identity without an API key. Never raises — auth failures fall
    through to the API-key path or a 401 with the `dmt auth login` hint.
    """
    try:
        cache = _load_cache()
        app = _app(cache)
        accounts = app.get_accounts()
        if not accounts:
            return None
        result = app.acquire_token_silent(_scopes(), account=accounts[0])
        _save_cache(cache)
        if result and "access_token" in result:
            return str(result["access_token"])
        return None
    except Exception:  # noqa: BLE001 — silent path must never break a turn
        return None


def login(*, device_code: bool = False) -> AuthStatus:
    """Interactive Entra sign-in. Browser (PKCE loopback) by default; device-code
    for headless environments. Returns the resulting status."""
    cache = _load_cache()
    app = _app(cache)

    result: dict[str, Any] | None = None
    if device_code:
        flow = app.initiate_device_flow(scopes=_scopes())
        if "user_code" not in flow:
            raise AuthError(f"cannot start device-code flow: {flow.get('error_description', flow)}")
        print(flow["message"])  # the go-to-URL + code prompt IS the UX
        result = app.acquire_token_by_device_flow(flow)
    else:
        try:
            result = app.acquire_token_interactive(
                scopes=_scopes(), prompt="select_account", port=8400
            )
        except Exception as exc:  # noqa: BLE001 — fall back to device code
            raise AuthError(
                "browser sign-in failed (is the app's http://localhost redirect "
                "registered as a Mobile & desktop platform?). Retry with "
                f"`dmt auth login --device-code`. Detail: {exc}"
            ) from exc

    if not result or "access_token" not in result:
        detail = (result or {}).get("error_description", "sign-in cancelled or failed")
        raise AuthError(str(detail))
    _save_cache(cache)
    return status()


def logout() -> bool:
    """Remove the cached tokens. True when something was removed."""
    path = cache_path()
    if path.exists():
        path.unlink()
        return True
    return False


def status() -> AuthStatus:
    """Read the cached account without touching the network."""
    path = cache_path()
    if not path.exists():
        return AuthStatus(signed_in=False)
    try:
        cache = _load_cache()
        app = _app(cache)
        accounts = app.get_accounts()
        if not accounts:
            return AuthStatus(signed_in=False)
        account = accounts[0]
        # Peek at the cached access token's expiry without decoding the JWT.
        expires_on = 0
        try:
            entries = json.loads(cache.serialize()).get("AccessToken", {})
            if entries:
                expires_on = int(next(iter(entries.values())).get("expires_on", 0))
        except (ValueError, AttributeError, TypeError):
            expires_on = 0
        return AuthStatus(
            signed_in=True,
            username=str(account.get("username", "")),
            tenant_id=str(account.get("realm", "")),
            client_id=_client_id(),
            expires_on=expires_on,
            source=str(path),
        )
    except Exception:  # noqa: BLE001
        return AuthStatus(signed_in=False)
