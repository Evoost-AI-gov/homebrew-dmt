"""Incremental Server-Sent-Events parser (WHATWG SSE wire format, subset).

The council chat streams ``event: <kind>\\ndata: <json>\\n\\n`` frames. This parser
accepts arbitrary chunk boundaries (a frame may be split across reads), supports
multi-line ``data:`` fields and ignores keepalive comment lines. Pure and
dependency-free so it is trivially unit-testable.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SseEvent:
    """One decoded SSE frame."""

    event: str
    data: str


class SseParser:
    """Feed text chunks; get complete events back. Buffers partial frames."""

    def __init__(self) -> None:
        self._buf = ""

    def feed(self, chunk: str) -> list[SseEvent]:
        """Consume a chunk and return every event completed by it."""
        self._buf += chunk
        events: list[SseEvent] = []
        while True:
            boundary = self._buf.find("\n\n")
            if boundary == -1:
                return events
            frame, self._buf = self._buf[:boundary], self._buf[boundary + 2 :]
            event = self._decode(frame)
            if event is not None:
                events.append(event)

    def close(self) -> list[SseEvent]:
        """Flush any trailing frame not terminated by a blank line."""
        frame, self._buf = self._buf, ""
        event = self._decode(frame) if frame.strip() else None
        return [event] if event is not None else []

    @staticmethod
    def _decode(frame: str) -> SseEvent | None:
        event = "message"
        data_lines: list[str] = []
        for line in frame.split("\n"):
            if line.startswith(":"):
                continue  # keepalive comment
            if line.startswith("event:"):
                event = line[len("event:") :].strip()
            elif line.startswith("data:"):
                data_lines.append(line[len("data:") :].lstrip(" "))
        if not data_lines:
            return None
        return SseEvent(event=event, data="\n".join(data_lines))
