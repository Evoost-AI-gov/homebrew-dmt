"""Professional input reader for the DMT Council CLI — codex/claude-grade.

Features (rich path, real TTY only):
- **Multi-line editing**: Alt/Option+Enter inserts a newline; Enter submits.
- **Persistent history** across sessions (~/.local/state/dmt/input_history),
  recalled with ↑/↓.
- **Paste-safe**: a multi-line paste lands as one block, no per-line submits.
- Ctrl-C clears the current buffer, Ctrl-D on an empty buffer exits (EOF).

Plain/non-TTY sinks fall back to a single-line ``input()`` so scripting, tests
and ``--json`` never change behaviour or block.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

_HISTORY_LIMIT = 500


class InputReader:
    """Codex-style input: multi-line, history, paste-aware."""

    def __init__(self, *, history_path: Path, interactive: bool) -> None:
        self._history_path = history_path
        self._interactive = interactive
        self._history: list[str] = []
        if interactive:
            self._load_history()

    # --- public API -----------------------------------------------------------

    def read(self, prompt: str) -> str | None:
        """Read one user submission. Returns None on EOF (Ctrl-D / closed stdin)."""
        if not self._interactive:
            try:
                return input(prompt)
            except EOFError:
                return None
        line = self._read_interactive(prompt)
        if line is not None and line.strip():
            self._push_history(line)
        return line

    # --- interactive path -------------------------------------------------------

    def _read_interactive(self, prompt: str) -> str | None:
        import termios
        import tty

        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        buf: list[str] = []
        hist_idx = len(self._history)  # one past the newest = the live buffer
        sys.stdout.write(prompt)
        sys.stdout.flush()
        try:
            tty.setraw(fd)
            while True:
                ch = os.read(fd, 1).decode("utf-8", errors="replace")
                if ch in ("\r", "\n"):  # Enter — submit
                    sys.stdout.write("\r\n")
                    break
                if ch == "\x1b":  # escape: arrow keys / Alt+Enter
                    seq = os.read(fd, 2).decode("utf-8", errors="replace")
                    if seq in ("[A", "[B"):  # history up / down
                        hist_idx, buf = self._nav_history(hist_idx, seq, buf)
                        self._redraw(prompt, buf)
                        continue
                    if seq.startswith("\r") or seq.startswith("\n") or seq == "":
                        # Alt+Enter (Esc then Enter) -> newline
                        buf.append("\n")
                        sys.stdout.write("\r\n")
                        continue
                    if seq == "[3":  # possible Delete (Esc [ 3 ~)
                        os.read(fd, 1)
                        continue
                    continue
                if ch == "\x12":  # Ctrl-R — fuzzy history search
                    found = self._search_history(prompt)
                    if found is not None:
                        buf = list(found)
                        self._redraw(prompt, buf)
                    continue
                if ch == "\x03":  # Ctrl-C — clear buffer, stay in the REPL
                    buf = []
                    self._redraw(prompt, buf)
                    continue
                if ch == "\x04":  # Ctrl-D — exit on empty buffer
                    if not buf:
                        sys.stdout.write("\r\n")
                        return None
                    continue
                if ch in ("\x7f", "\x08"):  # Backspace
                    if buf:
                        buf.pop()
                        sys.stdout.write("\x08 \x08")
                        sys.stdout.flush()
                    continue
                buf.append(ch)
                sys.stdout.write(ch)
                sys.stdout.flush()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        return "".join(buf)

    def _nav_history(self, hist_idx: int, seq: str, buf: list[str]) -> tuple[int, list[str]]:
        if not self._history:
            return hist_idx, buf
        if seq == "[A" and hist_idx > 0:
            hist_idx -= 1
        elif seq == "[B" and hist_idx < len(self._history):
            hist_idx += 1
        if hist_idx < len(self._history):
            return hist_idx, list(self._history[hist_idx])
        return hist_idx, []  # back to the live (empty) buffer

    def _redraw(self, prompt: str, buf: list[str]) -> None:
        # Move to the start of the input block and repaint it.
        text = "".join(buf)
        sys.stdout.write("\r\x1b[2K" + prompt + text)
        sys.stdout.flush()

    def _search_history(self, prompt: str) -> str | None:
        """Ctrl-R fuzzy search over history: type to filter, ↑/↓ to move,
        Enter accepts, Esc cancels. Returns the chosen command or None."""
        if not self._history:
            return None
        query = ""
        matches = self._match(query)
        sel = 0
        sys.stdout.write("\r\n")  # search UI drops below the prompt line
        drawn = 0
        try:
            while True:
                drawn = self._draw_search(query, matches, sel)
                ch = os.read(sys.stdin.fileno(), 1).decode("utf-8", errors="replace")
                if ch == "\x1b":
                    seq = os.read(sys.stdin.fileno(), 2).decode("utf-8", errors="replace")
                    if seq == "[A" and sel > 0:
                        sel -= 1
                    elif seq == "[B" and sel < len(matches) - 1:
                        sel += 1
                    else:  # bare Esc or other escape — cancel
                        self._clear_lines(drawn)
                        return None
                elif ch in ("\r", "\n"):  # Enter — accept the selection
                    self._clear_lines(drawn)
                    return matches[sel] if matches else None
                elif ch in ("\x7f", "\x08"):  # Backspace
                    query = query[:-1]
                    sel = 0
                elif ch == "\x03":  # Ctrl-C — cancel
                    self._clear_lines(drawn)
                    return None
                elif ch.isprintable():
                    query += ch
                    sel = 0
                matches = self._match(query)
                self._clear_lines(drawn)
        except (KeyboardInterrupt, EOFError):
            self._clear_lines(drawn)
            return None

    def _draw_search(self, query: str, matches: list[str], sel: int) -> int:
        lines = [f"(reverse-i-search)`{query}':"]
        for i, m in enumerate(matches):
            lines.append(("❯ " if i == sel else "  ") + m)
        sys.stdout.write("\r\x1b[2K" + "\n".join(lines))
        sys.stdout.flush()
        return len(lines)

    def _match(self, query: str) -> list[str]:
        """Subsequence-match history (most recent first), case-insensitive."""
        q = query.lower()
        if not q:
            return list(reversed(self._history))[:6]
        out = []
        for item in reversed(self._history):
            it = iter(item.lower())
            if all(c in it for c in q):  # subsequence
                out.append(item)
            if len(out) == 6:
                break
        return out

    def _clear_lines(self, n: int) -> None:
        for _ in range(max(n, 1)):
            sys.stdout.write("\x1b[1A\x1b[2K")
        sys.stdout.flush()

    # --- history -----------------------------------------------------------------

    # --- history -----------------------------------------------------------------

    def _load_history(self) -> None:
        try:
            if self._history_path.exists():
                lines = self._history_path.read_text(encoding="utf-8").splitlines()
                self._history = [line for line in lines if line.strip()][-_HISTORY_LIMIT:]
        except OSError:
            self._history = []

    def _push_history(self, line: str) -> None:
        self._history.append(line)
        try:
            self._history_path.parent.mkdir(parents=True, exist_ok=True)
            with self._history_path.open("a", encoding="utf-8") as fh:
                fh.write(line.replace("\n", " ") + "\n")
        except OSError:
            pass  # history is a convenience, never a failure mode
