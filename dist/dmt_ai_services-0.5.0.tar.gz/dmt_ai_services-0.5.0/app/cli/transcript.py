"""Local transcripts — an auditable JSONL record of every governed turn.

One file per conversation under the state dir (``~/.local/state/dmt``), each
line a self-contained event with the request id and the auth fingerprint so a
terminal session can be correlated with the gateway's audit logs. Advisory
state only — the caller keeps record-level content out of messages (data
minimization), same as the web assistant's sync.
"""

from __future__ import annotations

import json
import time
from contextlib import suppress
from pathlib import Path
from typing import Any


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class Transcript:
    """Append-only JSONL transcript for one conversation."""

    def __init__(self, state_dir: Path, conversation_id: str, *, enabled: bool = True) -> None:
        self._path = state_dir / "transcripts" / f"{conversation_id}.jsonl"
        self._enabled = enabled

    @property
    def path(self) -> Path:
        return self._path

    def record(self, kind: str, **fields: Any) -> None:
        if not self._enabled:
            return
        # A transcript failure must never break a governed turn.
        with suppress(OSError):
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with self._path.open("a", encoding="utf-8") as fh:
                fh.write(
                    json.dumps({"ts": _now_iso(), "kind": kind, **fields}, ensure_ascii=False)
                    + "\n"
                )

    def read_events(self) -> list[dict[str, Any]]:
        if not self._path.exists():
            return []
        events: list[dict[str, Any]] = []
        try:
            for line in self._path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    events.append(json.loads(line))
        except (OSError, json.JSONDecodeError):
            return []
        return events
