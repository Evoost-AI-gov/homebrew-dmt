"""Governed pricing endpoints (`/v1/pricing`) — the conflict surface.

The context graph's conflict-detection rule: a district band that sharply
contradicts the category-wide band is *flagged, never silently merged*. This
endpoint exposes those contradictions so the council (and the coverage
dashboard) can show them — abstention over invention, made visible.

Read-only, deterministic, and disclosure-floor-enforced (via the same governed
PricingTool the council uses).
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request

from app.council.tools import PricingTool

router = APIRouter(prefix="/pricing", tags=["Pricing"])


def get_pricing_tool(request: Request) -> PricingTool | None:
    """Return the shared governed pricing tool (None when unconfigured)."""
    return getattr(request.app.state, "pricing_tool", None)


@router.get("/conflicts")
def pricing_conflicts(
    request: Request,
    category: str = "",
    pricing: PricingTool | None = Depends(get_pricing_tool),
) -> dict:
    """Flag pricing bands that contradict the category-wide band.

    Returns the detected contradictions (district vs category median divergence
    > 60%) so they are surfaced and reviewed — never silently overwritten. An
    empty list means the governed data is internally consistent.
    """
    if pricing is None:
        return {"configured": False, "conflicts": []}
    conflicts = pricing.conflicts(category)
    return {
        "configured": True,
        "count": len(conflicts),
        "conflicts": conflicts,
        "note": "Conflicts are flagged for review — a divergent band is never silently merged.",
    }
