"""Personal Graph endpoints (`/v1/me/graph`) — the user's knowledge graph.

Backed by Semantica's ContextGraph: per-user, provenance-tracked, temporal, with
decision recording. The frontend Personal Graph canvas reads this; the activity
tracker writes to it as the user works. Scoped per signed-in user; fail-closed
when no store path is configured.

Governance: the graph holds the user's *own* working knowledge (entities they
touched, decisions the Director helped with) — never record-level DMT data. Each
decision is recorded with provenance so it is auditable (explainable invariant).
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field

from app.council.graph_service import PersonalGraphService
from app.council.user_context_routes import _user_id
from app.errors import InvalidRequestError

router = APIRouter(prefix="/me/graph", tags=["Personal Graph"])


def get_graph_service(request: Request) -> PersonalGraphService:
    """Return the app-scoped graph service (fail-closed when unconfigured)."""
    service = getattr(request.app.state, "graph_service", None)
    if service is None:
        raise InvalidRequestError("the personal graph is not configured")
    return service


class GraphActivityIn(BaseModel):
    """A work entity to add to the graph (viewed / compared / pinned / noted)."""

    kind: str = Field(max_length=40)
    label: str = Field(max_length=300)
    ref: str = Field(default="", max_length=200)
    module: str = Field(default="", max_length=100)


class GraphDecisionIn(BaseModel):
    """A governed decision to record (auditable)."""

    category: str = Field(max_length=100)
    scenario: str = Field(max_length=300)
    reasoning: str = Field(max_length=2000)
    outcome: str = Field(max_length=300)
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)


@router.get("")
def get_graph(
    request: Request,
    as_of: str | None = None,
    service: PersonalGraphService = Depends(get_graph_service),
) -> dict:
    """Return the signed-in user's Personal Graph (nodes + edges for the canvas).

    Pass ``as_of`` (ISO-8601) for a point-in-time snapshot — the graph as it was
    at that instant (the temporal model: nodes valid then, and the edges whose
    endpoints both existed). This is what makes a decision auditable against
    what was known at the time.
    """
    user_id = _user_id(request)
    if as_of:
        return service.snapshot(user_id, as_of)
    return service.to_frontend(user_id)


@router.post("/activity")
def record_graph_activity(
    payload: GraphActivityIn,
    request: Request,
    service: PersonalGraphService = Depends(get_graph_service),
) -> dict:
    """Add a work entity to the user's graph (grows as they work)."""
    return service.record_activity(
        _user_id(request), payload.kind, payload.label, payload.ref, payload.module
    )


@router.post("/decision", status_code=201)
def record_graph_decision(
    payload: GraphDecisionIn,
    request: Request,
    service: PersonalGraphService = Depends(get_graph_service),
) -> dict:
    """Record a governed decision in the user's graph (auditable, provenance)."""
    decision_id = service.record_decision(
        _user_id(request),
        payload.category,
        payload.scenario,
        payload.reasoning,
        payload.outcome,
        payload.confidence,
    )
    return {"decision_id": decision_id}


@router.get("/insights")
def graph_insights(
    request: Request, service: PersonalGraphService = Depends(get_graph_service)
) -> dict:
    """Graph intelligence: the hubs (most-connected entities) the work clusters on."""
    return service.insights(_user_id(request))


@router.get("/decisions")
def list_decisions(
    request: Request, service: PersonalGraphService = Depends(get_graph_service)
) -> dict:
    """The signed-in user's recorded decisions (the auditable decision log)."""
    return {"decisions": service.decisions(_user_id(request))}


@router.get("/decisions/{decision_id}/trace")
def trace_decision(
    decision_id: str,
    request: Request,
    service: PersonalGraphService = Depends(get_graph_service),
) -> dict:
    """The causal chain behind a decision (the audit trail)."""
    return service.trace_decision(_user_id(request), decision_id)


@router.get("/decisions/similar")
def similar_decisions(
    scenario: str,
    request: Request,
    service: PersonalGraphService = Depends(get_graph_service),
) -> dict:
    """Find precedent decisions for a scenario (consistency over time)."""
    return {"similar": service.similar_decisions(_user_id(request), scenario)}


@router.get("/explore/{node_id}")
def explore_node(
    node_id: str,
    request: Request,
    hops: int = 2,
    service: PersonalGraphService = Depends(get_graph_service),
) -> dict:
    """The neighbourhood around a node (multi-hop) — the explorer view."""
    return service.explore_node(_user_id(request), node_id, hops=min(hops, 4))
