"""Council graph: a deterministic, explainable view of one council turn (ADR-0001/0003).

This is the "wow" surface for DMT — who spoke, who they connect to, and *why* —
but it is built ONLY from deterministic edges derived from the governed turn, never
from LLM-invented relationships:

- expert → source (grounding): an agent cited a governed document.
- expert ↔ expert (co-citation): two agents grounded in the same document.
- expert ↔ expert (deliberation): a ``reply_to`` link from the F3 round.
- director → agent (synthesis): the Director reconciled that contribution.

Every edge carries ``why`` (the shared source / link), so the graph is auditable and
satisfies provenance. Pure functions over a CouncilChatResponse — no model calls.
"""

from __future__ import annotations

from app.council.schemas import CouncilChatResponse

# Node/edge kinds are strings so the frontend can render them without a schema bump.


def _node(node_id: str, kind: str, label: str) -> dict:
    return {"id": node_id, "kind": kind, "label": label}


def build_council_graph(
    response: CouncilChatResponse, *, agent_names: dict[str, str] | None = None
) -> dict:
    """Derive the deterministic graph for one council turn.

    ``agent_names`` maps agent_id -> display name (from the registry) for labels.
    Returns ``{"nodes": [...], "edges": [...], "meta": {...}}``.
    """
    names = agent_names or {}
    nodes: dict[str, dict] = {}
    edges: list[dict] = []
    seen_edges: set[tuple[str, str, str]] = set()

    def add_node(node_id: str, kind: str) -> None:
        if node_id not in nodes:
            nodes[node_id] = _node(node_id, kind, names.get(node_id, node_id))

    def add_edge(source: str, target: str, kind: str, why: str) -> None:
        key = (source, target, kind)
        if key in seen_edges:
            return
        seen_edges.add(key)
        edges.append({"source": source, "target": target, "kind": kind, "why": why})

    contributions = list(response.messages)
    if response.synthesis is not None:
        contributions.append(response.synthesis)

    # Nodes: every speaking agent + the Director.
    for message in contributions:
        add_node(message.agent_id, "agent")

    # Edges from grounding (agent -> source) and co-citation (agent <-> agent).
    by_source: dict[str, list[str]] = {}
    for message in contributions:
        for source in message.sources:
            add_node(source, "source")
            add_edge(message.agent_id, source, "cites", source)
            by_source.setdefault(source, []).append(message.agent_id)

    for source, agents in by_source.items():
        distinct = sorted(set(agents))
        for i, left in enumerate(distinct):
            for right in distinct[i + 1 :]:
                add_edge(left, right, "co_cited", f"both grounded in {source}")

    # Edges from deliberation (reply_to) and the Director's synthesis.
    for message in contributions:
        for other in message.reply_to:
            add_node(other, "agent")
            add_edge(message.agent_id, other, "deliberates", "reacted to their contribution")

    if response.synthesis is not None:
        director = response.synthesis.agent_id
        # The synthesizer is the Director — relabel its node so the graph shows the
        # orchestrator distinctly even though it also "spoke" a contribution.
        nodes[director] = _node(director, "director", names.get(director, director))
        for message in response.messages:
            add_edge(director, message.agent_id, "synthesizes", "reconciled into the answer")

    return {
        "nodes": list(nodes.values()),
        "edges": edges,
        "meta": {
            "turn_id": response.id,
            "participants": response.meta.participants,
            "rounds": response.meta.rounds,
            "node_count": len(nodes),
            "edge_count": len(edges),
        },
    }
