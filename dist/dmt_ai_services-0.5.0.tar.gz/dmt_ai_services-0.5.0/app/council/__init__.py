"""Council Chat — governed multi-agent conversational runtime (ADR-0003).

This package is the advisory, multi-agent surface of the DMT platform. It turns
the *editor-time* business council (`.github/agents/*.agent.md`) into a runtime:
a Director-orchestrated conversation where business experts answer in persona,
grounded only by read-only governed tools.

Hard boundaries (the five invariants):
  - Advisory only: no scored/priced/ranked figure is *produced* here; figures are
    read from governed tools and carry ``source`` + ``confidence``.
  - Abstention over invention; data minimization; sovereignty (no external egress).
  - Governed personalities: personas are compiled from versioned ``.agent.md``
    files, never free-typed at runtime.

F1 scope: a single active expert per turn, grounded in retrieval, streamed over an
OpenAI-compatible SSE gateway. Fan-out/synthesis (F2), deliberation (F3), the custom
builder (F4) and external capture (F5) build on this base.
"""

from app.council.persona import CouncilAgent, compile_persona
from app.council.registry import CouncilRegistry

__all__ = ["CouncilAgent", "CouncilRegistry", "compile_persona"]
