"""Council metrics — per-turn audit log + per-expert governance KPIs.

An append-only JSONL log of every completed council turn (who spoke, who grounded
on evidence, who abstained, confidence, veto, tokens), aggregated into
government-grade KPIs per expert so DMT can SEE the council working: how often each
expert intervenes, how often it confirms a position with governed evidence, how
often it abstains, and its typical confidence. Deterministic and real — computed
only from turns that actually happened; never invented. Data-minimized: the log
holds agent ids and governance flags, never user content or record-level data.
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

_logger = logging.getLogger("dmt_ai.council.metrics")

_CONF_NUM = {"low": 0, "medium": 1, "high": 2}
_NUM_CONF = {0: "low", 1: "medium", 2: "high"}


def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class CouncilMetricsStore:
    """Append-only per-turn metrics log with a deterministic KPI aggregation."""

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)

    @property
    def configured(self) -> bool:
        return bool(str(self._path).strip())

    def record(self, response: Any) -> None:
        """Append one turn's governance metrics (non-fatal — never breaks a turn)."""
        try:
            event = self._event(response)
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with self._path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(event) + "\n")
        except Exception as exc:  # noqa: BLE001 - metrics must never break a turn
            _logger.warning("council_metrics_record_failed", extra={"err": str(exc)})

    @staticmethod
    def _event(response: Any) -> dict[str, Any]:
        messages = list(getattr(response, "messages", []) or [])
        meta = getattr(response, "meta", None)
        synthesis = getattr(response, "synthesis", None)
        veto = getattr(response, "veto", None)
        return {
            "ts": _now_iso(),
            "turn_id": getattr(response, "id", ""),
            "participants": list(getattr(meta, "participants", []) or []),
            "speakers": [m.agent_id for m in messages],
            "grounded": [m.agent_id for m in messages if m.sources],
            "abstained": [m.agent_id for m in messages if m.abstained],
            "confidences": {m.agent_id: m.confidence for m in messages if m.confidence},
            "synthesis_confidence": getattr(synthesis, "confidence", None),
            "veto": getattr(veto, "gate", None),
            "tokens": int(getattr(meta, "total_tokens", 0) or 0),
        }

    def _read(self) -> list[dict[str, Any]]:
        if not self._path.exists():
            return []
        events: list[dict[str, Any]] = []
        for line in self._path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue  # a partial trailing write — skip, never fail the surface
        return events

    def aggregate(self, roster: list[Any]) -> dict[str, Any]:
        """Return per-expert + council-wide KPIs from the recorded turns."""
        events = self._read()
        total = len(events)
        experts_only = [a for a in roster if getattr(a, "kind", "expert") == "expert"]
        names = {a.agent_id: a.display_name for a in roster}

        per: dict[str, dict[str, Any]] = defaultdict(
            lambda: {
                "interventions": 0,
                "confirmed": 0,
                "abstained": 0,
                "conf_sum": 0,
                "conf_n": 0,
                "last_active": None,
            }
        )
        for event in events:
            grounded = set(event.get("grounded", []))
            abstained = set(event.get("abstained", []))
            confidences = event.get("confidences", {})
            # One intervention per expert per turn (a deliberation round can add a
            # second message for the same expert — it is still one participation).
            for agent_id in set(event.get("speakers", [])):
                stat = per[agent_id]
                stat["interventions"] += 1
                if agent_id in grounded and agent_id not in abstained:
                    stat["confirmed"] += 1
                if agent_id in abstained:
                    stat["abstained"] += 1
                conf = confidences.get(agent_id)
                if conf in _CONF_NUM:
                    stat["conf_sum"] += _CONF_NUM[conf]
                    stat["conf_n"] += 1
                stat["last_active"] = event.get("ts")

        def pct(n: int, d: int) -> float:
            return round(100 * n / d, 1) if d else 0.0

        experts: list[dict[str, Any]] = []
        for agent in experts_only:
            stat = per.get(agent.agent_id)
            interventions = stat["interventions"] if stat else 0
            avg_conf = (
                _NUM_CONF[round(stat["conf_sum"] / stat["conf_n"])]
                if stat and stat["conf_n"]
                else None
            )
            experts.append(
                {
                    "agent_id": agent.agent_id,
                    "display_name": names.get(agent.agent_id, agent.agent_id),
                    "interventions": interventions,
                    "participation_pct": pct(interventions, total),
                    "confirmation_pct": pct(stat["confirmed"] if stat else 0, interventions),
                    "abstention_pct": pct(stat["abstained"] if stat else 0, interventions),
                    "avg_confidence": avg_conf,
                    "last_active": stat["last_active"] if stat else None,
                }
            )
        experts.sort(key=lambda e: e["interventions"], reverse=True)

        speaker_counts = [len(set(e.get("speakers", []))) for e in events]
        grounded_turns = sum(1 for e in events if e.get("grounded"))
        abstained_turns = sum(1 for e in events if e.get("abstained"))
        veto_turns = sum(1 for e in events if e.get("veto"))
        return {
            "available": total > 0,
            "generated_at": _now_iso(),
            "council": {
                "total_turns": total,
                "avg_experts_per_turn": round(sum(speaker_counts) / total, 2) if total else 0.0,
                "grounded_turns_pct": pct(grounded_turns, total),
                "abstention_turns_pct": pct(abstained_turns, total),
                "veto_count": veto_turns,
            },
            "experts": experts,
        }
