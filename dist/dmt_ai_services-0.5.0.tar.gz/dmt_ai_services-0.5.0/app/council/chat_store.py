"""Chat-persistence store for the council gateway (advisory conversations only).

The frontend mirrors the assistant's working state (conversations + project
folders) so it survives across devices. This store keeps that state in a single
JSON file with atomic writes. It is **advisory state only** — it never holds a
governed figure, and (per data minimization) it is the caller's responsibility to
keep identity/record-level content out of messages.

Fail-closed on corruption: a missing/unreadable store yields an empty state, never
an error that takes the assistant down (the frontend keeps its local fallback).
"""

from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from pathlib import Path

_logger = logging.getLogger("dmt_ai.council.chat_store")


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class ChatStore:
    """File-backed store of assistant conversations + project folders."""

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        # Serializes read-modify-write so concurrent upserts never corrupt the file
        # or collide on the temp path (the council serves concurrent requests).
        self._lock = threading.Lock()

    def _read(self) -> dict:
        if not self._path.exists():
            return {"conversations": {}, "projects": {}}
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            _logger.warning("chat_store_unreadable", extra={"err": str(exc)})
            return {"conversations": {}, "projects": {}}
        return {
            "conversations": data.get("conversations", {}),
            "projects": data.get("projects", {}),
        }

    def _write(self, data: dict) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(self._path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self._path)  # atomic on POSIX

    # --- conversations --------------------------------------------------------

    def list_conversations(self) -> list[dict]:
        """Return all conversations, most recently updated first."""
        rows = list(self._read()["conversations"].values())
        return sorted(rows, key=lambda r: r.get("updated_at", ""), reverse=True)

    def upsert_conversation(
        self,
        conv_id: str,
        *,
        title: str,
        messages: list[dict],
        project_id: str | None = None,
    ) -> dict:
        """Create or replace a conversation (idempotent upsert, thread-safe)."""
        with self._lock:
            data = self._read()
            record = {
                "id": conv_id,
                "title": title,
                "messages": messages,
                "project_id": project_id,
                "updated_at": _now_iso(),
            }
            data["conversations"][conv_id] = record
            self._write(data)
            return record

    def delete_conversation(self, conv_id: str) -> bool:
        """Delete a conversation; True if it existed."""
        with self._lock:
            data = self._read()
            if conv_id not in data["conversations"]:
                return False
            del data["conversations"][conv_id]
            self._write(data)
            return True

    # --- projects ---------------------------------------------------------------

    def list_projects(self) -> list[dict]:
        """Return all project folders, oldest first."""
        rows = list(self._read()["projects"].values())
        return sorted(rows, key=lambda r: r.get("created_at", ""))

    def create_project(self, name: str) -> dict:
        """Create a project folder."""
        with self._lock:
            data = self._read()
            record = {"id": f"proj-{uuid.uuid4().hex[:12]}", "name": name, "created_at": _now_iso()}
            data["projects"][record["id"]] = record
            self._write(data)
            return record

    def rename_project(self, proj_id: str, name: str) -> dict | None:
        """Rename a project; None if unknown."""
        with self._lock:
            data = self._read()
            record = data["projects"].get(proj_id)
            if record is None:
                return None
            record["name"] = name
            data["projects"][proj_id] = record
            self._write(data)
            return record

    def delete_project(self, proj_id: str) -> bool:
        """Delete a project and unassign its conversations; True if it existed."""
        with self._lock:
            data = self._read()
            if proj_id not in data["projects"]:
                return False
            del data["projects"][proj_id]
            for conv in data["conversations"].values():
                if conv.get("project_id") == proj_id:
                    conv["project_id"] = None
            self._write(data)
            return True
