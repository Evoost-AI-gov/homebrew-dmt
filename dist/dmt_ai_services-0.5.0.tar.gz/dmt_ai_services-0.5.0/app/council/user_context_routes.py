"""User-context endpoints (`/v1/me`) — the Director-as-coworker substrate.

Per-user working state (role, goal, current module, pinned items, recent
activity) so the Director can answer personal, work-aware questions ("what do I
have pending today?") instead of abstaining. Scoped by the Entra user id; a
signed-in user only ever reads/writes their own context. Fail-closed: when no
store path is configured the router is not mounted.

Governance: data minimisation — the context is the user's *own* working state,
never governed figures or record-level DMT data. Read/write is per-user only.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field

from app.council.user_context import UserContextStore
from app.errors import InvalidRequestError

router = APIRouter(prefix="/me", tags=["User Context"])


def get_context_store(request: Request) -> UserContextStore:
    """Return the app-scoped user-context store (fail-closed when unconfigured)."""
    store = getattr(request.app.state, "user_context_store", None)
    if store is None:
        raise InvalidRequestError("user context is not configured")
    return store


def _user_id(request: Request) -> str:
    """Resolve the caller's user id (Entra bearer `user:<oid>`, else 'dev').

    The auth dependency already ran on the v1 router; we re-derive the identity
    from the Authorization header here so the context is scoped per signed-in
    user. Anonymous callers share the 'dev' bucket (the read-only demo).
    """
    auth = request.headers.get("authorization", "")
    if auth.startswith("Bearer "):
        from app.security import _validate_entra_jwt

        identity = _validate_entra_jwt(auth[7:], request.app.state.settings)
        if identity:
            return identity
    return "dev"


class ContextPatch(BaseModel):
    """A partial update to the user's work context."""

    role: str | None = Field(default=None, max_length=200)
    goal: str | None = Field(default=None, max_length=1000)
    module: str | None = Field(default=None, max_length=100)
    pinned: list[dict] | None = None


class ActivityIn(BaseModel):
    """A single work event (viewed / compared / pinned / noted)."""

    kind: str = Field(max_length=40)
    label: str = Field(max_length=300)
    ref: str = Field(default="", max_length=200)
    module: str = Field(default="", max_length=100)


@router.get("/context")
def get_context(request: Request, store: UserContextStore = Depends(get_context_store)) -> dict:
    """Return the signed-in user's work context."""
    return store.get(_user_id(request))


@router.put("/context")
def put_context(
    payload: ContextPatch,
    request: Request,
    store: UserContextStore = Depends(get_context_store),
) -> dict:
    """Merge a partial update into the signed-in user's work context."""
    return store.upsert(_user_id(request), payload.model_dump(exclude_none=True))


@router.post("/context/activity")
def record_activity(
    payload: ActivityIn,
    request: Request,
    store: UserContextStore = Depends(get_context_store),
) -> dict:
    """Append a work event to the signed-in user's context."""
    return store.record_activity(
        _user_id(request), payload.kind, payload.label, payload.ref, payload.module
    )
