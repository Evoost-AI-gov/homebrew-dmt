"""External-capture agents (F5): governed fetch of external, unverified sources.

DMT may ask the council about external market context, but external content is NOT
governed data. Every fetch is constrained and labelled so it can never be confused
with authoritative DMT evidence:

- **Allowlist**: only configured domains may be fetched (fail-closed otherwise).
- **Egress control**: the outbound call is the sovereignty boundary; only plain
  public GETs over https are allowed, with a hard timeout and size cap.
- **Provenance tagging**: everything returned is tagged ``external/unverified``
  with the source URL, so downstream (and the Director) treat it as untrusted and
  never merge it with governed figures.
- **Injection screening**: fetched text is treated as untrusted data (the caller
  injects it as context, never as instructions).
"""

from __future__ import annotations

import logging
from urllib.parse import urlparse

import httpx

from app.errors import InvalidRequestError, UpstreamError

_logger = logging.getLogger("dmt_ai.council.external")

# Governance label applied to every external capture. This is what keeps external
# content out of the governed confidence model.
EXTERNAL_TIER = "external/unverified"

_MAX_BYTES = 64_000  # cap a fetched page; we only need an excerpt, not the document
_TIMEOUT_S = 8.0


class ExternalCapture:
    """Bounded, allow-listed fetch of external sources with provenance tagging."""

    def __init__(self, allowlist: frozenset[str], *, enabled: bool = True) -> None:
        self._allowlist = {d.lower() for d in allowlist}
        self._enabled = enabled and bool(allowlist)

    @property
    def configured(self) -> bool:
        """Whether external capture is enabled and has an allowlist."""
        return self._enabled

    def _check_url(self, url: str) -> str:
        """Validate the URL scheme + host against the allowlist; return the host."""
        parsed = urlparse(url)
        if parsed.scheme != "https":
            raise InvalidRequestError("external capture only allows https URLs")
        host = (parsed.hostname or "").lower()
        if not host:
            raise InvalidRequestError("external capture requires a valid host")
        allowed = any(host == d or host.endswith(f".{d}") for d in self._allowlist)
        if not allowed:
            _logger.warning("external_capture_blocked", extra={"host": host})
            raise InvalidRequestError(f"{host} is not on the external-capture allowlist")
        return host

    async def fetch(self, url: str) -> dict:
        """Fetch a URL and return a governed, tagged excerpt.

        Returns ``{url, tier, excerpt, bytes}``; raises on disallowed/failed fetches.
        """
        if not self.configured:
            raise InvalidRequestError("external capture is not configured")
        self._check_url(url)
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(_TIMEOUT_S)) as client:
                response = await client.get(url, follow_redirects=True)
                response.raise_for_status()
                raw = response.content[:_MAX_BYTES]
        except httpx.HTTPError as exc:
            raise UpstreamError(f"external fetch failed: {exc}") from exc
        excerpt = raw.decode("utf-8", errors="replace")
        _logger.info("external_capture", extra={"url": url, "bytes": len(raw)})
        return {
            "url": url,
            "tier": EXTERNAL_TIER,
            "excerpt": excerpt,
            "bytes": len(raw),
        }
