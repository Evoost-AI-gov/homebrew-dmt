"""Council Chat request/response schemas (per `.github/specs/council-orchestrator.md`).

These extend the platform's OpenAI-compatible contract with the council's
governance fields: the active roster, and per-message ``agent_id`` / ``sources`` /
``confidence`` / ``abstained`` / ``veto``. Like the rest of the gateway, unknown
fields are rejected (``extra="forbid"``) so nothing is silently forwarded.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

Confidence = Literal["high", "medium", "low"]

# Thinking effort (instant/medium/high) -> per-call max_tokens budget. The Director
# synthesizes into one answer; experts get a tighter budget on lower effort.
_EFFORT_MAX_TOKENS = {"instant": 320, "medium": 768, "high": 1536}


def effort_max_tokens(effort: str | None, default: int) -> int:
    """Map the thinking-effort level to a per-call token budget (cost + latency).

    Lower effort = shorter, faster answers (less model reasoning). Unknown/None
    keeps the request's own ``max_tokens`` (fail-safe to the caller's budget).
    """
    if effort is None:
        return default
    return _EFFORT_MAX_TOKENS.get(effort, default)


# The active roster is capped per the spec's cost-governance limits.
MAX_AGENTS_PER_TURN = 4


class CouncilChatMessage(BaseModel):
    """A single council chat turn in the request."""

    model_config = ConfigDict(extra="forbid")

    role: Literal["system", "user", "assistant"]
    content: str = Field(max_length=100_000)


class CouncilChatRequest(BaseModel):
    """A request for one council turn.

    ``agents`` names the active roster (registry agent ids). F1 serves exactly one
    agent (the Director default); F2 fans out across several and synthesizes.
    """

    model_config = ConfigDict(extra="forbid")

    conversation_id: str | None = Field(default=None, max_length=128)
    agents: list[str] = Field(default_factory=list, max_length=MAX_AGENTS_PER_TURN)
    messages: list[CouncilChatMessage] = Field(min_length=1, max_length=100)
    model: str = Field(default="dmt-brain", min_length=1, max_length=128)
    max_tokens: int = Field(default=1024, ge=1, le=8192)
    stream: bool = True
    # F3: when more than one expert is active, run one Director-mediated
    # deliberation round (each expert reacts to the others' contributions) before
    # synthesis. OFF by default: it doubles expert model calls, so interactive
    # turns skip it (opt-in per request); the Director still reconciles in the
    # synthesis. Cost-bounded by ``_MAX_FANOUT``.
    deliberate: bool = False
    # Director-delegation mode: when true and no explicit roster is given, the
    # Director picks the relevant experts for the query itself (the council is
    # "active" without the user hand-picking agents). Off = Director answers alone.
    delegate: bool = False
    # Thinking effort (ChatGPT-style): instant = fast/concise, medium = balanced,
    # high = deep. Maps to a token budget; omitted = the request's max_tokens.
    effort: Literal["instant", "medium", "high"] | None = None
    # Director-as-coworker: the signed-in user's work context (role, goal,
    # current module, pinned/pending items) snapshot from the frontend, so the
    # Director answers personal, work-aware questions. Advisory only — never
    # governed figures; the caller keeps record-level content out of it.
    user_context: str = Field(default="", max_length=4000)


class CouncilAgentInfo(BaseModel):
    """Public metadata for one council agent (for the roster / picker)."""

    agent_id: str
    display_name: str
    kind: Literal["director", "gate", "expert"]
    lens: list[str]
    description: str = ""
    avatar_icon: str = "bot"
    avatar_color: str = "slate"


class CouncilRoster(BaseModel):
    """The list of agents the user can add to a conversation."""

    data: list[CouncilAgentInfo]


class ExternalFetchRequest(BaseModel):
    """A request to capture an external (unverified) source (F5)."""

    model_config = ConfigDict(extra="forbid")

    url: str = Field(min_length=8, max_length=2048)


class CouncilVeto(BaseModel):
    """A governance-gate block. The only output a gate ever produces."""

    gate: str
    reason: str


class CouncilEvidence(BaseModel):
    """One governed evidence citation (the exact retrieval chunk, with its tier
    + similarity score) — the provenance a decision links to."""

    chunk_id: str
    canonical_file: str
    tier: str = "reference"
    score: float = 0.0


class CouncilMessage(BaseModel):
    """One agent's governed contribution to a council turn."""

    agent_id: str
    content: str
    sources: list[str] = Field(default_factory=list)
    # The exact retrieval chunks that ground the answer (chunk-level provenance).
    evidence: list[CouncilEvidence] = Field(default_factory=list)
    confidence: Confidence | None = None
    abstained: bool = False
    # F3 deliberation: ids of the other contributions this message reacts to
    # (Director-mediated — experts never call each other directly).
    reply_to: list[str] = Field(default_factory=list)


class TurnMeta(BaseModel):
    """Cost + orchestration metadata for a turn (presence / audit / dashboard)."""

    participants: list[str] = Field(default_factory=list)
    rounds: int = 1
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class CouncilChatResponse(BaseModel):
    """The non-streaming council reply (also the payload of the final SSE event).

    F1 (single speaker): ``messages`` holds that one agent's message and
    ``synthesis`` is ``None``. F2 (fan-out): ``messages`` holds each expert's
    contribution and ``synthesis`` the Director's reconciled answer.
    """

    id: str
    conversation_id: str | None = None
    model: str
    messages: list[CouncilMessage] = Field(default_factory=list)
    synthesis: CouncilMessage | None = None
    veto: CouncilVeto | None = None
    meta: TurnMeta = Field(default_factory=TurnMeta)

    @property
    def speaker_id(self) -> str:
        """The primary speaker (first expert message, else the Director/synthesis)."""
        if self.messages:
            return self.messages[0].agent_id
        if self.synthesis is not None:
            return self.synthesis.agent_id
        return "director-program-orchestrator"

    @property
    def headline(self) -> str:
        """The user-facing text: the synthesis when present, else the speaker's."""
        if self.synthesis is not None:
            return self.synthesis.content
        return self.messages[0].content if self.messages else ""
