"""Per-user work context — the substrate for the Director-as-coworker.

The Director answers "what do I have pending today?" only when it can see the
user's actual work: their role, their goal, the module they're in, and the items
they've pinned or left open. This module owns that context, keyed by the Entra
user id (``oid``) so each DMT user has their own.

Governance: data minimisation — the context is the user's *own* working state
(role, goal, current module, pinned items, recent activity), never record-level
DMT data. It is stored per-user, returned only to that user, and fed to the
Director as grounding so answers are personal, not generic.
"""

from __future__ import annotations

import json
import threading
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class UserContextStore:
    """File-backed per-user work context (role, goal, module, pending, graph).

    Thread-safe, append-friendly. One JSON document keyed by user id:
        { "<oid>": { "role": "...", "goal": "...", "module": "...",
                     "pinned": [...], "activity": [...], "updated_at": "..." } }
    """

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._lock = threading.Lock()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        if not self._path.exists():
            self._write({})

    def _read(self) -> dict[str, Any]:
        try:
            return json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self._path)

    def get(self, user_id: str) -> dict[str, Any]:
        """Return the user's context, or an empty default."""
        with self._lock:
            return self._read().get(
                user_id,
                {
                    "role": "",
                    "goal": "",
                    "module": "",
                    "pinned": [],
                    "activity": [],
                    "updated_at": "",
                },
            )

    def upsert(self, user_id: str, patch: dict[str, Any]) -> dict[str, Any]:
        """Merge a partial update into the user's context."""
        with self._lock:
            data = self._read()
            current = data.get(user_id, {})
            current.update({k: v for k, v in patch.items() if v is not None})
            current["updated_at"] = _now_iso()
            # Cap activity to the most recent 50 events (data minimisation).
            if isinstance(current.get("activity"), list):
                current["activity"] = current["activity"][-50:]
            data[user_id] = current
            self._write(data)
            return current

    def record_activity(
        self, user_id: str, kind: str, label: str, ref: str = "", module: str = ""
    ) -> dict[str, Any]:
        """Append a work event (viewed a parcel, compared scenarios, pinned a note)."""
        ctx = self.get(user_id)
        activity = list(ctx.get("activity", []))
        activity.append(
            {
                "kind": kind,
                "label": label,
                "ref": ref,
                "module": module,
                "at": _now_iso(),
            }
        )
        return self.upsert(
            user_id, {"activity": activity, "module": module or ctx.get("module", "")}
        )
