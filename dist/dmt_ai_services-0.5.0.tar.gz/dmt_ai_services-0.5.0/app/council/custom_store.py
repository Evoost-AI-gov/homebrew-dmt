"""Persistence + approval state for DMT-custom council agents (F4).

Custom agents live in a JSON store (one file, atomic writes) separate from the
read-only curated `.agent.md` corpus. Each record carries its spec, an approval
status (``pending`` -> ``approved``/``rejected``), and provenance (creator,
reviewer, timestamps). Only ``approved`` agents may be compiled into the roster.

Fail-closed: a missing/corrupt store yields an empty set, never an error that
would take the council down.
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path

from app.council.builder import CustomAgentSpec

_logger = logging.getLogger("dmt_ai.council.custom_store")

STATUS_PENDING = "pending"
STATUS_APPROVED = "approved"
STATUS_REJECTED = "rejected"


class CustomAgentStore:
    """File-backed store of custom agent specs with an approval workflow."""

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)

    def _read(self) -> dict[str, dict]:
        if not self._path.exists():
            return {}
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            _logger.warning("council_custom_store_unreadable", extra={"err": str(exc)})
            return {}
        return data if isinstance(data, dict) else {}

    def _write(self, data: dict[str, dict]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(self._path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self._path)  # atomic on POSIX

    def list(self, *, status: str | None = None) -> list[dict]:
        """Return all custom agent records, optionally filtered by status."""
        records = list(self._read().values())
        if status is not None:
            records = [r for r in records if r.get("status") == status]
        return sorted(records, key=lambda r: r.get("created_at", 0))

    def get(self, agent_id: str) -> dict | None:
        """Return one record by id, or None."""
        return self._read().get(agent_id)

    def create(self, spec: CustomAgentSpec) -> dict:
        """Register a new custom agent as ``pending`` (never auto-approved)."""
        data = self._read()
        if spec.agent_id in data:
            raise ValueError(f"a custom agent with id {spec.agent_id!r} already exists")
        record = {
            "spec": spec.model_dump(),
            "status": STATUS_PENDING,
            "created_by": spec.created_by,
            "created_at": int(time.time() * 1000),
            "reviewed_by": "",
            "reviewed_at": None,
        }
        data[spec.agent_id] = record
        self._write(data)
        return record

    def approve(self, agent_id: str, *, reviewer: str) -> dict:
        """Approve a pending agent (Compliance). Raises if unknown."""
        return self._set_status(agent_id, STATUS_APPROVED, reviewer)

    def reject(self, agent_id: str, *, reviewer: str) -> dict:
        """Reject a pending agent (Compliance). Raises if unknown."""
        return self._set_status(agent_id, STATUS_REJECTED, reviewer)

    def _set_status(self, agent_id: str, status: str, reviewer: str) -> dict:
        data = self._read()
        record = data.get(agent_id)
        if record is None:
            raise KeyError(agent_id)
        record["status"] = status
        record["reviewed_by"] = reviewer
        record["reviewed_at"] = int(time.time() * 1000)
        data[agent_id] = record
        self._write(data)
        return record

    def approved_specs(self) -> list[CustomAgentSpec]:
        """Return the specs of approved agents (the ones that may join the roster)."""
        return [
            CustomAgentSpec(**r["spec"])
            for r in self.list(status=STATUS_APPROVED)
            if isinstance(r.get("spec"), dict)
        ]
