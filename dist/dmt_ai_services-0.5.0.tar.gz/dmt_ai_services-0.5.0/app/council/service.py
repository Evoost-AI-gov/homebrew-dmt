"""Council turn service: governed conversational turns (F1 single-speaker, F2 fan-out).

The turn manager is deterministic code — never a model — so routing, the veto
channel, fan-out and cost caps stay auditable. F1 answers with one speaker; F2
fans the user turn out to the relevant experts (clean context each, in parallel)
and has the Director synthesize a single decision-grade reply.

Hard boundaries (the five invariants): advisory only; abstention over invention;
data minimization; degraded confidence on bridges; sovereignty (no external egress).
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from collections.abc import AsyncIterator
from typing import Any

from app.council.metrics import CouncilMetricsStore
from app.council.persona import CouncilAgent
from app.council.registry import CouncilRegistry
from app.council.schemas import (
    Confidence,
    CouncilChatRequest,
    CouncilChatResponse,
    CouncilEvidence,
    CouncilMessage,
    CouncilVeto,
    TurnMeta,
    effort_max_tokens,
)
from app.council.tools import BriefTool, PricingTool, run_governed_tools
from app.errors import InvalidRequestError, RetrievalNotConfiguredError, UpstreamError
from app.inference import InferenceService
from app.retrieval import RetrievalService
from app.schemas import ChatCompletionRequest, ChatMessage, Citation

_logger = logging.getLogger("dmt_ai.council.service")

# Keywords that mark a routing domain as backed by the governed pricing tool.
_PRICING_DOMAIN_KEYWORDS: frozenset[str] = frozenset(
    {"price", "pricing", "rent", "rental", "benchmark", "valuation", "value", "comparable"}
)

# Keywords that mark a routing domain as backed by the governed Command Center brief.
_BRIEF_DOMAIN_KEYWORDS: frozenset[str] = frozenset(
    {
        "posture",
        "release posture",
        "robustness",
        "how robust",
        "tripwire",
        "headroom",
        "command center",
    }
)


def _domain_label(keywords: tuple[str, ...]) -> str:
    """A short, human label for a routing domain (its first, most specific keyword)."""
    return keywords[0].replace("-", " ").title() if keywords else "Domain"


# Returned verbatim when retrieval is required and nothing clears the floor — the
# model is not called, so it cannot answer off-corpus (abstention over invention).
_ABSTENTION_TEXT = (
    "I can only answer from governed DMT sources, and I don't have grounded evidence "
    "for that. Try asking about DMT parcels, pricing benchmarks, land scores, demand, "
    "scenarios, foresight, or geopolitical risk."
)

# Cost governance (per turn). Bounds fan-out so a broad roster cannot blow up spend.
_MAX_FANOUT = 3

# qwen3 (dmt-brain) soft switch: skip the chain-of-thought for the Director's
# synthesis. It reconciles already-grounded, already-cited expert contributions — a
# reconciliation/writing task, not deep reasoning — so thinking adds ~14s of latency
# for no decision-quality gain (measured 16.0s -> 2.0s). The provider's _strip_reasoning
# removes the now-empty <think> block; harmlessly ignored by non-qwen deployments.
_NO_THINK_DIRECTIVE = " /no_think"

# Domain identity, prepended to every council system prompt. DMT is the Abu Dhabi
# Department of Municipalities & Transport — never the chemical compound. This
# anchors the model's frame so a bare "What is DMT?" answers about the department.
_DMT_IDENTITY = (
    "In this platform, DMT always means the Department of Municipalities & Transport "
    "(DMT), the Abu Dhabi government department for municipal services, urban planning, "
    "land and real-estate regulation, and transport. It never refers to the chemical "
    "compound. Answer every question in that government / land-intelligence frame."
)

# Deterministic lens router — a distilled, code form of `.github/agents/ROUTING-EVALS.md`.
# Each row maps query keywords to the *expert ids* that own that domain (lead first).
# Order matters: earlier rows win on overlap; matched against the lowercased query.
# An expert is selected when routed AND (requested explicitly OR present in delegate mode).
# Every expert is also grounded in retrieval regardless of its domain.
_ROUTING_TABLE: tuple[tuple[tuple[str, ...], tuple[str, ...]], ...] = (
    # Registry & regulation (ADREC) — the ADREC expert leads; deal-structuring supports.
    (
        (
            "register",
            "registration",
            "title deed",
            "tawtheeq",
            "escrow",
            "jop",
            "ownership",
            "tenancy",
        ),
        ("registry-regulation-adrec-expert", "deal-structuring-land-tenure-expert"),
    ),
    # Permits & licensing (MePS / DCR / occupancy) — the permits expert leads.
    (
        ("permit", "licence", "license", "occupancy", "meps", "dcr", "completion certificate"),
        (
            "permits-licensing-meps-expert",
            "urban-planning-land-use-strategist",
            "sequencing-phasing-strategist",
        ),
    ),
    # Pricing / valuation.
    (
        ("price", "pricing", "value", "valuation", "rent", "comparable", "benchmark"),
        ("real-estate-valuation-expert", "market-intelligence-research-analyst"),
    ),
    # Investment / return.
    (
        ("irr", "yield", "return", "investment case", "cash flow", "risk-adjusted"),
        ("investment-capital-markets-analyst", "real-estate-valuation-expert"),
    ),
    # Investor matching / KYC / capital source.
    (
        ("archetype", "kyc", "mandate", "match", "swf", "investor", "capital source"),
        ("investor-archetypes-capital-sourcing-expert", "investment-capital-markets-analyst"),
    ),
    # Market intelligence / demand.
    (
        ("absorption", "trend", "comparable market", "transaction", "demand", "competitor"),
        ("market-intelligence-research-analyst",),
    ),
    # Sequencing / phasing.
    (
        ("phase", "phasing", "sequence", "sequencing", "staging"),
        ("sequencing-phasing-strategist", "urban-planning-land-use-strategist"),
    ),
    # Sustainability / Estidama / livability.
    (
        ("estidama", "pearl", "esg", "livability", "sustainab", "quality of life"),
        ("sustainability-livability-esg-estidama-expert", "urban-planning-land-use-strategist"),
    ),
    # Geopolitical risk.
    (
        ("geopolitic", "sanction", "fatf", "pep", "risk score"),
        (
            "geopolitical-risk-international-relations-analyst",
            "investor-archetypes-capital-sourcing-expert",
        ),
    ),
    # Urban planning / land use.
    (
        ("zoning", "plan abu dhabi", "land use", "land-use", "mussafah", "masterplan"),
        ("urban-planning-land-use-strategist", "sequencing-phasing-strategist"),
    ),
    # Deal structuring / tenure.
    (
        ("musataha", "lease", "tenure", "contract", "joint venture", " jv"),
        ("deal-structuring-land-tenure-expert", "registry-regulation-adrec-expert"),
    ),
    # Government affairs / stakeholders / data access.
    (
        ("stakeholder", "mou", "data access", "government", "adrec api", "approval friction"),
        ("government-affairs-stakeholder-strategy-expert",),
    ),
    # Product / GTM / positioning.
    (
        ("position", "go-to-market", "gtm", "poc scope", "licensing model", "competitor pitch"),
        ("product-go-to-market-strategist", "market-intelligence-research-analyst"),
    ),
    # Command Center — the composed release decision (posture / robustness / tripwires),
    # grounded on the governed brief snapshot.
    (
        (
            "posture",
            "release posture",
            "robustness",
            "how robust",
            "tripwire",
            "headroom",
            "at risk",
            "command center",
            "stress test",
            "executive read",
            "should we release",
        ),
        (
            "sequencing-phasing-strategist",
            "urban-planning-land-use-strategist",
            "investment-capital-markets-analyst",
        ),
    ),
)

# Pre-inference veto triggers (Compliance & Data-Governance / Security). A request
# for identity/record-level data is blocked before any model is called.
_VETO_PATTERNS: tuple[tuple[str, str], ...] = (
    ("who owns", "Ownership identity is record-level data (data minimization)."),
    ("owner name", "Owner identity is record-level data (data minimization)."),
    ("which investor", "Investor identity is record-level data (data minimization)."),
    ("personal data", "Personal data is out of scope for this advisory surface."),
)

# Domain signal for the on-topic guard. A question must touch the DMT land /
# real-estate / planning / transport domain to reach a model. Off-topic questions
# abstain instantly (before any LLM call) — fast, and no off-corpus invention.
_DOMAIN_SIGNAL: frozenset[str] = frozenset(
    {
        "dmt",
        "land",
        "parcel",
        "plot",
        "real estate",
        "real-estate",
        "property",
        "price",
        "pricing",
        "rent",
        "valuation",
        "value",
        "benchmark",
        "comparable",
        "mussafah",
        "abu dhabi",
        "al ain",
        "dhafra",
        "zoning",
        "masterplan",
        "plan abu dhabi",
        "estidama",
        "pearl",
        "sustainab",
        "livability",
        "esg",
        "investor",
        "investment",
        "irr",
        "yield",
        "return",
        "mandate",
        "swf",
        "kyc",
        "archetype",
        "musataha",
        "lease",
        "tenure",
        "adrec",
        "tawtheeq",
        "escrow",
        "register",
        "registration",
        "title deed",
        "ownership",
        "jop",
        "permit",
        "licence",
        "license",
        "occupancy",
        "meps",
        "dcr",
        "building",
        "construction",
        "scenario",
        "phasing",
        "sequencing",
        "staging",
        "demand",
        "absorption",
        "market",
        "transaction",
        "geopolitic",
        "sanction",
        "fatf",
        "risk",
        "stakeholder",
        "mou",
        "government",
        "transport",
        "mobility",
        "infrastructure",
        "development",
        "developer",
        "waterfront",
        "industrial",
        "mixed-use",
        "residential",
        "foresight",
        "supply",
        "affordable",
        "housing",
        "public realm",
    }
)

_OFF_TOPIC_TEXT = (
    "I can only answer from governed DMT sources about land, parcels, pricing, "
    "scenarios, permits, registry, demand, and transport. That question is outside "
    "this platform's domain. Try asking about a DMT parcel, a pricing benchmark, or "
    "an approval step."
)


def _lowest_confidence(citations: list[Citation]) -> Confidence | None:
    """Map retrieved evidence to a confidence, inheriting the weakest input."""
    if not citations:
        return None
    weakest = min(c.score for c in citations)
    if weakest >= 0.75:
        return "high"
    if weakest >= 0.5:
        return "medium"
    return "low"


def _evidence(citations: list[Citation]) -> list[CouncilEvidence]:
    """Map the governing citations to chunk-level evidence (provenance a decision
    links to — the exact retrieval chunk, its tier, its similarity score)."""
    return [
        CouncilEvidence(
            chunk_id=c.chunk_id,
            canonical_file=c.canonical_file,
            tier=c.tier,
            score=c.score,
        )
        for c in citations
    ]


def _merge_confidence(levels: list[Confidence | None]) -> Confidence | None:
    """The synthesis inherits the lowest confidence across contributions."""
    order = {"low": 0, "medium": 1, "high": 2}
    present = [level for level in levels if level is not None]
    if not present:
        return None
    return min(present, key=lambda level: order[level])


class CouncilService:
    """Run governed council turns against the registry + retrieval + inference."""

    def __init__(
        self,
        registry: CouncilRegistry,
        inference: InferenceService,
        retrieval: RetrievalService | None,
        *,
        require_grounding: bool = True,
        pricing: PricingTool | None = None,
        brief: BriefTool | None = None,
        metrics: CouncilMetricsStore | None = None,
    ) -> None:
        self._registry = registry
        self._inference = inference
        self._retrieval = retrieval
        self._require_grounding = require_grounding
        self._pricing = pricing if pricing is not None and pricing.configured else None
        self._brief = brief if brief is not None and brief.configured else None
        self._metrics = metrics if metrics is not None and metrics.configured else None
        # Token accounting for the current turn (reset per run_turn; presence/audit).
        self._usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}

    def metrics(self) -> dict[str, Any]:
        """Per-expert + council-wide governance KPIs from the recorded turns.

        Returns ``available: false`` when no metrics store is configured or no turn
        has been recorded yet — a visible empty state, never invented numbers.
        """
        if self._metrics is None:
            return {"available": False, "council": {"total_turns": 0}, "experts": []}
        return self._metrics.aggregate(self._registry.list())

    @property
    def pricing(self) -> PricingTool | None:
        """The governed pricing tool (None when unconfigured) — for the conflicts endpoint."""
        return self._pricing

    # --- roster & routing ----------------------------------------------------

    def roster(self) -> list[CouncilAgent]:
        """Return the canonical agents available to add to a conversation."""
        return self._registry.list()

    def custom_roster(self, store) -> list[CouncilAgent]:  # noqa: ANN001 - CustomAgentStore
        """Return the approved DMT-custom agents (F4) compiled into personas.

        The custom agents are the merged roster minus the canon (by id), so ordering
        or duplicates can never mislabel a curated agent as custom.
        """
        canon_ids = {a.agent_id for a in self._registry.list()}
        merged = self._registry.with_custom(store.approved_specs()).list()
        return [a for a in merged if a.agent_id not in canon_ids]

    def coverage(self) -> dict[str, Any]:
        """The council coverage surface: which domains the council can answer, with
        what confidence, derived deterministically from the routing table.

        For each routing domain this reports the owning experts (resolved to the
        roster), the governed tools that back them, and a confidence posture:
        the pricing domain carries a *grounded* confidence (deal benchmarks) while
        domains without a governed tool are *retrieval-grounded* (advisory). It also
        surfaces any detected pricing-band conflicts so the dashboard can flag them.
        This is the "what does the council cover, and how well" answer — built from
        the same table that routes real queries, so it can never drift from reality.
        """
        roster_by_id = {a.agent_id: a for a in self._registry.list()}
        grounded = self._pricing is not None
        brief_grounded = self._brief is not None
        conflicts = self._pricing.conflicts() if self._pricing else []
        domains: list[dict[str, Any]] = []
        for keywords, expert_ids in _ROUTING_TABLE:
            experts = []
            for eid in expert_ids:
                agent = roster_by_id.get(eid)
                experts.append(
                    {
                        "agent_id": eid,
                        "display_name": agent.display_name if agent else eid,
                        "available": agent is not None,
                    }
                )
            uses_pricing = any(k in _PRICING_DOMAIN_KEYWORDS for k in keywords)
            uses_brief = any(k in _BRIEF_DOMAIN_KEYWORDS for k in keywords)
            is_governed = (uses_pricing and grounded) or (uses_brief and brief_grounded)
            domains.append(
                {
                    "domain": _domain_label(keywords),
                    "keywords": list(keywords),
                    "experts": experts,
                    "grounding": "governed" if is_governed else "retrieval",
                    "confidence": "high" if is_governed else "advisory",
                }
            )
        return {
            "domain_count": len(domains),
            "expert_count": sum(1 for a in self._registry.list() if a.kind == "expert"),
            "pricing_grounded": grounded,
            "brief_grounded": brief_grounded,
            "pricing_conflicts": conflicts,
            "domains": domains,
        }

    def resolve_speaker(self, request: CouncilChatRequest) -> CouncilAgent:
        """Pick the single speaker (F1 path / streaming header): expert else Director."""
        if not self._registry.configured:
            raise InvalidRequestError("council registry is not configured")
        for agent_id in request.agents:
            agent = self._registry.get(agent_id)
            if agent is not None and agent.kind == "expert":
                return agent
        director = self._registry.director()
        if director is None:
            raise InvalidRequestError("council has no Director agent")
        return director

    def route_experts(self, request: CouncilChatRequest) -> list[CouncilAgent]:
        """Return the experts to fan out to for this turn (deterministic, capped).

        With no active roster the Director answers alone. Otherwise each requested
        expert whose tool grants intersect the routed domain tools is selected; if
        nothing matches, the first requested expert answers (still grounded in
        retrieval). With ``delegate`` and no explicit roster, the Director picks
        from the full roster (council active without hand-picking). The result is
        capped at ``_MAX_FANOUT`` (cost governance).
        """
        if not self._registry.configured:
            raise InvalidRequestError("council registry is not configured")
        requested: list[CouncilAgent] = []
        for agent_id in request.agents:
            agent = self._registry.get(agent_id)
            if agent is not None and agent.kind == "expert":
                requested.append(agent)
        # Director-delegation: no explicit roster -> route across the full roster.
        if not requested and request.delegate:
            requested = [a for a in self._registry.list() if a.kind == "expert"]
        if not requested:
            return []
        routed = self._routed_experts(self._last_user_query(request))
        # Preserve the routing-table lead order, then keep the rest of the roster.
        selected = [a for a in requested if a.agent_id in routed]
        chosen = selected or requested[:1]
        return chosen[:_MAX_FANOUT]

    @staticmethod
    def _routed_experts(query: str) -> frozenset[str]:
        """Map the user query to the expert ids it touches (deterministic).

        A question can span several domains ("price and return?"); accumulate every
        matching domain's experts so the Director routes to all relevant voices.
        """
        lowered = query.lower()
        experts: set[str] = set()
        for patterns, agent_ids in _ROUTING_TABLE:
            if any(p in lowered for p in patterns):
                experts.update(agent_ids)
        return frozenset(experts)

    def check_veto(self, request: CouncilChatRequest) -> CouncilVeto | None:
        """Pre-inference governance gate. Returns a veto to block, else ``None``."""
        query = self._last_user_query(request).lower()
        for needle, reason in _VETO_PATTERNS:
            if needle in query:
                _logger.warning("council_veto", extra={"needle": needle})
                return CouncilVeto(gate="compliance-data-governance", reason=reason)
        return None

    def _is_on_topic(self, query: str) -> bool:
        """Whether the query touches the DMT domain (the on-topic guard)."""
        lowered = query.lower()
        return any(signal in lowered for signal in _DOMAIN_SIGNAL)

    def _off_topic_response(
        self, request: CouncilChatRequest, agent_id: str
    ) -> CouncilChatResponse:
        """An instant, visible abstention for an off-domain question (no model call)."""
        return CouncilChatResponse(
            id=f"council-{uuid.uuid4().hex}",
            conversation_id=request.conversation_id,
            model=request.model,
            messages=[
                CouncilMessage(
                    agent_id=agent_id,
                    content=_OFF_TOPIC_TEXT,
                    sources=[],
                    confidence=None,
                    abstained=True,
                )
            ],
            meta=TurnMeta(participants=[agent_id], rounds=0, **self._usage),
        )

    # --- grounding & inference ----------------------------------------------

    @staticmethod
    def _last_user_query(request: CouncilChatRequest) -> str:
        """The most recent user turn — used for routing, veto and grounding."""
        return next((m.content for m in reversed(request.messages) if m.role == "user"), "")

    async def _ground(self, query: str) -> list[Citation]:
        """Retrieve governing evidence for the query (empty when unavailable)."""
        if self._retrieval is None or not self._retrieval.configured or not query.strip():
            return []
        try:
            return await self._retrieval.retrieve(query)
        except (RetrievalNotConfiguredError, UpstreamError) as exc:
            _logger.warning("council_grounding_failed", extra={"err": str(exc)})
            return []

    def _tool_citations(self, query: str) -> list[Citation]:
        """Run governed read-only tools (pricing, …) and map results to citations.

        These are the credibility surface: a pricing question returns the real
        benchmark band with its confidence, injected as authoritative evidence so
        the expert cites a governed figure instead of abstaining.
        """
        if (self._pricing is None and self._brief is None) or not query.strip():
            return []
        results = run_governed_tools(query, self._pricing, self._brief)
        citations: list[Citation] = []
        for r in results:
            conf_score = {"high": 0.95, "medium": 0.75, "low": 0.5}.get(r.confidence, 0.5)
            citations.append(
                Citation(
                    chunk_id=f"tool:{r.tool}",
                    canonical_file=r.source,
                    domain="governed-tool",
                    tier="authoritative",
                    score=conf_score,
                    text=r.text,
                )
            )
        return citations

    def _requires_grounding(self) -> bool:
        """Whether a council answer must be grounded (retrieval live + policy on)."""
        return (
            self._require_grounding and self._retrieval is not None and self._retrieval.configured
        )

    def _build_inference_request(
        self, agent: CouncilAgent, request: CouncilChatRequest, citations: list[Citation]
    ) -> ChatCompletionRequest:
        """Assemble the grounded, in-persona inference request for one agent."""
        system = f"{_DMT_IDENTITY}\n\n{agent.compose_system_prompt()}"
        # Director-as-coworker: ground the answer in the user's own work context
        # (role, goal, current module, pending items) so personal questions get a
        # personal answer, not a generic abstention. Advisory; no governed figures.
        if request.user_context.strip():
            system += (
                "\n\nThe signed-in user's current work context follows. Use it to make the "
                "answer personal and actionable — reference their role, goal, current module "
                "and pending/pinned items when relevant. Answer as a coworker who knows what "
                "they are working on.\n[user work context]\n" + request.user_context.strip()
            )
        messages: list[ChatMessage] = [ChatMessage(role="system", content=system)]
        for citation in citations:
            if not citation.text:
                continue
            header = f"[source: {citation.canonical_file} | tier: {citation.tier}]"
            messages.append(ChatMessage(role="tool", content=f"{header}\n{citation.text}"))
        messages.extend(
            ChatMessage(role=m.role, content=m.content)
            for m in request.messages
            if m.role in ("user", "assistant")
        )
        return ChatCompletionRequest(
            model=request.model,
            messages=messages,
            max_tokens=effort_max_tokens(request.effort, request.max_tokens),
            require_grounding=self._requires_grounding(),
        )

    async def _agent_turn(
        self, agent: CouncilAgent, request: CouncilChatRequest, citations: list[Citation]
    ) -> CouncilMessage:
        """Run one expert's grounded turn -> its governed message."""
        completion = await self._inference.chat(
            self._build_inference_request(agent, request, citations), role=agent.kind
        )
        self._record_usage(completion.usage)
        content = completion.choices[0].message.content if completion.choices else ""
        abstained = completion.abstained
        return CouncilMessage(
            agent_id=agent.agent_id,
            content=_ABSTENTION_TEXT if abstained and not content.strip() else content,
            sources=sorted({c.canonical_file for c in citations}),
            evidence=_evidence(citations),
            confidence=_lowest_confidence(citations),
            abstained=abstained,
        )

    async def stream_single_turn(
        self, request: CouncilChatRequest
    ) -> AsyncIterator[tuple[str, str, CouncilMessage | None]]:
        """Stream a single-speaker turn token-by-token (the interactive path).

        Yields ``("token", delta, None)`` per delta, then ``("done", "", message)``
        with the assembled governed message. Abstention and veto resolve before any
        token is yielded (governance first).
        """
        veto = self.check_veto(request)
        if veto is not None:
            yield ("veto", "", None)
            return
        self._usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        speaker = self.resolve_speaker(request)
        query = self._last_user_query(request)
        # On-topic guard: an off-domain question abstains instantly (no model call).
        if not self._is_on_topic(query):
            yield ("done", "", self._off_topic_response(request, speaker.agent_id).messages[0])
            return
        citations = await self._ground(query) + self._tool_citations(query)
        if self._requires_grounding() and not citations:
            yield ("done", "", self._abstention_response(request, speaker.agent_id).messages[0])
            return

        inference_request = self._build_inference_request(speaker, request, citations)
        collected = ""
        usage: dict[str, int] = {}
        async for delta in self._inference.chat_stream_for_role(
            inference_request, speaker.kind, usage
        ):
            collected += delta
            yield ("token", delta, None)
        # Token accounting for the streamed turn (cost audit + the CLI footer).
        self._record_usage_dict(usage)
        message = CouncilMessage(
            agent_id=speaker.agent_id,
            content=collected,
            sources=sorted({c.canonical_file for c in citations}),
            evidence=_evidence(citations),
            confidence=_lowest_confidence(citations),
            abstained=False,
        )
        yield ("done", "", message)

    def _record_usage(self, usage) -> None:  # noqa: ANN001 - Usage schema
        """Accumulate token usage for the current turn (cost governance / audit)."""
        self._usage["prompt_tokens"] += usage.prompt_tokens
        self._usage["completion_tokens"] += usage.completion_tokens
        self._usage["total_tokens"] += usage.total_tokens

    def _record_usage_dict(self, usage: dict[str, int]) -> None:
        """Accumulate token usage from a plain dict (the streaming usage_out)."""
        for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
            self._usage[key] += int(usage.get(key, 0) or 0)

    def current_usage(self) -> dict[str, int]:
        """The accumulated token usage for the in-flight turn (read by the SSE layer)."""
        return dict(self._usage)

    def _build_synthesis_request(
        self, request: CouncilChatRequest, contributions: list[CouncilMessage]
    ) -> ChatCompletionRequest:
        """Build the Director's synthesis request (persona + user turn + contributions)."""
        director = self._registry.director()
        system = (
            director.compose_system_prompt()
            if director is not None
            else "You are the Director. Synthesize the experts into one decision-grade answer."
        )
        system += (
            "\n\nYou are synthesizing your council's contributions into ONE final "
            "answer the user reads. Lead with a crisp executive summary of the decision "
            "or answer (2-3 sentences), then the key points reconciled across experts, "
            "then the decisive tradeoff or caveat. Reconcile conflicts, keep every figure "
            "tied to its source and confidence, and never introduce a figure no expert "
            "grounded. If the experts could not ground an answer, abstain visibly."
        )
        lines = [
            f"[{c.agent_id} | confidence: {c.confidence or 'n/a'} | sources: "
            f"{', '.join(c.sources) or 'none'}]\n{c.content}"
            for c in contributions
        ]
        contributions_text = "\n\n".join(lines)
        messages: list[ChatMessage] = [ChatMessage(role="system", content=system)]
        messages.extend(
            ChatMessage(role=m.role, content=m.content)
            for m in request.messages
            if m.role in ("user", "assistant")
        )
        messages.append(
            ChatMessage(
                role="user",
                content=(
                    "Council contributions to my question:\n\n"
                    f"{contributions_text}\n\nNow synthesize one decision-grade answer."
                    f"{_NO_THINK_DIRECTIVE}"
                ),
            )
        )
        return ChatCompletionRequest(
            model=request.model,
            messages=messages,
            max_tokens=effort_max_tokens(request.effort, request.max_tokens),
            require_grounding=False,  # synthesis grounds in the experts' contributions
        )

    def _director_id(self, request: CouncilChatRequest) -> str:
        """The Director's id (for synthesis), falling back to the resolved speaker."""
        director = self._registry.director()
        return director.agent_id if director is not None else self.resolve_speaker(request).agent_id

    def _build_deliberation_request(
        self,
        agent: CouncilAgent,
        request: CouncilChatRequest,
        others: list[CouncilMessage],
    ) -> ChatCompletionRequest:
        """Ask one expert to react to the other experts' contributions (Director-mediated)."""
        peers = "\n\n".join(
            f"[{o.agent_id} | confidence: {o.confidence or 'n/a'}]\n{o.content}" for o in others
        )
        system = (
            agent.compose_system_prompt()
            + "\n\nThe Director has shared your fellow experts' contributions below. React "
            "briefly in your own voice: agree, challenge, or refine from your domain, and "
            "say which contribution you are responding to. Stay grounded; never introduce "
            "an un-sourced figure."
        )
        messages: list[ChatMessage] = [ChatMessage(role="system", content=system)]
        messages.extend(
            ChatMessage(role=m.role, content=m.content)
            for m in request.messages
            if m.role in ("user", "assistant")
        )
        messages.append(
            ChatMessage(
                role="user",
                content=f"Your fellow experts answered:\n\n{peers}\n\nReact from your domain.",
            )
        )
        return ChatCompletionRequest(
            model=request.model,
            messages=messages,
            max_tokens=effort_max_tokens(request.effort, request.max_tokens),
            require_grounding=False,
        )

    async def _deliberate(
        self,
        experts: list[CouncilAgent],
        request: CouncilChatRequest,
        contributions: list[CouncilMessage],
    ) -> list[CouncilMessage]:
        """One Director-mediated deliberation round: each expert reacts to the others.

        Returns the follow-up messages (each ``reply_to`` the other contributors). The
        Director mediates — experts never call each other directly. Abstaining experts
        do not deliberate. Cost-bounded by the fan-out cap.
        """
        speaking = [c for c in contributions if not c.abstained]
        if len(speaking) < 2:
            return []

        async def react(agent: CouncilAgent) -> CouncilMessage | None:
            own = next((c for c in speaking if c.agent_id == agent.agent_id), None)
            others = [c for c in speaking if c.agent_id != agent.agent_id]
            if own is None or not others:
                return None
            completion = await self._inference.chat(
                self._build_deliberation_request(agent, request, others), role=agent.kind
            )
            self._record_usage(completion.usage)
            content = completion.choices[0].message.content if completion.choices else ""
            if not content.strip():
                return None
            return CouncilMessage(
                agent_id=agent.agent_id,
                content=content,
                sources=own.sources,
                confidence=own.confidence,
                abstained=False,
                reply_to=[o.agent_id for o in others],
            )

        reactions = await asyncio.gather(*(react(e) for e in experts))
        return [r for r in reactions if r is not None]

    # --- turns ---------------------------------------------------------------

    async def run_turn(self, request: CouncilChatRequest) -> CouncilChatResponse:
        """Execute one governed turn and record its governance metrics (non-fatal)."""
        response = await self._run_turn_inner(request)
        if self._metrics is not None:
            self._metrics.record(response)
        return response

    async def _run_turn_inner(self, request: CouncilChatRequest) -> CouncilChatResponse:
        """Execute one governed turn (single-speaker or fan-out) and return it."""
        self._usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        veto = self.check_veto(request)
        if veto is not None:
            return CouncilChatResponse(
                id=f"council-{uuid.uuid4().hex}",
                conversation_id=request.conversation_id,
                model="blocked",
                veto=veto,
            )

        query = self._last_user_query(request)
        # On-topic guard: an off-domain question abstains instantly (no model call).
        if not self._is_on_topic(query):
            return self._off_topic_response(request, self.resolve_speaker(request).agent_id)
        experts = self.route_experts(request)

        # F1 path: no active experts -> the Director answers alone.
        if not experts:
            speaker = self.resolve_speaker(request)
            citations = await self._ground(query) + self._tool_citations(query)
            if self._requires_grounding() and not citations:
                return self._abstention_response(request, speaker.agent_id)
            message = await self._agent_turn(speaker, request, citations)
            return CouncilChatResponse(
                id=f"council-{uuid.uuid4().hex}",
                conversation_id=request.conversation_id,
                model=request.model,
                messages=[message],
                meta=TurnMeta(participants=[speaker.agent_id], rounds=1, **self._usage),
            )

        # F2/F3 path: fan out, optionally deliberate, then synthesize.
        citations = await self._ground(query) + self._tool_citations(query)
        if self._requires_grounding() and not citations:
            return self._abstention_response(request, experts[0].agent_id)
        contributions = list(
            await asyncio.gather(
                *(self._agent_turn(expert, request, citations) for expert in experts)
            )
        )
        rounds = 1
        reactions: list[CouncilMessage] = []
        if request.deliberate and len(experts) > 1:
            reactions = await self._deliberate(experts, request, contributions)
            if reactions:
                rounds = 2
        all_contributions = contributions + reactions
        synthesis = await self._synthesize(request, all_contributions, citations)
        participants = [e.agent_id for e in experts] + [self._director_id(request)]
        return CouncilChatResponse(
            id=f"council-{uuid.uuid4().hex}",
            conversation_id=request.conversation_id,
            model=request.model,
            messages=all_contributions,
            synthesis=synthesis,
            meta=TurnMeta(participants=participants, rounds=rounds, **self._usage),
        )

    def _recorded(self, response: CouncilChatResponse) -> CouncilChatResponse:
        """Record the turn's governance metrics (non-fatal) and return it unchanged."""
        if self._metrics is not None:
            self._metrics.record(response)
        return response

    async def stream_fanout_turn(
        self, request: CouncilChatRequest
    ) -> AsyncIterator[tuple[str, Any]]:
        """Stream a governed fan-out turn progressively, yielding the final response last.

        Governance is identical to :meth:`run_turn` — same veto/on-topic/grounding gates
        and helpers; only delivery is incremental so each expert is emitted the moment it
        finishes (and the synthesis right after) instead of after the whole turn resolves.
        Event kinds: ``veto`` (a Veto), ``message`` (a lone off-topic/abstention message),
        ``expert`` and ``synthesis`` (a CouncilMessage), then ``final`` (the assembled
        CouncilChatResponse, for message_done + auditing). Metrics are recorded here.
        """
        self._usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        veto = self.check_veto(request)
        if veto is not None:
            blocked = CouncilChatResponse(
                id=f"council-{uuid.uuid4().hex}",
                conversation_id=request.conversation_id,
                model="blocked",
                veto=veto,
            )
            yield ("veto", veto)
            yield ("final", self._recorded(blocked))
            return

        query = self._last_user_query(request)
        if not self._is_on_topic(query):
            response = self._off_topic_response(request, self.resolve_speaker(request).agent_id)
            yield ("message", response.messages[0])
            yield ("final", self._recorded(response))
            return

        experts = self.route_experts(request)
        citations = await self._ground(query) + self._tool_citations(query)
        if self._requires_grounding() and not citations:
            fallback = experts[0].agent_id if experts else self.resolve_speaker(request).agent_id
            response = self._abstention_response(request, fallback)
            yield ("message", response.messages[0])
            yield ("final", self._recorded(response))
            return

        # Fan out; emit each expert the moment it completes (progressive delivery),
        # but keep the final message order deterministic (expert order, not completion).
        pending = [asyncio.ensure_future(self._agent_turn(e, request, citations)) for e in experts]
        by_id: dict[str, CouncilMessage] = {}
        for future in asyncio.as_completed(pending):
            message = await future
            by_id[message.agent_id] = message
            yield ("expert", message)
        contributions = [by_id[e.agent_id] for e in experts]

        rounds = 1
        reactions: list[CouncilMessage] = []
        if request.deliberate and len(experts) > 1:
            reactions = await self._deliberate(experts, request, contributions)
            for reaction in reactions:
                yield ("expert", reaction)
            if reactions:
                rounds = 2

        all_contributions = contributions + reactions
        # Stream the Director's synthesis live so the main answer appears as it is
        # generated (not after the full ~8-16s), then assemble the governed message.
        director_id = self._director_id(request)
        yield ("synthesis_start", director_id)
        if all(c.abstained for c in all_contributions):
            synthesis = self._synthesis_message(
                request, all_contributions, citations, _ABSTENTION_TEXT, abstained=True
            )
        else:
            usage: dict[str, int] = {}
            content = ""
            async for delta in self._inference.chat_stream_for_role(
                self._build_synthesis_request(request, all_contributions), "director", usage
            ):
                content += delta
                yield ("synthesis_token", delta)
            self._usage["prompt_tokens"] += usage.get("prompt_tokens", 0)
            self._usage["completion_tokens"] += usage.get("completion_tokens", 0)
            self._usage["total_tokens"] += usage.get("total_tokens", 0)
            synthesis = self._synthesis_message(
                request, all_contributions, citations, content, abstained=False
            )
        yield ("synthesis", synthesis)
        participants = [e.agent_id for e in experts] + [director_id]
        response = CouncilChatResponse(
            id=f"council-{uuid.uuid4().hex}",
            conversation_id=request.conversation_id,
            model=request.model,
            messages=all_contributions,
            synthesis=synthesis,
            meta=TurnMeta(participants=participants, rounds=rounds, **self._usage),
        )
        yield ("final", self._recorded(response))

    async def _synthesize(
        self,
        request: CouncilChatRequest,
        contributions: list[CouncilMessage],
        citations: list[Citation],
    ) -> CouncilMessage:
        """The Director reconciles the experts' contributions into one answer."""
        # If every expert abstained, abstain without a synthesis model call.
        if all(c.abstained for c in contributions):
            return self._synthesis_message(
                request, contributions, citations, _ABSTENTION_TEXT, abstained=True
            )
        completion = await self._inference.chat(
            self._build_synthesis_request(request, contributions)
        )
        self._record_usage(completion.usage)
        content = completion.choices[0].message.content if completion.choices else ""
        return self._synthesis_message(
            request, contributions, citations, content, abstained=completion.abstained
        )

    def _synthesis_message(
        self,
        request: CouncilChatRequest,
        contributions: list[CouncilMessage],
        citations: list[Citation],
        content: str,
        *,
        abstained: bool,
    ) -> CouncilMessage:
        """Assemble the Director's synthesis message under the governed confidence model."""
        director_id = self._director_id(request)
        if abstained:
            return CouncilMessage(
                agent_id=director_id, content=content, sources=[], confidence=None, abstained=True
            )
        sources = sorted({s for c in contributions for s in c.sources})
        # External content is never merged into the governed confidence model: if any
        # contribution relied on an external/unverified source, the synthesis is capped
        # at ``low`` and the source is explicitly labelled.
        external_used = any("external" in s or s.startswith("http") for s in sources)
        confidence = _merge_confidence([c.confidence for c in contributions]) or _lowest_confidence(
            citations
        )
        if external_used:
            confidence = "low"
        return CouncilMessage(
            agent_id=director_id,
            content=content,
            sources=sources,
            confidence=confidence,
            abstained=False,
        )

    def _abstention_response(
        self, request: CouncilChatRequest, agent_id: str
    ) -> CouncilChatResponse:
        """The hard grounding gate: a visible abstention, no model called."""
        return CouncilChatResponse(
            id=f"council-{uuid.uuid4().hex}",
            conversation_id=request.conversation_id,
            model="abstained",
            messages=[
                CouncilMessage(
                    agent_id=agent_id,
                    content=_ABSTENTION_TEXT,
                    sources=[],
                    confidence=None,
                    abstained=True,
                )
            ],
        )


def sse_event(event: str, data: str) -> bytes:
    """Encode one Server-Sent-Events frame."""
    return f"event: {event}\ndata: {data}\n\n".encode()


def monotonic_ms() -> int:
    """Wall-clock epoch milliseconds (message timestamps)."""
    return int(time.time() * 1000)
