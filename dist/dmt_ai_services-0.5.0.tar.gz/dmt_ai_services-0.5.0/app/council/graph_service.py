"""Personal Graph service — backed by Semantica's ContextGraph.

Each signed-in user has their own ContextGraph: every entity they work with
(parcel, scenario, investor, note, decision) is a node with full provenance
(`valid_from`/`valid_until`, source) and every relationship an edge. Decisions
the Director helps with are first-class, auditable objects (record_decision →
trace_decision_chain).

Why Semantica: it gives us temporal, provenance-tracked, decision-aware graphs
out of the box — the governance invariants (explainable, auditable, sovereign)
are native, not bolted on. We import only the `context` module (no heavy extras)
and self-host inside the UAE boundary.

The service exposes a plain nodes/edges model for the frontend canvas (the
Obsidian-style Personal Graph), mapped from the ContextGraph.
"""

from __future__ import annotations

import json
import threading
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def _new_graph():  # lazy import so the app starts even if semantica is absent
    from semantica.context import ContextGraph

    return ContextGraph()


class PersonalGraphService:
    """Per-user ContextGraph store with provenance + decision recording.

    Persisted as JSON per user (the ContextGraph's to_dict). Thread-safe.
    """

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._lock = threading.Lock()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        if not self._path.exists():
            self._write({})

    def _read(self) -> dict[str, Any]:
        try:
            return json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}

    def _write(self, data: dict[str, Any]) -> None:
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(self._path)

    def _load_graph(self, user_id: str):  # -> ContextGraph
        g = _new_graph()
        stored = self._read().get(user_id)
        if stored:
            for n in stored.get("nodes", []):
                # Restore temporal provenance (valid_from / valid_until) so the
                # graph remembers when each fact was true (point-in-time reads).
                g.add_node(
                    n["id"],
                    n.get("type", "note"),
                    content=n.get("content", ""),
                    valid_from=n.get("valid_from"),
                    valid_until=n.get("valid_until"),
                )
            for e in stored.get("edges", []):
                g.add_edge(e["source"], e["target"], edge_type=e.get("type", "related_to"))
        return g

    def _save_graph(self, user_id: str, g) -> None:  # g: ContextGraph
        with self._lock:
            data = self._read()
            d = g.to_dict()
            data[user_id] = {
                "nodes": d.get("nodes", {}),
                "edges": d.get("edges", []),
                "updated_at": _now_iso(),
            }
            self._write(data)

    def record_activity(
        self, user_id: str, kind: str, label: str, ref: str = "", module: str = ""
    ) -> dict[str, Any]:
        """Add a work entity to the user's graph (grows as they work)."""
        g = self._load_graph(user_id)
        node_type = (
            "scenario"
            if module == "scenarios"
            else "investor"
            if module == "investors"
            else "parcel"
            if module in ("parcels", "map")
            else "note"
        )
        node_id = ref or f"{node_type}:{label}"
        # Temporal provenance: stamp when the entity entered the user's graph
        # (the graph remembers when each fact became true — Semantica valid_from).
        g.add_node(
            node_id,
            node_type,
            content=label,
            module=module,
            recorded_at=_now_iso(),
            valid_from=_now_iso(),
        )
        if module:
            g.add_node(f"module:{module}", "module", content=module, valid_from=_now_iso())
            g.add_edge(node_id, f"module:{module}", edge_type="in")
        self._save_graph(user_id, g)
        return self.to_frontend(user_id)

    def record_decision(
        self,
        user_id: str,
        category: str,
        scenario: str,
        reasoning: str,
        outcome: str,
        confidence: float,
        evidence: list[dict[str, Any]] | None = None,
    ) -> str:
        """Record a governed decision in the user's graph (auditable), linked to
        the evidence that supports it — the context-graph "what is connected, why,
        and how": the decision traverses to the exact chunks that ground it."""
        g = self._load_graph(user_id)
        decision_id = g.record_decision(
            category=category,
            scenario=scenario,
            reasoning=reasoning,
            outcome=outcome,
            confidence=confidence,
        )
        # Link the decision to the evidence chunks that ground it (provenance).
        for ev in evidence or []:
            src = ev.get("source") or ev.get("canonical_file", "")
            if not src:
                continue
            ev_id = f"evidence:{src}"
            g.add_node(
                ev_id,
                "evidence",
                content=ev.get("label", src),
                confidence=ev.get("confidence", "reference"),
            )
            g.add_edge(decision_id, ev_id, edge_type="supported_by")
            g.add_edge(ev_id, decision_id, edge_type="evidence_for")
        self._save_graph(user_id, g)
        return decision_id

    def add_evidence(
        self,
        user_id: str,
        entity_id: str,
        sources: list[dict[str, Any]],
    ) -> None:
        """Link an entity to the source documents that evidence it (provenance)."""
        g = self._load_graph(user_id)
        stored_nodes = {n["id"] for n in self._read().get(user_id, {}).get("nodes", [])}
        if entity_id not in stored_nodes:
            return
        for s in sources:
            src = s.get("source") or s.get("canonical_file", "")
            if not src:
                continue
            ev_id = f"evidence:{src}"
            g.add_node(ev_id, "evidence", content=s.get("label", src))
            g.add_edge(entity_id, ev_id, edge_type="supported_by")
        self._save_graph(user_id, g)

    # --- Enterprise intelligence (Semantica full surface) --------------------

    def insights(self, user_id: str) -> dict[str, Any]:
        """Graph intelligence: the most-connected entities (the hubs the user's
        work clusters around), a per-kind breakdown, and the largest cluster."""
        stored = self._read().get(user_id, {})
        nodes = stored.get("nodes", [])
        edges = stored.get("edges", [])
        out: dict[str, Any] = {
            "node_count": len(nodes),
            "edge_count": len(edges),
            "hubs": [],
            "kinds": {},
            "largest_cluster": 0,
        }
        if not nodes:
            return out
        # Degree centrality over the stored edges (deterministic, no extra deps).
        degree: dict[str, int] = {}
        for e in edges:
            degree[e["source"]] = degree.get(e["source"], 0) + 1
            degree[e["target"]] = degree.get(e["target"], 0) + 1
        max_deg = max(degree.values(), default=1) or 1
        scored = [
            {
                "id": n["id"],
                "label": n.get("content", n["id"]),
                "kind": n.get("type", "note"),
                "centrality": round(degree.get(n["id"], 0) / max_deg, 4),
                "degree": degree.get(n["id"], 0),
            }
            for n in nodes
        ]
        scored.sort(key=lambda x: (x["centrality"], x["degree"]), reverse=True)
        out["hubs"] = scored[:8]
        # Per-kind breakdown (how the user's work splits across entity types).
        kinds: dict[str, int] = {}
        for n in nodes:
            kinds[n.get("type", "note")] = kinds.get(n.get("type", "note"), 0) + 1
        out["kinds"] = kinds
        # Largest connected cluster (how much of the graph is one workstream).
        out["largest_cluster"] = self._largest_cluster(nodes, edges)
        return out

    @staticmethod
    def _largest_cluster(nodes: list[dict], edges: list[dict]) -> int:
        """Size of the largest connected component (union-find, deterministic)."""
        parent = {n["id"]: n["id"] for n in nodes}

        def find(x: str) -> str:
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        for e in edges:
            if e["source"] in parent and e["target"] in parent:
                parent[find(e["source"])] = find(e["target"])
        sizes: dict[str, int] = {}
        for n in nodes:
            root = find(n["id"])
            sizes[root] = sizes.get(root, 0) + 1
        return max(sizes.values(), default=0)

    def trace_decision(self, user_id: str, decision_id: str) -> dict[str, Any]:
        """The causal chain behind a decision (the audit trail)."""
        g = self._load_graph(user_id)
        try:
            chain = g.trace_decision_causality(decision_id)
        except Exception:  # noqa: BLE001
            chain = None
        return {"decision_id": decision_id, "chain": chain if chain is not None else []}

    def similar_decisions(self, user_id: str, scenario: str) -> list[dict[str, Any]]:
        """Find precedent decisions for a scenario (consistency over time)."""
        g = self._load_graph(user_id)
        try:
            return g.find_similar_decisions(scenario, max_results=5)
        except Exception:  # noqa: BLE001
            return []

    def decisions(self, user_id: str) -> list[dict[str, Any]]:
        """The user's recorded decisions (the auditable decision log)."""
        g = self._load_graph(user_id)
        try:
            summary = g.get_decision_summary()
        except Exception:  # noqa: BLE001
            summary = {}
        return summary.get("decisions", []) if isinstance(summary, dict) else []

    def explore_node(self, user_id: str, node_id: str, hops: int = 2) -> dict[str, Any]:
        """The neighbourhood around a node (multi-hop) — the 'what connects to
        this, and what connects to that' explorer view (Obsidian-style)."""
        g = self._load_graph(user_id)
        stored = self._read().get(user_id, {})
        nodes_by_id = {n["id"]: n for n in stored.get("nodes", [])}
        if node_id not in nodes_by_id:
            return {"node": None, "neighbors": []}
        try:
            raw = g.get_neighbors(node_id, hops=hops)
        except Exception:  # noqa: BLE001
            raw = []
        neighbors = [
            {
                "id": (n.get("id") if isinstance(n, dict) else str(n)),
                "label": nodes_by_id.get(n.get("id") if isinstance(n, dict) else str(n), {}).get(
                    "content", n.get("id") if isinstance(n, dict) else str(n)
                ),
                "kind": nodes_by_id.get(n.get("id") if isinstance(n, dict) else str(n), {}).get(
                    "type", "note"
                ),
            }
            for n in raw
        ]
        node = nodes_by_id[node_id]
        return {
            "node": {
                "id": node_id,
                "label": node.get("content", node_id),
                "kind": node.get("type", "note"),
            },
            "neighbors": neighbors,
        }

    @staticmethod
    def _valid_on(node: dict[str, Any], as_of: str) -> bool:
        """True when the node was valid at the as_of instant (temporal filter).

        valid_from <= as_of and (no valid_until or valid_until > as_of).
        String ISO-8601 comparison is chronologically correct for UTC stamps.
        """
        vf = node.get("valid_from")
        vu = node.get("valid_until")
        if vf and vf > as_of:
            return False  # not yet true
        return not (vu and vu <= as_of)  # already closed

    def snapshot(self, user_id: str, as_of: str) -> dict[str, Any]:
        """The graph as it was at a point in time (the temporal model).

        Filters nodes by temporal validity (valid_from/valid_until) and keeps only
        the edges whose endpoints both existed then. This is what makes a council
        decision auditable against *what was known at the time*.
        """
        stored = self._read().get(user_id, {})
        nodes = [n for n in stored.get("nodes", []) if self._valid_on(n, as_of)]
        live_ids = {n["id"] for n in nodes}
        edges = [
            e
            for e in stored.get("edges", [])
            if e["source"] in live_ids and e["target"] in live_ids
        ]
        return {
            "as_of": as_of,
            "node_count": len(nodes),
            "edge_count": len(edges),
            "nodes": nodes,
            "edges": edges,
        }

    def to_frontend(self, user_id: str) -> dict[str, Any]:
        """Map the user's ContextGraph to the frontend nodes/edges model."""
        stored = self._read().get(user_id, {})
        nodes = stored.get("nodes", [])  # list of {id, type, content, properties, metadata}
        edges = stored.get("edges", [])  # list of {source_id, target_id, edge_type}
        return {
            "nodes": {
                n["id"]: {
                    "id": n["id"],
                    "kind": n.get("type", "note"),
                    "label": n.get("content", n["id"]),
                    "module": (n.get("properties") or {}).get("module"),
                }
                for n in nodes
            },
            "edges": {
                f"{e['source']}->{e.get('type', 'related_to')}->{e['target']}": {
                    "id": f"{e['source']}->{e.get('type', 'related_to')}->{e['target']}",
                    "source": e["source"],
                    "target": e["target"],
                    "relation": e.get("type", "related_to"),
                }
                for e in edges
            },
        }
