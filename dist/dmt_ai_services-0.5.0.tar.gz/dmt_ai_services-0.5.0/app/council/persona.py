"""Persona compiler: turn a versioned ``.agent.md`` into a runtime council agent.

The source of truth for a council personality is the versioned ``.agent.md`` file
in ``dmt-agents``. This module compiles it into an immutable :class:`CouncilAgent`:
identity, lens, read-only tool grants, the model tier, and the composed system
prompt. Personas are never free-typed at runtime — they are compiled and cached.

The compiler is deliberately stdlib-only (no YAML dependency): it parses the small
front-matter block and the markdown body by hand, which keeps the online service
profile lean and CI-friendly.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

_VALID_KINDS = {"director", "gate", "expert"}
_VALID_LENSES = {"sovereign", "investor", "both"}

# Tool grants are read-only and drawn from the governance provenance map. The
# registry fails to compile an agent that asks for anything outside this list.
ALLOWED_TOOLS = frozenset(
    {
        "retrieval.query",  # grounded corpus search (RAG)
        "pricing.query",  # read-only pricing benchmark (floor-enforced)
        "geopolitical.read",  # GET /v1/geopolitical
        "demand.read",  # GET /v1/demand
        "parcels.read",  # GET /v1/parcels
        "scenarios.read",  # GET /v1/scenarios
        "recommendation.read",  # GET /v1/recommendation
        "external.fetch",  # F5: governed, allow-listed external capture (tagged)
    }
)

_FRONT_MATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)

_GOVERNANCE_FOOTER = (
    "\n\n## Council runtime rules (non-negotiable)\n"
    "- You are advisory. You never produce a score, price, or decision; you explain\n"
    "  and draft using only the grounded context and your read-only tools.\n"
    "- Every figure you state must come from a governed source; name the source and\n"
    "  its confidence. If you have no grounded evidence, abstain visibly — never invent.\n"
    "- Stay inside your domain; defer to the Director for cross-domain synthesis.\n"
    "- Write in ASD-STE100 Simplified Technical English: short sentences, one idea\n"
    "  per sentence, common words, active voice. The reader is a DMT decision-maker,\n"
    "  not a specialist. Be direct, fluid, and easy to read. No jargon, no filler.\n"
    "- Keep a formal government register: no emojis, no emoticons, no exclamation\n"
    "  marks, no casual slang. This is a government decision surface."
)


def _slugify(text: str) -> str:
    """Lowercase, hyphen-free-ish slug used as the stable agent id."""
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return re.sub(r"-{2,}", "-", slug)


def _parse_front_matter(raw: str) -> tuple[dict[str, str], str]:
    """Split a ``.agent.md`` into (front-matter dict, body). Lenient, stdlib-only."""
    match = _FRONT_MATTER_RE.match(raw)
    if not match:
        return {}, raw
    meta: dict[str, str] = {}
    for line in match.group(1).splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        meta[key.strip().lower()] = value.strip().strip('"').strip("'")
    return meta, raw[match.end() :]


def _first_paragraph(body: str) -> str:
    """Return the first non-heading, non-empty paragraph — used as the description."""
    for block in body.split("\n\n"):
        text = " ".join(
            line.strip()
            for line in block.splitlines()
            if line.strip() and not line.strip().startswith(("#", "-", "|", ">"))
        )
        if text:
            return re.sub(r"\s+", " ", text).strip()
    return ""


@dataclass(frozen=True)
class CouncilAgent:
    """A compiled, immutable runtime persona (the registry's unit)."""

    agent_id: str
    display_name: str
    kind: str  # director | gate | expert
    lens: tuple[str, ...]
    persona_prompt: str
    tool_grants: tuple[str, ...] = field(default_factory=tuple)
    model_tier: str = "expert"  # director -> strongest; expert -> small tier
    description: str = ""
    avatar_icon: str = "bot"
    avatar_color: str = "slate"
    source_path: str = ""
    version: str = "1.0.0"
    # True for DMT-custom agents (built via the governed builder, F4). Custom agents
    # are always ``expert`` kind (never director/gate) and carry an explicit creator
    # + provenance so the roster and audit can distinguish them from the canon.
    custom: bool = False
    created_by: str = ""

    def compose_system_prompt(self) -> str:
        """The persona prompt plus the non-negotiable council runtime rules."""
        base = f"{self.persona_prompt.rstrip()}{_GOVERNANCE_FOOTER}"
        if self.kind == "director":
            # When the Director is the speaker (no experts routed), it must answer
            # the user's question directly and concisely — not narrate its internal
            # routing/orchestration. Keep reasoning minimal so the reply is fast and
            # fluid (the model is a reasoning model; long deliberation slows the UI).
            base += (
                "\n\nWhen you answer the user directly, give the answer itself in plain, "
                "concise language. Reason briefly and answer at once — do not over-deliberate. "
                "Aim for a short, direct answer (a few sentences unless the question needs "
                "more). Do NOT narrate your routing, lenses, or internal decision format — "
                "just answer, grounded and advisory."
            )
        return base


def compile_persona(
    text: str,
    *,
    source_path: str = "",
    kind: str | None = None,
    lens: tuple[str, ...] | None = None,
    tool_grants: tuple[str, ...] | None = None,
    model_tier: str | None = None,
    avatar_icon: str = "bot",
    avatar_color: str = "slate",
    custom: bool = False,
    created_by: str = "",
) -> CouncilAgent:
    """Compile a ``.agent.md`` document into a :class:`CouncilAgent`.

    ``kind``/``lens``/``tool_grants``/``model_tier`` may be overridden by the
    registry (the curated catalog); when omitted they are inferred conservatively.
    Custom agents (``custom=True``) are forced to ``expert`` kind so a custom
    persona can never impersonate the Director or a governance gate.
    Raises ``ValueError`` on an invalid kind/lens or a tool outside the allow-list.
    """
    meta, body = _parse_front_matter(text)
    name = meta.get("name", "Council Agent").strip() or "Council Agent"
    description = meta.get("description", "").strip() or _first_paragraph(body)

    resolved_kind = (kind or _infer_kind(source_path)).lower()
    if custom and resolved_kind != "expert":
        resolved_kind = "expert"  # a custom agent can never be a director/gate
    if resolved_kind not in _VALID_KINDS:
        raise ValueError(f"invalid agent kind: {resolved_kind!r}")

    resolved_lens = tuple(lens) if lens else ("both",)
    for item in resolved_lens:
        if item not in _VALID_LENSES:
            raise ValueError(f"invalid lens {item!r} for {name!r}")

    grants = tuple(tool_grants) if tool_grants is not None else _infer_tools(body)
    unknown = set(grants) - ALLOWED_TOOLS
    if unknown:
        raise ValueError(f"{name!r} requests tools outside the allow-list: {sorted(unknown)}")

    tier = model_tier or ("director" if resolved_kind == "director" else "expert")
    agent_id = _slugify(name)
    # The persona prompt is the markdown body (role/domain/output format/voice).
    persona_prompt = body.strip()

    return CouncilAgent(
        agent_id=agent_id,
        display_name=name,
        kind=resolved_kind,
        lens=resolved_lens,
        persona_prompt=persona_prompt,
        tool_grants=grants,
        model_tier=tier,
        description=description,
        avatar_icon=avatar_icon,
        avatar_color=avatar_color,
        source_path=source_path,
        custom=custom,
        created_by=created_by,
    )


def _infer_kind(source_path: str) -> str:
    """Infer director/gate/expert from the file name when not overridden."""
    base = source_path.rsplit("/", 1)[-1]
    if base.startswith("director"):
        return "director"
    if base.startswith(("security-reviewer", "compliance-data-governance")):
        return "gate"
    return "expert"


def _infer_tools(body: str) -> tuple[str, ...]:
    """Infer read-only grants from grounding hints in the body (conservative).

    Every council agent may ground in retrieval. Domain tools are granted only when
    the body references the corresponding governed artifact/endpoint.
    """
    grants: list[str] = ["retrieval.query"]
    hints = {
        "pricing.query": ("rate_table", "pricing"),
        "geopolitical.read": ("/v1/geopolitical", "geopolitical"),
        "demand.read": ("/v1/demand",),
        "parcels.read": ("/v1/parcels", "livability_score"),
        "scenarios.read": ("/v1/scenarios",),
        "recommendation.read": ("/v1/recommendation",),
    }
    lowered = body.lower()
    for tool, needles in hints.items():
        if any(needle in lowered for needle in needles):
            grants.append(tool)
    return tuple(dict.fromkeys(grants))
