"""Council Chat HTTP surface: roster + a governed chat endpoint (SSE or unary).

Mounted under ``/v1/council`` on the existing ``v1_router``, so it inherits the
platform's API-key auth and rate limiting. The chat endpoint runs one governed
turn via :class:`CouncilService`; with ``stream=true`` it streams Server-Sent
Events (``agent_started`` -> ``token``* -> ``message_done``), otherwise it returns
the final :class:`CouncilChatResponse` as JSON.
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import AsyncGenerator

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse
from pydantic import ValidationError

from app.council.builder import CustomAgentSpec
from app.council.custom_store import CustomAgentStore
from app.council.external import ExternalCapture
from app.council.graph import build_council_graph
from app.council.schemas import (
    CouncilAgentInfo,
    CouncilChatRequest,
    CouncilChatResponse,
    CouncilRoster,
    ExternalFetchRequest,
)
from app.council.service import CouncilService, sse_event
from app.errors import AppError, InvalidRequestError

_logger = logging.getLogger("dmt_ai.council.decisions")

# Mounted under the platform's /v1 router (prefix="/council") so it inherits the
# same API-key auth and rate limiting as the rest of the governed /v1 surface.
router = APIRouter(prefix="/council", tags=["Council"])


def get_council_service(request: Request) -> CouncilService:
    """Return the app-scoped council service."""
    return request.app.state.council_service


def get_custom_store(request: Request) -> CustomAgentStore:
    """Return the app-scoped custom-agent store (F4 builder)."""
    store = getattr(request.app.state, "council_custom_store", None)
    if store is None:
        raise InvalidRequestError("the custom-agent builder is not configured")
    return store


def _optional_custom_store(request: Request) -> CustomAgentStore | None:
    """Return the custom store when configured, else ``None`` (roster = canon only)."""
    return getattr(request.app.state, "council_custom_store", None)


def get_external_capture(request: Request) -> ExternalCapture:
    """Return the app-scoped external-capture service (F5), fail-closed if unset."""
    capture = getattr(request.app.state, "council_external_capture", None)
    if capture is None:
        raise InvalidRequestError("external capture is not configured")
    return capture


def _to_info(agent) -> CouncilAgentInfo:  # noqa: ANN001 - CouncilAgent (kept local)
    return CouncilAgentInfo(
        agent_id=agent.agent_id,
        display_name=agent.display_name,
        kind=agent.kind,
        lens=list(agent.lens),
        description=agent.description,
        avatar_icon=agent.avatar_icon,
        avatar_color=agent.avatar_color,
    )


@router.get("/agents", response_model=CouncilRoster)
def list_agents(
    service: CouncilService = Depends(get_council_service),
    store: CustomAgentStore | None = Depends(_optional_custom_store),
) -> CouncilRoster:
    """List the governed agents the user can add (canon + approved custom)."""
    agents = service.roster()
    if store is not None:
        agents = agents + service.custom_roster(store)
    return CouncilRoster(data=[_to_info(a) for a in agents])


@router.get("/coverage")
def council_coverage(service: CouncilService = Depends(get_council_service)) -> dict:
    """The council coverage surface: which domains the council can answer, with what
    confidence, plus any detected pricing-band conflicts. Derived from the same
    deterministic routing table that routes real queries — it cannot drift from
    what the council actually covers."""
    return service.coverage()


@router.get("/metrics")
def council_metrics(service: CouncilService = Depends(get_council_service)) -> dict:
    """Per-expert + council-wide governance KPIs from the recorded turns.

    Interventions, evidence-backed confirmation rate, abstention rate and typical
    confidence per expert — real, deterministic and computed only from turns that
    happened (``available: false`` until the first recorded turn). This is the
    "prove the council works" surface for DMT."""
    return service.metrics()


async def _stream_turn(
    service: CouncilService,
    request: CouncilChatRequest,
    http_request: Request | None = None,
) -> AsyncGenerator[bytes]:
    """Yield SSE frames for one governed council turn.

    The governed reply is produced first (veto check, grounding gate, abstention,
    fan-out + synthesis resolved), then streamed so the UI shows each agent's
    contribution and the Director's synthesis as live text while the content
    remains the governed result.
    """
    try:
        experts = service.route_experts(request)
        # Single-speaker interactive turn -> stream token-by-token in real time.
        if not experts:
            speaker = service.resolve_speaker(request)
            yield sse_event("turn_started", json.dumps({"agents": [speaker.agent_id]}))
            yield sse_event("agent_started", json.dumps({"agent_id": speaker.agent_id}))
            final_message = None
            async for kind, delta, message in service.stream_single_turn(request):
                if kind == "token":
                    yield sse_event(
                        "token", json.dumps({"agent_id": speaker.agent_id, "delta": delta})
                    )
                elif kind == "veto":
                    yield sse_event(
                        "veto",
                        json.dumps({"gate": "compliance-data-governance", "reason": "blocked"}),
                    )
                    return
                elif kind == "done" and message is not None:
                    final_message = message
            if final_message is not None:
                yield sse_event("agent_message", final_message.model_dump_json())
                yield sse_event(
                    "message_done",
                    json.dumps(
                        {
                            "id": "council-stream",
                            "conversation_id": request.conversation_id,
                            "model": request.model,
                            "messages": [json.loads(final_message.model_dump_json())],
                            "synthesis": None,
                            "veto": None,
                            "meta": {
                                "participants": [speaker.agent_id],
                                "rounds": 1,
                                "prompt_tokens": 0,
                                "completion_tokens": 0,
                                "total_tokens": 0,
                            },
                        }
                    ),
                )
            return

        started = [a.agent_id for a in experts]
        yield sse_event("turn_started", json.dumps({"agents": started}))
        # Progressive delivery: emit each expert the moment it finishes, then the
        # synthesis — instead of resolving the whole turn before the first token.
        final_response: CouncilChatResponse | None = None
        synthesis_agent = ""
        async for kind, payload in service.stream_fanout_turn(request):
            if kind == "veto":
                yield sse_event("veto", payload.model_dump_json())
            elif kind in ("expert", "message"):
                yield sse_event("agent_started", json.dumps({"agent_id": payload.agent_id}))
                async for frame in _replay_words(payload.agent_id, payload.content):
                    yield frame
                yield sse_event("agent_message", payload.model_dump_json())
            elif kind == "synthesis_start":
                synthesis_agent = payload
                yield sse_event("synthesis_started", json.dumps({"agent_id": payload}))
            elif kind == "synthesis_token":
                yield sse_event(
                    "token", json.dumps({"agent_id": synthesis_agent, "delta": payload})
                )
            elif kind == "synthesis":
                yield sse_event("synthesis_done", payload.model_dump_json())
            elif kind == "final":
                final_response = payload
    except InvalidRequestError as exc:
        yield sse_event("error", json.dumps({"error": exc.message}))
        return
    except AppError as exc:
        # A governed failure (e.g. no model upstream) must end the stream cleanly,
        # not hang the client with a truncated SSE body.
        yield sse_event("error", json.dumps({"error": exc.message, "code": exc.code}))
        return

    if final_response is None:
        return
    yield sse_event("message_done", final_response.model_dump_json())

    # Episodic memory: record the streamed turn as an auditable decision in the
    # user's graph (after the answer is delivered), so precedent grounding works
    # over the user's real history — the streaming path, not only the unary one.
    if http_request is not None:
        _record_council_decision(http_request, request, final_response)


# Per-word pacing for the multi-agent replay (the fan-out answers are assembled
# before streaming; emit them at a reading pace so the UI types out, ChatGPT-style).
_REPLAY_WORD_DELAY_S = 0.012
# Cap the typewriter tax per (already-computed) message so a long answer adds at most
# this much replay after it resolves; short answers keep the natural reading pace.
_REPLAY_MAX_S = 1.5


async def _replay_words(agent_id: str, content: str) -> AsyncGenerator[bytes]:
    """Yield one token event per word at a reading pace, bounded so a long (already
    computed) message does not add a large replay tail."""
    words = content.split(" ")
    delay = min(_REPLAY_WORD_DELAY_S, _REPLAY_MAX_S / max(1, len(words)))
    for token in words:
        yield sse_event("token", json.dumps({"agent_id": agent_id, "delta": token + " "}))
        await asyncio.sleep(delay)


@router.post("/graph")
async def council_graph(
    payload: CouncilChatRequest,
    service: CouncilService = Depends(get_council_service),
) -> dict:
    """Run a governed council turn and return its deterministic graph.

    The same governed turn as /chat (veto, grounding, abstention unchanged), but
    the response is the explainable graph (nodes + edges + why) instead of the
    message list — the visual "who connected to whom and why" surface for DMT.
    """
    response: CouncilChatResponse = await service.run_turn(payload)
    names = {a.agent_id: a.display_name for a in service.roster()}
    return build_council_graph(response, agent_names=names)


@router.post("/chat")
async def council_chat(
    payload: CouncilChatRequest,
    request: Request,
    service: CouncilService = Depends(get_council_service),
):
    """Run one governed council turn (SSE stream by default, unary JSON if not)."""
    # Director-as-coworker: if the caller didn't send a context snapshot, hydrate
    # it from the signed-in user's stored work context so the Director answers
    # personal questions ("what do I have pending?") from their actual state.
    if not payload.user_context.strip():
        store = getattr(request.app.state, "user_context_store", None)
        if store is not None:
            ctx = _caller_context(store, request)
            if ctx:
                payload = payload.model_copy(update={"user_context": ctx})
    # GraphRAG traversal: the Director consults the user's graph for precedent
    # decisions on this topic (consistency over time) and adds them as context, so
    # the answer is grounded in the user's own decision history, not just the query.
    precedent = _graph_precedent(request, payload)
    if precedent:
        extra = (payload.user_context + "\n\n" if payload.user_context else "") + precedent
        payload = payload.model_copy(update={"user_context": extra})
    if not payload.stream:
        response = await service.run_turn(payload)
        _record_council_decision(request, payload, response)
        return response
    return StreamingResponse(
        _stream_turn(service, payload, request),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


def _graph_precedent(request: Request, payload: CouncilChatRequest) -> str:
    """Traverse the user's graph for precedent decisions on this topic (GraphRAG:
    the answer grounds in the user's own decision history, not just the query)."""
    service = getattr(request.app.state, "graph_service", None)
    if service is None:
        return ""
    try:
        from app.council.user_context_routes import _user_id

        query = next((m.content for m in reversed(payload.messages) if m.role == "user"), "")
        if not query.strip():
            return ""
        similar = service.similar_decisions(_user_id(request), query)
        if not similar:
            return ""
        lines = []
        for d in similar[:3]:
            scenario = d.get("scenario", "") if isinstance(d, dict) else ""
            outcome = d.get("outcome", "") if isinstance(d, dict) else ""
            if scenario:
                lines.append(f"- On '{scenario[:120]}' the council recommended: {outcome[:160]}")
        if not lines:
            return ""
        return (
            "Precedent from this user's own decision history (the context graph) — "
            "keep the answer consistent with it:\n" + "\n".join(lines)
        )
    except Exception:  # noqa: BLE001
        return ""


def _record_council_decision(request: Request, payload: CouncilChatRequest, response) -> None:  # noqa: ANN001
    """Record the council turn as an auditable decision in the user's graph.

    Governance: the Director's recommendation is a first-class decision object
    (scenario, reasoning, outcome, confidence) with provenance — the audit trail
    DMT needs. Advisory only; the recorded confidence is the turn's own level.
    """
    service = getattr(request.app.state, "graph_service", None)
    if service is None:
        return
    try:
        from app.council.user_context_routes import _user_id

        query = next((m.content for m in reversed(payload.messages) if m.role == "user"), "")
        outcome = (
            response.synthesis.content[:280]
            if response.synthesis
            else response.messages[-1].content[:280]
            if response.messages
            else "no-answer"
        )
        participants = ", ".join(response.meta.participants) if response.meta else "director"
        confidence_map = {"high": 0.9, "medium": 0.65, "low": 0.4}
        level = (
            (response.synthesis.confidence if response.synthesis else None)
            or (response.messages[-1].confidence if response.messages else None)
            or "low"
        )
        # Link the decision to the exact retrieval chunks that grounded the turn —
        # the context-graph "why": the recommendation traverses to the governed
        # evidence (chunk id + tier + score), not just a source filename.
        evidence: list[dict] = []
        for m in response.messages:
            for ev in m.evidence or []:
                evidence.append(
                    {
                        "source": ev.chunk_id,
                        "label": ev.canonical_file,
                        "confidence": ev.tier,
                    }
                )
        if response.synthesis and response.synthesis.evidence:
            for ev in response.synthesis.evidence:
                evidence.append(
                    {
                        "source": ev.chunk_id,
                        "label": ev.canonical_file,
                        "confidence": ev.tier,
                    }
                )
        service.record_decision(
            _user_id(request),
            category="council-turn",
            scenario=query[:280],
            reasoning=f"Council participants: {participants}",
            outcome=outcome,
            confidence=confidence_map.get(str(level), 0.4),
            evidence=evidence,
        )
    except Exception as exc:  # noqa: BLE001 — decision recording never breaks a turn
        _logger.warning("council_decision_record_failed", extra={"err": str(exc)})


def _caller_context(store, request: Request) -> str:  # noqa: ANN001 - UserContextStore
    """Render the caller's work context as a compact grounding string."""
    from app.council.user_context_routes import _user_id

    ctx = store.get(_user_id(request))
    parts: list[str] = []
    if ctx.get("role"):
        parts.append(f"Role: {ctx['role']}")
    if ctx.get("goal"):
        parts.append(f"Current objective: {ctx['goal']}")
    if ctx.get("module"):
        parts.append(f"Working in: {ctx['module']}")
    pinned = ctx.get("pinned") or []
    if pinned:
        labels = ", ".join(str(p.get("label", p)) for p in pinned[:8])
        parts.append(f"Pinned / pending: {labels}")
    activity = ctx.get("activity") or []
    if activity:
        recent = ", ".join(f"{a.get('kind')} {a.get('label')}" for a in activity[-5:])
        parts.append(f"Recent activity: {recent}")
    return "\n".join(parts)


# --- Custom-agent builder (F4) ----------------------------------------------


@router.get("/custom-agents")
def list_custom_agents(
    store: CustomAgentStore = Depends(get_custom_store),
) -> dict:
    """List all custom agents and their approval status (any status)."""
    return {"data": store.list()}


@router.post("/custom-agents", status_code=201)
def create_custom_agent(
    payload: CustomAgentSpec,
    store: CustomAgentStore = Depends(get_custom_store),
) -> dict:
    """Register a custom DMT agent as ``pending`` Compliance approval.

    The spec is validated (slug, lens, read-only tool allow-list) and the persona
    is screened for prompt-injection before it is stored. It cannot speak until a
    Compliance reviewer approves it.
    """
    try:
        record = store.create(payload)
    except ValidationError as exc:
        raise InvalidRequestError(str(exc)) from exc
    except ValueError as exc:
        raise InvalidRequestError(str(exc)) from exc
    return record


@router.post("/custom-agents/{agent_id}/approve")
def approve_custom_agent(
    agent_id: str,
    request: Request,
    store: CustomAgentStore = Depends(get_custom_store),
) -> dict:
    """Approve a pending custom agent (Compliance). Reviewer via ``X-Reviewer``."""
    reviewer = request.headers.get("x-reviewer", "compliance")
    try:
        return store.approve(agent_id, reviewer=reviewer)
    except KeyError as exc:
        raise InvalidRequestError(f"unknown custom agent: {agent_id}") from exc


@router.post("/custom-agents/{agent_id}/reject")
def reject_custom_agent(
    agent_id: str,
    request: Request,
    store: CustomAgentStore = Depends(get_custom_store),
) -> dict:
    """Reject a pending custom agent (Compliance). Reviewer via ``X-Reviewer``."""
    reviewer = request.headers.get("x-reviewer", "compliance")
    try:
        return store.reject(agent_id, reviewer=reviewer)
    except KeyError as exc:
        raise InvalidRequestError(f"unknown custom agent: {agent_id}") from exc


# --- External-capture (F5) ---------------------------------------------------


@router.post("/external/fetch")
async def external_fetch(
    payload: ExternalFetchRequest,
    capture: ExternalCapture = Depends(get_external_capture),
) -> dict:
    """Fetch an allow-listed external URL, tagged ``external/unverified`` (F5).

    The result is unverified external context — never merged with governed figures.
    Only https GETs to allow-listed domains are permitted; everything else 400s.
    """
    return await capture.fetch(payload.url)
