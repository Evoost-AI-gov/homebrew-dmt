"""Governed read-only tools — deterministic, evidence-backed answers.

The council's experts are advisory: they never invent a figure. These tools read
*governed* data (the IC-approved deal benchmarks, land scores, scenarios) and
return it with `source` + `confidence`, so an expert can cite a real number
instead of abstaining. Every tool is read-only, floor-enforced (a band with too
few deals is never disclosed), and carries the data's own provenance.

This is the credibility surface: a pricing question returns the actual benchmark
band (p25/p50/p75) with its confidence, not a generic "insufficient evidence".
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# The governed deal-benchmark table (IC-approved; aggregate bands, not valuations).
_DEFAULT_RATE_TABLE = (
    Path(__file__).resolve().parents[2] / "ml" / "pricing" / "deal_benchmarks" / "rate_table.json"
)

# The governed Command Center brief snapshot (deterministic composition of the
# release posture, Phase-1 robustness and per-driver tripwires; low confidence).
_DEFAULT_BRIEF = (
    Path(__file__).resolve().parents[2] / "ml" / "command_center" / "command_center_brief.json"
)


@dataclass(frozen=True)
class ToolResult:
    """One governed tool answer: the figure + its provenance + confidence."""

    tool: str
    found: bool
    text: str  # human/agent-readable summary (injected into the prompt)
    source: str  # provenance (file / dataset)
    confidence: str  # high | medium | low
    data: dict[str, Any] | None = None


class PricingTool:
    """Read-only pricing benchmark lookups over the deal-benchmark rate table.

    Disclosure floor: a band with fewer than ``min_deals_per_band`` deals is
    never disclosed (governance: abstention over a thin figure).
    """

    def __init__(self, rate_table_path: str | Path = _DEFAULT_RATE_TABLE) -> None:
        self._path = Path(rate_table_path)
        self._min_deals = 3
        self._table: dict[str, Any] | None = None

    @property
    def configured(self) -> bool:
        return self._path.exists()

    def _load(self) -> dict[str, Any]:
        if self._table is None:
            self._table = json.loads(self._path.read_text(encoding="utf-8"))
            self._min_deals = int(self._table.get("provenance", {}).get("min_deals_per_band", 3))
        return self._table

    def _fmt(self, entry: dict[str, Any], label: str) -> ToolResult | None:
        """Render a band as a ToolResult, enforcing the disclosure floor."""
        n = int(entry.get("n", 0))
        if n < self._min_deals:
            return None  # below the disclosure floor — never reveal a thin band
        rent = entry.get("rent_aed_sqm", {})
        conf = entry.get("confidence", "low")
        text = (
            f"{label}: {n} deals — rent AED/sqm p25={rent.get('p25')}, "
            f"median={rent.get('p50')}, p75={rent.get('p75')}; "
            f"median tenure {entry.get('duration_years_median', '?')} years; "
            f"confidence {conf}."
        )
        return ToolResult(
            tool="pricing.query",
            found=True,
            text=text,
            source="deal_rate_benchmarks@1 (IC-approved deal register, aggregate bands)",
            confidence=conf,
            data={"label": label, **entry},
        )

    def lookup(self, category: str = "", district: str = "") -> ToolResult:
        """Look up a benchmark band, most specific first (district+category ->
        category -> district). Abstains when nothing clears the floor."""
        if not self.configured:
            return ToolResult(
                tool="pricing.query",
                found=False,
                text="Pricing benchmarks are not configured.",
                source="deal_rate_benchmarks@1",
                confidence="low",
            )
        table = self._load()
        groups = table.get("groups", {})
        category = category.strip().lower().replace(" ", "_").replace("-", "_")
        district = district.strip().lower().replace(" ", "_").replace("-", "_")

        # Most specific: district + category.
        if district and category:
            entry = groups.get("district_category", {}).get(f"{district}|{category}")
            if entry:
                result = self._fmt(
                    entry, f"{district.replace('_', ' ').title()} · {category.replace('_', ' ')}"
                )
                if result:
                    return result
        # Category-wide.
        if category:
            entry = groups.get("category", {}).get(category)
            if entry:
                result = self._fmt(entry, f"Category: {category.replace('_', ' ')}")
                if result:
                    return result
        # District-wide.
        if district:
            entry = groups.get("district", {}).get(district)
            if entry:
                result = self._fmt(entry, f"District: {district.replace('_', ' ').title()}")
                if result:
                    return result
        return ToolResult(
            tool="pricing.query",
            found=False,
            text="No benchmark band clears the disclosure floor for that query.",
            source="deal_rate_benchmarks@1",
            confidence="low",
        )

    def all_categories(self) -> list[str]:
        """The available category bands (for routing / matching)."""
        if not self.configured:
            return []
        return list(self._load().get("groups", {}).get("category", {}).keys())

    def conflicts(self, category: str = "") -> list[dict[str, Any]]:
        """Detect contradictions across the governed pricing bands (the context
        graph flags conflicts instead of silently overwriting).

        A conflict is a district+category band whose median rent diverges sharply
        from the category-wide band (|district median − category median| > 60% of
        the category median) — a signal the band needs review, not a silent merge.
        Returns the flagged contradictions with both figures + the divergence.
        """
        if not self.configured:
            return []
        table = self._load()
        groups = table.get("groups", {})
        category = category.strip().lower().replace(" ", "_").replace("-", "_")
        bands = groups.get("district_category", {})
        category_bands = groups.get("category", {})
        out: list[dict[str, Any]] = []
        for key, entry in bands.items():
            if "|" not in key:
                continue
            district, cat = key.split("|", 1)
            if category and cat != category:
                continue
            cat_entry = category_bands.get(cat)
            if not cat_entry:
                continue
            district_med = entry.get("rent_aed_sqm", {}).get("p50")
            cat_med = cat_entry.get("rent_aed_sqm", {}).get("p50")
            if not district_med or not cat_med:
                continue
            divergence = abs(district_med - cat_med) / cat_med
            if divergence > 0.6:
                out.append(
                    {
                        "district": district,
                        "category": cat,
                        "district_median": district_med,
                        "category_median": cat_med,
                        "divergence": round(divergence, 3),
                        "note": (
                            "District band diverges sharply from the category-wide "
                            "band — review before relying on it."
                        ),
                    }
                )
        return out


class BriefTool:
    """Read-only Command Center brief lookups over the governed snapshot.

    The composed executive decision — release posture, Phase-1 robustness +
    headroom, and per-driver tripwires — as a dated, low-confidence governed read.
    The council grounds its single-voice synthesis on this so "what is the release
    posture / how robust is the plan / what would flip it" cites a real governed
    figure with its as-of date, instead of abstaining. Never a live recomputation
    inside the advisory surface.
    """

    def __init__(self, brief_path: str | Path = _DEFAULT_BRIEF) -> None:
        self._path = Path(brief_path)
        self._brief: dict[str, Any] | None = None

    @property
    def configured(self) -> bool:
        return self._path.exists()

    def _load(self) -> dict[str, Any]:
        if self._brief is None:
            self._brief = json.loads(self._path.read_text(encoding="utf-8"))
        return self._brief

    def summary(self) -> ToolResult | None:
        """Render the governed brief as one ToolResult (posture + robustness +
        earliest tripwire), tagged with its as-of date and confidence."""
        if not self.configured:
            return None
        brief = self._load()
        posture = brief.get("posture", {})
        robustness = brief.get("robustness", {})
        cost = brief.get("cost", {})
        as_of = brief.get("generated_at", "")
        confidence = brief.get("headline_confidence", "low")
        parts: list[str] = []
        if posture.get("available") and posture.get("posture"):
            window = f" for {posture.get('calendar')}" if posture.get("calendar") else ""
            parts.append(
                f"Release posture is {posture['posture']}{window} "
                f"(basis: {posture.get('basis', 'n/a')})."
            )
        if cost.get("available") and cost.get("level") is not None:
            parts.append(
                f"Cost pressure — {cost.get('name')} — is at {cost['level']} "
                f"({cost.get('change_pct')}% week on week)."
            )
        if robustness.get("available"):
            parts.append(
                f"Phase-1 robustness under {robustness.get('scenario_label')}: "
                f"{robustness.get('at_risk_count')} of {robustness.get('phase1_parcel_count')} "
                f"parcels at risk ({robustness.get('revenue_at_risk_pct')}% of indicative "
                f"revenue); the plan holds until materials "
                f"+{robustness.get('headroom_materials_pct')}%, energy "
                f"+{robustness.get('headroom_energy_pct')}%, or financing "
                f"+{robustness.get('headroom_financing_bp')} bp."
            )
        armed = [
            t
            for t in brief.get("tripwires", [])
            if t.get("armed") and t.get("pct_to_trip") is not None
        ]
        if armed:
            first = min(armed, key=lambda t: t.get("pct_to_trip", 100))
            parts.append(
                f"Earliest tripwire: {first.get('label')} moves the posture to "
                f"{first.get('tripped_posture')} at {first.get('pct_to_trip')}% toward the "
                f"pessimistic case."
            )
        return ToolResult(
            tool="command_center.brief",
            found=bool(parts),
            text=" ".join(parts),
            source=f"command_center_brief@{as_of} (governed composition, low confidence)",
            confidence=confidence,
            data=brief,
        )


# --- Query -> tool routing (deterministic) -----------------------------------

_PRICING_SIGNAL = (
    "price",
    "pricing",
    "rent",
    "rental",
    "benchmark",
    "aed",
    "rate",
    "cost",
    "lease",
    "per sqm",
    "per square",
    "how much",
)

# Signals that a query is about the composed Command Center decision (posture /
# robustness / tripwires) — routed to the governed brief snapshot.
_BRIEF_SIGNAL = (
    "release posture",
    "posture",
    "robustness",
    "how robust",
    "at risk",
    "at-risk",
    "at risk parcels",
    "tripwire",
    "trip wire",
    "headroom",
    "breaking point",
    "command center",
    "command-center",
    "stress test",
    "executive read",
    "release plan",
    "should we release",
    "phase-1 stress",
)

_CATEGORY_KEYWORDS = {
    "commercial": ("commercial", "office", "retail", "shop"),
    "industrial_automotive": ("industrial", "automotive", "warehouse", "factory", "logistics"),
    "recreation_leisure": (
        "recreation",
        "leisure",
        "hotel",
        "hospitality",
        "tourism",
        "entertainment",
    ),
    "strategic_projects": ("strategic", "mega", "infrastructure project"),
}

_DISTRICT_KEYWORDS = {
    "al_bateen": ("al bateen", "bateen"),
    "al_shamkhah": ("al shamkhah", "shamkhah"),
    "bani_yas": ("bani yas", "baniyas"),
    "mohamed_bin_zayed_city": ("mohamed bin zayed", "mbz", "mbz city"),
}

# Signal sets for the extended governed surface (each routes to its tool).
_MATCH_SIGNAL = (
    "optimal parcel",
    "best parcel",
    "which parcel",
    "parcel for",
    "match",
    "suitab",
    "target investor",
    "optimal release",
    "best site",
)
_DEMAND_SIGNAL = (
    "archetype",
    "demand",
    "which investor type",
    "investor demand",
    "who would invest",
    "target archetype",
)
_LAND_SIGNAL = (
    "land score",
    "parcel score",
    "best land",
    "top parcel",
    "highest score",
    "livability score",
    "parcel quality",
)
_GEO_SIGNAL = (
    "geopolitic",
    "sanction",
    "fatf",
    "pep",
    "country risk",
    "political risk",
    "capital source risk",
)
_SCENARIO_SIGNAL = (
    "scenario",
    "frontier",
    "release plan",
    "phase-1",
    "what-if",
    "sensitivity",
)
_FORESIGHT_SIGNAL = (
    "foresight",
    "outlook",
    "forecast",
    "horizon",
    "demand outlook",
    "cost outlook",
)
_RECOMMEND_SIGNAL = (
    "recommend",
    "committee",
    "release package",
    "optimal release",
    "phase-1 recommendation",
    "what should we release",
    "investment case",
)

_LAND_USE_KEYWORDS = {
    "commercial": ("commercial", "office", "retail", "shop"),
    "mixed_use": ("mixed", "mixed-use", "mixed use"),
    "industrial": ("industrial", "logistics", "warehouse", "factory"),
    "residential": ("residential", "housing", "apartment", "villa"),
    "hospitality": ("hotel", "hospitality", "tourism", "resort"),
    "recreation_leisure": ("recreation", "leisure", "sports", "fitness"),
}


def _match(query: str, table: dict[str, tuple[str, ...]]) -> str:
    """Return the first key whose keywords appear in the lowercased query."""
    for key, keywords in table.items():
        if any(kw in query for kw in keywords):
            return key
    return ""


# The remaining governed datasets (backend-aggregated, deterministic).
_BACKEND_DATA = Path(__file__).resolve().parents[3] / "dmt-backend" / "app" / "data"
_DEFAULT_ARCHETYPE_DEMAND = _BACKEND_DATA / "archetype_demand.json"
_DEFAULT_LAND_SCORE = _BACKEND_DATA / "land_score.json"
_DEFAULT_GEOPOLITICAL = _BACKEND_DATA / "geopolitical.json"
_DEFAULT_SCENARIOS = _BACKEND_DATA / "scenarios.json"
_DEFAULT_FORESIGHT = _BACKEND_DATA / "foresight.json"


class _JsonTool:
    """Shared base: a governed JSON dataset, path-gated and lazily loaded."""

    tool_name = "tool"

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._data: dict[str, Any] | None = None

    @property
    def configured(self) -> bool:
        return self._path.exists()

    def _load(self) -> dict[str, Any]:
        if self._data is None:
            self._data = json.loads(self._path.read_text(encoding="utf-8"))
        return self._data

    def _not_configured(self) -> ToolResult:
        return ToolResult(
            tool=self.tool_name,
            found=False,
            text=f"{self.tool_name} is not configured.",
            source=self._path.name,
            confidence="low",
        )


class ArchetypeDemandTool(_JsonTool):
    """The 18-archetype ADREC demand mapping + the land_use → target-archetype map.

    Floor-enforced: only archetypes with ``min_deals_per_archetype`` deals are
    published; the classifier-abstained count is surfaced, never hidden.
    """

    tool_name = "demand.read"

    def __init__(self, path: str | Path = _DEFAULT_ARCHETYPE_DEMAND) -> None:
        super().__init__(path)

    def summary(self, land_use: str = "") -> ToolResult:
        """Archetype demand, optionally the target archetypes for a land use."""
        if not self.configured:
            return self._not_configured()
        data = self._load()
        prov = data.get("provenance", {})
        archetypes = data.get("archetypes", {})
        land_use = land_use.strip().lower().replace(" ", "_").replace("-", "_")
        published = int(prov.get("archetypes_published", len(archetypes)))
        abstained = int(prov.get("classifier_abstained", 0))
        if land_use:
            targets = data.get("land_use_target_archetypes", {}).get(land_use, [])
            if not targets:
                return ToolResult(
                    tool=self.tool_name,
                    found=False,
                    text=f"No published target archetypes for land use '{land_use}'.",
                    source=f"archetype_demand@1 ({prov.get('deals_considered', '?')} deals)",
                    confidence="low",
                )
            listed = "; ".join(f"{t['archetype']} ({t['n_deals']} deals)" for t in targets)
            text = (
                f"Target archetypes for {land_use.replace('_', ' ')}: {listed}. "
                f"({published} archetypes published, {abstained} classifier-abstained.)"
            )
            return ToolResult(
                tool=self.tool_name,
                found=True,
                text=text,
                source=f"archetype_demand@1 ({prov.get('source', 'IC deal register')})",
                confidence="medium",
                data={"land_use": land_use, "targets": targets},
            )
        # No land use: the demand landscape.
        top = sorted(
            ((name, a.get("n_deals", 0)) for name, a in archetypes.items()),
            key=lambda kv: kv[1],
            reverse=True,
        )[:5]
        listed = "; ".join(f"{name} ({n} deals)" for name, n in top)
        text = (
            f"Investor-archetype demand ({published} published, {abstained} "
            f"classifier-abstained): strongest — {listed}."
        )
        return ToolResult(
            tool=self.tool_name,
            found=True,
            text=text,
            source=f"archetype_demand@1 ({prov.get('source', 'IC deal register')})",
            confidence="medium",
            data={"top": [dict(zip(("archetype", "n_deals"), t, strict=True)) for t in top]},
        )


class LandScoreTool(_JsonTool):
    """The sovereign multi-pillar land score (240 parcels, livability+technical)."""

    tool_name = "land_score.read"

    def __init__(self, path: str | Path = _DEFAULT_LAND_SCORE) -> None:
        super().__init__(path)

    def top(self, n: int = 5, district: str = "") -> ToolResult:
        """The highest-scoring parcels (advisory), with the headline confidence."""
        if not self.configured:
            return self._not_configured()
        parcels = self._load().get("parcels", [])
        if district:
            want = district.strip().lower().replace(" ", "_")
            parcels = [p for p in parcels if want in str(p.get("reference", "")).lower()]
        parcels = sorted(parcels, key=lambda p: p.get("land_score", 0), reverse=True)[:n]
        if not parcels:
            return ToolResult(
                tool=self.tool_name,
                found=False,
                text="No parcels match that query.",
                source="land_score@1",
                confidence="low",
            )
        ranked = ", ".join(
            f"{p.get('reference')} {p.get('land_score')} ({p.get('confidence')})" for p in parcels
        )
        # Headline confidence inherits the weakest contributing parcel (invariant 4).
        confidence = _min_confidence(p.get("confidence") for p in parcels) or "low"
        return ToolResult(
            tool=self.tool_name,
            found=True,
            text=f"Top-scoring parcels (advisory): {ranked}.",
            source="land_score@1 (sovereign multi-pillar, advisory)",
            confidence=confidence,
            data={"parcels": parcels},
        )


class GeopoliticalTool(_JsonTool):
    """Geopolitical risk per geography (sanctions/FATF/PEP-informed, advisory)."""

    tool_name = "geopolitical.read"

    def __init__(self, path: str | Path = _DEFAULT_GEOPOLITICAL) -> None:
        super().__init__(path)

    def summary(self, geography: str = "") -> ToolResult:
        if not self.configured:
            return self._not_configured()
        data = self._load()
        geos = data.get("geographies", [])
        geography = geography.strip().lower()
        rows: list[tuple[str, Any, str]] = []
        for g in geos:
            if not isinstance(g, dict):
                continue
            label = str(g.get("label", ""))
            if (
                geography
                and geography not in label.lower()
                and geography not in str(g.get("country", "")).lower()
            ):
                continue
            # The headline lens reading: combined score + its confidence.
            lenses = g.get("lenses", [])
            headline = lenses[0] if lenses else {}
            rows.append((label, headline.get("combined"), headline.get("confidence", "low")))
        if not rows:
            return ToolResult(
                tool=self.tool_name,
                found=False,
                text=f"No geopolitical reading for '{geography or 'that geography'}'.",
                source=f"geopolitical@1 ({data.get('n_geographies', '?')} geographies)",
                confidence="low",
            )
        listed = "; ".join(f"{n} {s} ({c})" for n, s, c in rows[:6])
        confidence = _min_confidence(c for _, _, c in rows) or "low"
        return ToolResult(
            tool=self.tool_name,
            found=True,
            text=f"Geopolitical risk (advisory): {listed}.",
            source=f"geopolitical@1 (window {data.get('window_days', '?')}d)",
            confidence=confidence,
            data={"rows": rows},
        )


class ScenariosTool(_JsonTool):
    """The scenario frontier + decision matrix (release planning, advisory)."""

    tool_name = "scenarios.read"

    def __init__(self, path: str | Path = _DEFAULT_SCENARIOS) -> None:
        super().__init__(path)

    def summary(self) -> ToolResult:
        if not self.configured:
            return self._not_configured()
        data = self._load()
        scenarios = data.get("scenarios", [])
        n = len(scenarios)
        robust = data.get("robust_actions", [])
        text = (
            f"Scenario frontier: {n} scenarios across "
            f"{data.get('horizons_months', '?')} months; "
            f"{len(robust)} robust actions identified (advisory)."
        )
        return ToolResult(
            tool=self.tool_name,
            found=bool(n),
            text=text,
            source=f"scenarios@1 (generated {data.get('generated_at', '?')[:10]})",
            confidence="medium" if n else "low",
            data={"n_scenarios": n, "robust_actions": robust[:5]},
        )


class ForesightTool(_JsonTool):
    """The foresight demand/cost series (horizon outlook, advisory)."""

    tool_name = "foresight.read"

    def __init__(self, path: str | Path = _DEFAULT_FORESIGHT) -> None:
        super().__init__(path)

    def summary(self) -> ToolResult:
        if not self.configured:
            return self._not_configured()
        data = self._load()
        series = data.get("series", [])
        n = len(series)
        horizon = data.get("horizon", "?")
        text = f"Foresight outlook: {n} series over the {horizon} horizon (advisory)."
        return ToolResult(
            tool=self.tool_name,
            found=bool(n),
            text=text,
            source=f"foresight@1 (generated {data.get('generated_at', '?')[:10]})",
            confidence="medium" if n else "low",
            data={"n_series": n, "horizon": horizon},
        )


class MatchTool:
    """Parcel ↔ archetype matching — a governed composition, not a model call.

    Combines the sovereign land score (parcel quality) with the archetype-demand
    land_use → target-archetype map (investor fit). Headline confidence inherits
    the weakest input (invariant 4); a query with no demand signal or no scored
    parcels abstains visibly (invariant 2). Never names a real investor
    (data minimization, invariant 3) — matches archetypes, not entities.
    """

    tool_name = "match.parcels_archetypes"

    def __init__(self, demand: ArchetypeDemandTool, land: LandScoreTool) -> None:
        self._demand = demand
        self._land = land

    @property
    def configured(self) -> bool:
        return self._demand.configured and self._land.configured

    def optimal(self, land_use: str, n: int = 5) -> ToolResult:
        """Rank the highest-quality parcels and the target archetypes for a use."""
        if not self.configured:
            return ToolResult(
                tool=self.tool_name,
                found=False,
                text="Parcel-archetype matching is not configured.",
                source="match.parcels_archetypes",
                confidence="low",
            )
        demand = self._demand.summary(land_use=land_use)
        land = self._land.top(n=n)
        if not demand.found or not land.found:
            return ToolResult(
                tool=self.tool_name,
                found=False,
                text=(
                    "Insufficient governed evidence to match parcels to archetypes for "
                    f"'{land_use}' — abstaining rather than guessing."
                ),
                source="match.parcels_archetypes",
                confidence="low",
            )
        # Compose: parcel quality (land) × investor fit (demand targets).
        confidence = _min_confidence([demand.confidence, land.confidence]) or "low"
        targets = ", ".join(t["archetype"] for t in (demand.data or {}).get("targets", [])[:4])
        parcels = ", ".join(
            f"{p.get('reference')} ({p.get('land_score')})"
            for p in (land.data or {}).get("parcels", [])
        )
        text = (
            f"Optimal {land_use.replace('_', ' ')} release — top parcels: {parcels}. "
            f"Target investor archetypes: {targets}. (Advisory composition; confidence "
            f"inherits the weakest input.)"
        )
        return ToolResult(
            tool=self.tool_name,
            found=True,
            text=text,
            source="match.parcels_archetypes (land_score@1 × archetype_demand@1)",
            confidence=confidence,
            data={
                "land_use": land_use,
                "parcels": (land.data or {}).get("parcels", []),
                "targets": (demand.data or {}).get("targets", []),
            },
        )


def _min_confidence(levels: Any) -> str | None:
    """The lowest confidence across a set of inputs (headline inherits it)."""
    order = {"low": 0, "medium": 1, "high": 2}
    present = [level for level in levels if level in order]
    return min(present, key=lambda level: order[level]) if present else None


def run_governed_tools(
    query: str,
    pricing: PricingTool | None,
    brief: BriefTool | None = None,
    demand: ArchetypeDemandTool | None = None,
    land: LandScoreTool | None = None,
    geopolitical: GeopoliticalTool | None = None,
    scenarios: ScenariosTool | None = None,
    foresight: ForesightTool | None = None,
    match: MatchTool | None = None,
    backend: BackendReadTool | None = None,
) -> list[ToolResult]:
    """Detect and run the governed tools a query needs (deterministic, read-only).

    The LIVE backend reads (demand / recommendation) take precedence over the
    offline snapshots for matching and recommendation queries — enterprise mode
    answers from the current governed state. Falls back to the offline tools
    when no backend is configured. Returns only results that found data.
    """
    results: list[ToolResult] = []
    q = query.lower()
    live = backend is not None and backend.configured
    # Matching / "optimal parcels for an investor" -> live demand (the register-
    # evidenced archetype targeting), else the offline match composition.
    if any(sig in q for sig in _MATCH_SIGNAL):
        land_use = _match(q, _LAND_USE_KEYWORDS)
        result = (
            backend.demand(land_use=land_use)
            if live
            else (match.optimal(land_use=land_use or "commercial") if match is not None else None)
        )
        if result is not None and result.found:
            results.append(result)
    # The committee recommendation -> live, when configured.
    if live and any(sig in q for sig in _RECOMMEND_SIGNAL):
        result = backend.recommendation()
        if result.found:
            results.append(result)
    if pricing is not None and any(sig in q for sig in _PRICING_SIGNAL):
        category = _match(q, _CATEGORY_KEYWORDS)
        district = _match(q, _DISTRICT_KEYWORDS)
        result = pricing.lookup(category=category, district=district)
        if result.found:
            results.append(result)
    if brief is not None and any(sig in q for sig in _BRIEF_SIGNAL):
        brief_result = brief.summary()
        if brief_result is not None and brief_result.found:
            results.append(brief_result)
    # The archetype-demand question falls back to the offline tool when no live
    # backend answered it above.
    if demand is not None and not live and any(sig in q for sig in _DEMAND_SIGNAL):
        land_use = _match(q, _LAND_USE_KEYWORDS)
        result = demand.summary(land_use=land_use)
        if result.found:
            results.append(result)
    if land is not None and any(sig in q for sig in _LAND_SIGNAL):
        result = land.top()
        if result.found:
            results.append(result)
    if geopolitical is not None and any(sig in q for sig in _GEO_SIGNAL):
        result = geopolitical.summary()
        if result.found:
            results.append(result)
    if scenarios is not None and any(sig in q for sig in _SCENARIO_SIGNAL):
        result = scenarios.summary()
        if result.found:
            results.append(result)
    if foresight is not None and any(sig in q for sig in _FORESIGHT_SIGNAL):
        result = foresight.summary()
        if result.found:
            results.append(result)
    return results


# --- Live backend reads (the enterprise surface) ------------------------------

# When a backend base URL is configured, the council consults the LIVE governed
# endpoints (demand / recommendation / parcels) instead of the offline snapshots,
# so a chat/CLI answer reflects the current governed state. Fail-closed: an
# unreachable or unauthorized backend abstains visibly, never serves stale data
# as if it were live.
_BACKEND_TIMEOUT_S = 6.0


class BackendReadTool:
    """Read-only live queries against the governed dmt-backend endpoints.

    Enterprise mode: the council answers from the platform's live decision
    surface (``GET /v1/demand`` — the archetype-to-land matching, ``GET
    /v1/recommendation`` — the committee-ready phase package), not a static
    snapshot. Read-only, bounded timeout, and abstains visibly when the backend
    is not configured or not reachable (invariant 2 — never a fabricated figure).
    """

    tool_name = "backend.read"

    def __init__(
        self,
        base_url: str = "",
        token: str = "",
        *,
        entra_tenant_id: str = "",
        client_id: str = "",
        client_secret: str = "",
        scope: str = "",
    ) -> None:
        self._base = base_url.rstrip("/")
        self._static_token = token
        # Entra client-credentials (enterprise): the tool acquires + refreshes its
        # own bearer so the live read never dies on token expiry. Static ``token``
        # takes precedence (a trusted-local backend with a pre-shared token).
        self._tenant = entra_tenant_id
        self._client_id = client_id
        self._client_secret = client_secret
        self._scope = scope
        self._token = token
        self._token_expires_at = 0.0

    @property
    def configured(self) -> bool:
        return bool(self._base)

    def _bearer(self) -> str:
        """A valid bearer token: the static one, or a refreshed client-credentials
        token (cached until ~5 min before expiry)."""
        if self._static_token:
            return self._static_token
        import time

        if self._token and time.monotonic() < self._token_expires_at:
            return self._token
        if not (self._tenant and self._client_id and self._client_secret and self._scope):
            return ""
        import httpx

        try:
            with httpx.Client(timeout=_BACKEND_TIMEOUT_S) as client:
                resp = client.post(
                    f"https://login.microsoftonline.com/{self._tenant}/oauth2/v2.0/token",
                    data={
                        "client_id": self._client_id,
                        "client_secret": self._client_secret,
                        "scope": self._scope,
                        "grant_type": "client_credentials",
                    },
                )
            body = resp.json()
            self._token = str(body.get("access_token", ""))
            # Refresh 5 minutes before the token's stated lifetime ends.
            ttl = max(int(body.get("expires_in", 3600)) - 300, 60)
            self._token_expires_at = time.monotonic() + ttl
            return self._token
        except Exception:  # noqa: BLE001 - a token failure abstains downstream
            return ""

    def _get(self, path: str) -> dict[str, Any] | None:
        """One bounded GET; None on any failure (the caller abstains)."""
        import httpx

        token = self._bearer()
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        try:
            with httpx.Client(timeout=_BACKEND_TIMEOUT_S) as client:
                resp = client.get(f"{self._base}{path}", headers=headers)
            if resp.status_code != 200:
                return None
            return resp.json()
        except Exception:  # noqa: BLE001 - any transport/parse failure -> abstain
            return None

    def demand(self, land_use: str = "") -> ToolResult:
        """Live archetype demand + the parcels each archetype targets."""
        if not self.configured:
            return ToolResult(
                tool=self.tool_name,
                found=False,
                text="The live backend is not configured.",
                source="dmt-backend",
                confidence="low",
            )
        body = self._get("/v1/demand")
        if body is None:
            return ToolResult(
                tool=self.tool_name,
                found=False,
                text="The governed demand surface is unreachable — abstaining.",
                source="dmt-backend /v1/demand",
                confidence="low",
            )
        targeting = body.get("investor_targeting", [])
        if land_use:
            want = land_use.strip().lower().replace(" ", "_")
            targeting = [
                t for t in targeting if want in [u.lower() for u in t.get("target_land_uses", [])]
            ]
        if not targeting:
            return ToolResult(
                tool=self.tool_name,
                found=False,
                text=f"No governed archetype demand for '{land_use or 'the portfolio'}'.",
                source="dmt-backend /v1/demand",
                confidence="low",
            )
        top = targeting[:5]
        listed = "; ".join(
            f"{t.get('archetype')} — {t.get('demand_parcels')} parcels "
            f"({t.get('source')}, {t.get('n_deals') or 0} deals)"
            for t in top
        )
        confidence = _min_confidence(t.get("confidence") for t in top) or "medium"
        return ToolResult(
            tool=self.tool_name,
            found=True,
            text=f"Investor-archetype demand (live): {listed}.",
            source="dmt-backend GET /v1/demand (register-evidenced targeting)",
            confidence=confidence,
            data={"targeting": top},
        )

    def recommendation(self) -> ToolResult:
        """The committee-ready phase recommendation (optimal release)."""
        if not self.configured:
            return ToolResult(
                tool=self.tool_name,
                found=False,
                text="The live backend is not configured.",
                source="dmt-backend",
                confidence="low",
            )
        body = self._get("/v1/recommendation")
        if body is None:
            return ToolResult(
                tool=self.tool_name,
                found=False,
                text="The recommendation surface is unreachable — abstaining.",
                source="dmt-backend /v1/recommendation",
                confidence="low",
            )
        selected = body.get("selected") or {}
        metrics = body.get("headline_metrics", [])
        targeting = body.get("investor_targeting", [])
        if not selected and not metrics:
            return ToolResult(
                tool=self.tool_name,
                found=False,
                text="No committee recommendation is available — abstaining.",
                source="dmt-backend /v1/recommendation",
                confidence="low",
            )
        metric_txt = "; ".join(
            f"{m.get('label')} {m.get('value')} {m.get('unit')} ({m.get('confidence')})"
            for m in metrics[:4]
        )
        targets = ", ".join(t.get("archetype") for t in targeting[:4])
        confidence = _min_confidence([m.get("confidence") for m in metrics]) or "low"
        text = f"Recommended release: {metric_txt}. Target archetypes: {targets}."
        return ToolResult(
            tool=self.tool_name,
            found=True,
            text=text,
            source="dmt-backend GET /v1/recommendation (committee package)",
            confidence=confidence,
            data={"selected": selected, "investor_targeting": targeting},
        )
