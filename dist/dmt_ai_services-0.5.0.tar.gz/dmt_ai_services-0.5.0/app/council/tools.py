"""Governed read-only tools — deterministic, evidence-backed answers.

The council's experts are advisory: they never invent a figure. These tools read
*governed* data (the IC-approved deal benchmarks, land scores, scenarios) and
return it with `source` + `confidence`, so an expert can cite a real number
instead of abstaining. Every tool is read-only, floor-enforced (a band with too
few deals is never disclosed), and carries the data's own provenance.

This is the credibility surface: a pricing question returns the actual benchmark
band (p25/p50/p75) with its confidence, not a generic "insufficient evidence".
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# The governed deal-benchmark table (IC-approved; aggregate bands, not valuations).
_DEFAULT_RATE_TABLE = (
    Path(__file__).resolve().parents[2] / "ml" / "pricing" / "deal_benchmarks" / "rate_table.json"
)

# The governed Command Center brief snapshot (deterministic composition of the
# release posture, Phase-1 robustness and per-driver tripwires; low confidence).
_DEFAULT_BRIEF = (
    Path(__file__).resolve().parents[2] / "ml" / "command_center" / "command_center_brief.json"
)


@dataclass(frozen=True)
class ToolResult:
    """One governed tool answer: the figure + its provenance + confidence."""

    tool: str
    found: bool
    text: str  # human/agent-readable summary (injected into the prompt)
    source: str  # provenance (file / dataset)
    confidence: str  # high | medium | low
    data: dict[str, Any] | None = None


class PricingTool:
    """Read-only pricing benchmark lookups over the deal-benchmark rate table.

    Disclosure floor: a band with fewer than ``min_deals_per_band`` deals is
    never disclosed (governance: abstention over a thin figure).
    """

    def __init__(self, rate_table_path: str | Path = _DEFAULT_RATE_TABLE) -> None:
        self._path = Path(rate_table_path)
        self._min_deals = 3
        self._table: dict[str, Any] | None = None

    @property
    def configured(self) -> bool:
        return self._path.exists()

    def _load(self) -> dict[str, Any]:
        if self._table is None:
            self._table = json.loads(self._path.read_text(encoding="utf-8"))
            self._min_deals = int(self._table.get("provenance", {}).get("min_deals_per_band", 3))
        return self._table

    def _fmt(self, entry: dict[str, Any], label: str) -> ToolResult | None:
        """Render a band as a ToolResult, enforcing the disclosure floor."""
        n = int(entry.get("n", 0))
        if n < self._min_deals:
            return None  # below the disclosure floor — never reveal a thin band
        rent = entry.get("rent_aed_sqm", {})
        conf = entry.get("confidence", "low")
        text = (
            f"{label}: {n} deals — rent AED/sqm p25={rent.get('p25')}, "
            f"median={rent.get('p50')}, p75={rent.get('p75')}; "
            f"median tenure {entry.get('duration_years_median', '?')} years; "
            f"confidence {conf}."
        )
        return ToolResult(
            tool="pricing.query",
            found=True,
            text=text,
            source="deal_rate_benchmarks@1 (IC-approved deal register, aggregate bands)",
            confidence=conf,
            data={"label": label, **entry},
        )

    def lookup(self, category: str = "", district: str = "") -> ToolResult:
        """Look up a benchmark band, most specific first (district+category ->
        category -> district). Abstains when nothing clears the floor."""
        if not self.configured:
            return ToolResult(
                tool="pricing.query",
                found=False,
                text="Pricing benchmarks are not configured.",
                source="deal_rate_benchmarks@1",
                confidence="low",
            )
        table = self._load()
        groups = table.get("groups", {})
        category = category.strip().lower().replace(" ", "_").replace("-", "_")
        district = district.strip().lower().replace(" ", "_").replace("-", "_")

        # Most specific: district + category.
        if district and category:
            entry = groups.get("district_category", {}).get(f"{district}|{category}")
            if entry:
                result = self._fmt(
                    entry, f"{district.replace('_', ' ').title()} · {category.replace('_', ' ')}"
                )
                if result:
                    return result
        # Category-wide.
        if category:
            entry = groups.get("category", {}).get(category)
            if entry:
                result = self._fmt(entry, f"Category: {category.replace('_', ' ')}")
                if result:
                    return result
        # District-wide.
        if district:
            entry = groups.get("district", {}).get(district)
            if entry:
                result = self._fmt(entry, f"District: {district.replace('_', ' ').title()}")
                if result:
                    return result
        return ToolResult(
            tool="pricing.query",
            found=False,
            text="No benchmark band clears the disclosure floor for that query.",
            source="deal_rate_benchmarks@1",
            confidence="low",
        )

    def all_categories(self) -> list[str]:
        """The available category bands (for routing / matching)."""
        if not self.configured:
            return []
        return list(self._load().get("groups", {}).get("category", {}).keys())

    def conflicts(self, category: str = "") -> list[dict[str, Any]]:
        """Detect contradictions across the governed pricing bands (the context
        graph flags conflicts instead of silently overwriting).

        A conflict is a district+category band whose median rent diverges sharply
        from the category-wide band (|district median − category median| > 60% of
        the category median) — a signal the band needs review, not a silent merge.
        Returns the flagged contradictions with both figures + the divergence.
        """
        if not self.configured:
            return []
        table = self._load()
        groups = table.get("groups", {})
        category = category.strip().lower().replace(" ", "_").replace("-", "_")
        bands = groups.get("district_category", {})
        category_bands = groups.get("category", {})
        out: list[dict[str, Any]] = []
        for key, entry in bands.items():
            if "|" not in key:
                continue
            district, cat = key.split("|", 1)
            if category and cat != category:
                continue
            cat_entry = category_bands.get(cat)
            if not cat_entry:
                continue
            district_med = entry.get("rent_aed_sqm", {}).get("p50")
            cat_med = cat_entry.get("rent_aed_sqm", {}).get("p50")
            if not district_med or not cat_med:
                continue
            divergence = abs(district_med - cat_med) / cat_med
            if divergence > 0.6:
                out.append(
                    {
                        "district": district,
                        "category": cat,
                        "district_median": district_med,
                        "category_median": cat_med,
                        "divergence": round(divergence, 3),
                        "note": (
                            "District band diverges sharply from the category-wide "
                            "band — review before relying on it."
                        ),
                    }
                )
        return out


class BriefTool:
    """Read-only Command Center brief lookups over the governed snapshot.

    The composed executive decision — release posture, Phase-1 robustness +
    headroom, and per-driver tripwires — as a dated, low-confidence governed read.
    The council grounds its single-voice synthesis on this so "what is the release
    posture / how robust is the plan / what would flip it" cites a real governed
    figure with its as-of date, instead of abstaining. Never a live recomputation
    inside the advisory surface.
    """

    def __init__(self, brief_path: str | Path = _DEFAULT_BRIEF) -> None:
        self._path = Path(brief_path)
        self._brief: dict[str, Any] | None = None

    @property
    def configured(self) -> bool:
        return self._path.exists()

    def _load(self) -> dict[str, Any]:
        if self._brief is None:
            self._brief = json.loads(self._path.read_text(encoding="utf-8"))
        return self._brief

    def summary(self) -> ToolResult | None:
        """Render the governed brief as one ToolResult (posture + robustness +
        earliest tripwire), tagged with its as-of date and confidence."""
        if not self.configured:
            return None
        brief = self._load()
        posture = brief.get("posture", {})
        robustness = brief.get("robustness", {})
        cost = brief.get("cost", {})
        as_of = brief.get("generated_at", "")
        confidence = brief.get("headline_confidence", "low")
        parts: list[str] = []
        if posture.get("available") and posture.get("posture"):
            window = f" for {posture.get('calendar')}" if posture.get("calendar") else ""
            parts.append(
                f"Release posture is {posture['posture']}{window} "
                f"(basis: {posture.get('basis', 'n/a')})."
            )
        if cost.get("available") and cost.get("level") is not None:
            parts.append(
                f"Cost pressure — {cost.get('name')} — is at {cost['level']} "
                f"({cost.get('change_pct')}% week on week)."
            )
        if robustness.get("available"):
            parts.append(
                f"Phase-1 robustness under {robustness.get('scenario_label')}: "
                f"{robustness.get('at_risk_count')} of {robustness.get('phase1_parcel_count')} "
                f"parcels at risk ({robustness.get('revenue_at_risk_pct')}% of indicative "
                f"revenue); the plan holds until materials "
                f"+{robustness.get('headroom_materials_pct')}%, energy "
                f"+{robustness.get('headroom_energy_pct')}%, or financing "
                f"+{robustness.get('headroom_financing_bp')} bp."
            )
        armed = [
            t
            for t in brief.get("tripwires", [])
            if t.get("armed") and t.get("pct_to_trip") is not None
        ]
        if armed:
            first = min(armed, key=lambda t: t.get("pct_to_trip", 100))
            parts.append(
                f"Earliest tripwire: {first.get('label')} moves the posture to "
                f"{first.get('tripped_posture')} at {first.get('pct_to_trip')}% toward the "
                f"pessimistic case."
            )
        return ToolResult(
            tool="command_center.brief",
            found=bool(parts),
            text=" ".join(parts),
            source=f"command_center_brief@{as_of} (governed composition, low confidence)",
            confidence=confidence,
            data=brief,
        )


# --- Query -> tool routing (deterministic) -----------------------------------

_PRICING_SIGNAL = (
    "price",
    "pricing",
    "rent",
    "rental",
    "benchmark",
    "aed",
    "rate",
    "cost",
    "lease",
    "per sqm",
    "per square",
    "how much",
)

# Signals that a query is about the composed Command Center decision (posture /
# robustness / tripwires) — routed to the governed brief snapshot.
_BRIEF_SIGNAL = (
    "release posture",
    "posture",
    "robustness",
    "how robust",
    "at risk",
    "at-risk",
    "at risk parcels",
    "tripwire",
    "trip wire",
    "headroom",
    "breaking point",
    "command center",
    "command-center",
    "stress test",
    "executive read",
    "release plan",
    "should we release",
    "phase-1 stress",
)

_CATEGORY_KEYWORDS = {
    "commercial": ("commercial", "office", "retail", "shop"),
    "industrial_automotive": ("industrial", "automotive", "warehouse", "factory", "logistics"),
    "recreation_leisure": (
        "recreation",
        "leisure",
        "hotel",
        "hospitality",
        "tourism",
        "entertainment",
    ),
    "strategic_projects": ("strategic", "mega", "infrastructure project"),
}

_DISTRICT_KEYWORDS = {
    "al_bateen": ("al bateen", "bateen"),
    "al_shamkhah": ("al shamkhah", "shamkhah"),
    "bani_yas": ("bani yas", "baniyas"),
    "mohamed_bin_zayed_city": ("mohamed bin zayed", "mbz", "mbz city"),
}


def _match(query: str, table: dict[str, tuple[str, ...]]) -> str:
    """Return the first key whose keywords appear in the lowercased query."""
    for key, keywords in table.items():
        if any(kw in query for kw in keywords):
            return key
    return ""


def run_governed_tools(
    query: str, pricing: PricingTool | None, brief: BriefTool | None = None
) -> list[ToolResult]:
    """Detect and run the governed tools a query needs (deterministic, read-only).

    Wires the pricing benchmark and the Command Center brief; land_score /
    scenarios plug in the same way as their governed datasets land. Returns only
    results that found data.
    """
    results: list[ToolResult] = []
    q = query.lower()
    if pricing is not None and any(sig in q for sig in _PRICING_SIGNAL):
        category = _match(q, _CATEGORY_KEYWORDS)
        district = _match(q, _DISTRICT_KEYWORDS)
        result = pricing.lookup(category=category, district=district)
        if result.found:
            results.append(result)
    if brief is not None and any(sig in q for sig in _BRIEF_SIGNAL):
        brief_result = brief.summary()
        if brief_result is not None and brief_result.found:
            results.append(brief_result)
    return results
