"""Council agent registry: load, validate and serve the governed roster.

The registry compiles personas from the versioned ``.agent.md`` corpus
(``.github/agents/`` in the ``dmt-agents`` repo) and exposes them by stable id.
It is fail-closed: with no agents directory configured it serves an empty roster
rather than inventing agents, and it skips any file that fails to compile (a
persona that asks for a non-allow-listed tool or an invalid lens/kind) — logging
the skip so a bad persona can never reach a user.
"""

from __future__ import annotations

import logging
from pathlib import Path

from app.council.persona import CouncilAgent, compile_persona
from app.errors import InvalidRequestError

_logger = logging.getLogger("dmt_ai.council.registry")

# Curated per-agent overrides (lens, avatar) applied on top of compilation. This
# is the registry's editorial layer; persona text itself stays in the .agent.md.
_LENS_BY_ID: dict[str, tuple[str, ...]] = {
    "director-program-orchestrator": ("both",),
    "security-multi-tenant-reviewer": ("both",),
    "compliance-data-governance-steward": ("both",),
    "urban-planning-land-use-strategist": ("sovereign",),
    "real-estate-valuation-expert": ("investor",),
    "investment-capital-markets-analyst": ("investor",),
    "investor-archetypes-capital-sourcing-expert": ("investor",),
    "market-intelligence-research-analyst": ("both",),
    "deal-structuring-land-tenure-expert": ("investor",),
    "government-affairs-stakeholder-strategy-expert": ("sovereign",),
    "sequencing-phasing-strategist": ("sovereign",),
    "sustainability-livability-esg-estidama-expert": ("sovereign",),
    "product-go-to-market-strategist": ("both",),
    "geopolitical-risk-international-relations-analyst": ("both",),
}

_AVATAR_BY_KIND: dict[str, tuple[str, str]] = {
    "director": ("crown", "indigo"),
    "gate": ("shield", "rose"),
    "expert": ("briefcase", "teal"),
}


class CouncilRegistry:
    """In-memory, immutable view of the compiled council roster."""

    def __init__(self, agents: list[CouncilAgent]) -> None:
        self._agents: dict[str, CouncilAgent] = {a.agent_id: a for a in agents}

    @property
    def configured(self) -> bool:
        """Whether the registry holds at least one agent."""
        return bool(self._agents)

    def list(self) -> list[CouncilAgent]:
        """Return all agents, Director first, then gates, then experts (alpha)."""
        order = {"director": 0, "gate": 1, "expert": 2}
        return sorted(self._agents.values(), key=lambda a: (order[a.kind], a.display_name))

    def get(self, agent_id: str) -> CouncilAgent | None:
        """Return the agent for ``agent_id``, or ``None`` if unknown."""
        return self._agents.get(agent_id)

    def director(self) -> CouncilAgent | None:
        """Return the Director agent (the default speaker / synthesizer)."""
        return next((a for a in self._agents.values() if a.kind == "director"), None)

    @classmethod
    def from_directory(cls, directory: str | Path) -> CouncilRegistry:
        """Compile every ``*.agent.md`` under ``directory`` into a registry.

        Files that fail to compile are skipped (logged), never served.
        """
        path = Path(directory)
        agents: list[CouncilAgent] = []
        if not path.is_dir():
            _logger.warning("council_agents_dir_missing", extra={"dir": str(path)})
            return cls([])
        for file in sorted(path.glob("*.agent.md")):
            try:
                agent = compile_persona(file.read_text(encoding="utf-8"), source_path=str(file))
            except (ValueError, OSError) as exc:
                _logger.warning(
                    "council_persona_skipped", extra={"file": file.name, "err": str(exc)}
                )
                continue
            lens = _LENS_BY_ID.get(agent.agent_id, agent.lens)
            icon, color = _AVATAR_BY_KIND.get(agent.kind, ("bot", "slate"))
            agents.append(
                CouncilAgent(
                    **{
                        **agent.__dict__,
                        "lens": lens,
                        "avatar_icon": icon,
                        "avatar_color": color,
                    }
                )
            )
        _logger.info("council_registry_loaded", extra={"count": len(agents)})
        return cls(agents)

    def with_custom(self, specs: list) -> CouncilRegistry:  # noqa: ANN001 - CustomAgentSpec
        """Return a new registry that also serves approved custom agents (F4).

        Each spec compiles through the same persona compiler with ``custom=True``
        (forced to ``expert`` kind). A custom id that collides with the curated
        canon is refused — custom agents can never shadow a governed agent.
        """
        from app.council.builder import render_agent_md

        merged = dict(self._agents)
        for spec in specs:
            try:
                agent = compile_persona(
                    render_agent_md(spec),
                    source_path=f"custom:{spec.agent_id}",
                    kind="expert",
                    custom=True,
                    created_by=spec.created_by,
                )
            except (ValueError, InvalidRequestError) as exc:
                _logger.warning(
                    "council_custom_skipped", extra={"id": spec.agent_id, "err": str(exc)}
                )
                continue
            if agent.agent_id in merged:
                _logger.warning("council_custom_collides_canon", extra={"id": agent.agent_id})
                continue
            merged[agent.agent_id] = agent
        return CouncilRegistry(list(merged.values()))
