"""Chat-persistence endpoints (`/v1/chats`) — advisory conversation state.

Mirrors the assistant's conversations + project folders so the working state
survives across devices. Fail-closed: when no store path is configured the router
is not mounted and the frontend falls back to its local (offline) state. These
endpoints hold advisory conversation state only — never governed figures — and the
caller keeps identity/record-level content out of messages (data minimization).
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, ConfigDict, Field

from app.council.chat_store import ChatStore
from app.errors import InvalidRequestError

router = APIRouter(prefix="/chats", tags=["Chats"])


def get_chat_store(request: Request) -> ChatStore:
    """Return the app-scoped chat store (fail-closed when unconfigured)."""
    store = getattr(request.app.state, "chat_store", None)
    if store is None:
        raise InvalidRequestError("chat persistence is not configured")
    return store


class ChatMessageIn(BaseModel):
    """One stored message (passthrough of the frontend message shape)."""

    model_config = ConfigDict(extra="allow")  # forward-compatible message fields

    id: str
    role: str
    content: str = Field(max_length=100_000)


class ConversationUpsert(BaseModel):
    """The conversation write payload from the frontend sync."""

    model_config = ConfigDict(extra="forbid")

    title: str = Field(max_length=200)
    messages: list[ChatMessageIn] = Field(default_factory=list)
    project_id: str | None = None


class ProjectCreate(BaseModel):
    """Create a project folder."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=120)


class ProjectRename(BaseModel):
    """Rename a project folder."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=120)


@router.get("")
def list_conversations(store: ChatStore = Depends(get_chat_store)) -> list[dict]:
    """List the caller's conversations (most recent first)."""
    return store.list_conversations()


@router.get("/projects")
def list_projects(store: ChatStore = Depends(get_chat_store)) -> list[dict]:
    """List the caller's project folders."""
    return store.list_projects()


@router.put("/{conv_id}")
def upsert_conversation(
    conv_id: str,
    payload: ConversationUpsert,
    store: ChatStore = Depends(get_chat_store),
) -> dict:
    """Create or replace a conversation (the sync write path)."""
    return store.upsert_conversation(
        conv_id,
        title=payload.title,
        messages=[m.model_dump() for m in payload.messages],
        project_id=payload.project_id,
    )


@router.delete("/{conv_id}", status_code=204)
def delete_conversation(conv_id: str, store: ChatStore = Depends(get_chat_store)) -> None:
    """Delete a conversation (idempotent)."""
    store.delete_conversation(conv_id)


@router.post("/projects", status_code=201)
def create_project(payload: ProjectCreate, store: ChatStore = Depends(get_chat_store)) -> dict:
    """Create a project folder."""
    return store.create_project(payload.name)


@router.patch("/projects/{proj_id}")
def rename_project(
    proj_id: str, payload: ProjectRename, store: ChatStore = Depends(get_chat_store)
) -> dict:
    """Rename a project folder."""
    record = store.rename_project(proj_id, payload.name)
    if record is None:
        raise InvalidRequestError(f"unknown project: {proj_id}")
    return record


@router.delete("/projects/{proj_id}", status_code=204)
def delete_project(proj_id: str, store: ChatStore = Depends(get_chat_store)) -> None:
    """Delete a project folder (idempotent; its conversations are unassigned)."""
    store.delete_project(proj_id)
