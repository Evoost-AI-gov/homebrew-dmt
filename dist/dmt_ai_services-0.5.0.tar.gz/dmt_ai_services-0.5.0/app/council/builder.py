"""Custom-agent builder (F4): validate and render governed DMT-custom agents.

DMT users can define their own council agents, but governance is non-negotiable:
a custom agent is **always an expert** (never the Director or a gate), its tool
grants are a subset of the read-only allow-list, and its persona is validated and
screened for prompt-injection before it can be compiled. New custom agents enter
as ``pending`` and must be **approved by Compliance** before they can speak in a
conversation.

Rendering produces a ``.agent.md`` document (the same governed format as the canon)
so a custom agent compiles through the exact same persona compiler — one code path,
no special-casing at inference time.
"""

from __future__ import annotations

import re

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.council.persona import ALLOWED_TOOLS
from app.errors import InvalidRequestError
from app.guardrails import scan_for_injection

_VALID_LENSES = {"sovereign", "investor", "both"}
_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,62}[a-z0-9]$")

# Custom agents may only ever ground in retrieval plus the read-only domain tools
# below — never anything that could reach the decision plane directly.
CUSTOM_ALLOWED_TOOLS = ALLOWED_TOOLS

MAX_PERSONA_LEN = 4_000
MAX_NAME_LEN = 80


class CustomAgentSpec(BaseModel):
    """A request to create a custom DMT council agent (pending approval)."""

    model_config = ConfigDict(extra="forbid")

    agent_id: str = Field(min_length=3, max_length=64)
    display_name: str = Field(min_length=3, max_length=MAX_NAME_LEN)
    description: str = Field(default="", max_length=300)
    persona: str = Field(min_length=20, max_length=MAX_PERSONA_LEN)
    lens: list[str] = Field(default_factory=lambda: ["both"])
    tool_grants: list[str] = Field(default_factory=lambda: ["retrieval.query"])
    created_by: str = Field(default="", max_length=128)

    @field_validator("agent_id")
    @classmethod
    def _slug(cls, value: str) -> str:
        if not _SLUG_RE.match(value):
            raise ValueError("agent_id must be a lowercase slug (a-z, 0-9, '-')")
        return value

    @field_validator("lens")
    @classmethod
    def _lenses(cls, value: list[str]) -> list[str]:
        bad = [v for v in value if v not in _VALID_LENSES]
        if bad:
            raise ValueError(f"invalid lens: {bad}")
        return value or ["both"]

    @field_validator("tool_grants")
    @classmethod
    def _tools(cls, value: list[str]) -> list[str]:
        unknown = sorted(set(value) - CUSTOM_ALLOWED_TOOLS)
        if unknown:
            raise ValueError(f"tools outside the custom allow-list: {unknown}")
        # retrieval is always available to a council agent.
        return list(dict.fromkeys(["retrieval.query", *value]))


def validate_spec(spec: CustomAgentSpec) -> None:
    """Screen the persona for prompt-injection and obvious governance violations."""
    if scan_for_injection(spec.persona):
        raise InvalidRequestError(
            "the persona contains instruction-override patterns and cannot be approved"
        )


def render_agent_md(spec: CustomAgentSpec) -> str:
    """Render a validated spec to the governed ``.agent.md`` format."""
    validate_spec(spec)
    grants = ", ".join(spec.tool_grants)
    return (
        "---\n"
        f"name: {spec.display_name}\n"
        f'description: "{spec.description}"\n'
        f"tools: [{grants}]\n"
        "custom: true\n"
        f"created_by: {spec.created_by}\n"
        "---\n\n"
        f"# {spec.display_name}\n\n"
        f"{spec.persona.strip()}\n"
    )
