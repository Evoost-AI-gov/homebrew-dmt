"""Inference orchestration: guardrails -> routing -> provider (with fallback).

This is the single place where a request is turned into an answer: it enforces
the abstention policy, screens context for injection, resolves the logical model
to concrete candidates, and tries them in order, falling back only on genuine
upstream failures (5xx / network), never on a configuration error.
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator

from app.errors import UpstreamError
from app.guardrails import flag_injection, has_grounding_context
from app.providers import Provider
from app.routing import Router
from app.schemas import (
    ChatChoice,
    ChatChoiceMessage,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatMessage,
    Citation,
    EmbeddingRequest,
    EmbeddingResponse,
)

_logger = logging.getLogger("dmt_ai.inference")

_ABSTENTION_TEXT = (
    "I don't have enough grounded evidence to answer that. No approved source context was provided."
)

_GROUNDED_SYSTEM_PROMPT = (
    "You are the DMT land-intelligence assistant. Answer the question using ONLY the "
    "provided context passages. Cite the source file name(s) you used. If the context "
    "is insufficient, reply that you do not have enough grounded evidence."
)

# Domain identity for the direct (non-council) chat path. DMT is the Abu Dhabi
# Department of Municipalities & Transport — never the chemical compound. Prepended
# as a system message so the Director answers in the right frame.
_DMT_IDENTITY = (
    "In this platform, DMT always means the Department of Municipalities & Transport "
    "(DMT), the Abu Dhabi government department for municipal services, urban planning, "
    "land and real-estate regulation, and transport. It never refers to the chemical "
    "compound. Answer every question in that government / land-intelligence frame. "
    "Write in clear, plain, formal language (no emojis)."
)


def _with_identity(request: ChatCompletionRequest) -> ChatCompletionRequest:
    """Prepend the DMT domain-identity system message (idempotent)."""
    if request.messages and request.messages[0].role == "system":
        return request
    return request.model_copy(
        update={"messages": [ChatMessage(role="system", content=_DMT_IDENTITY), *request.messages]}
    )


# Thinking effort (instant/medium/high) -> a per-call max_tokens budget.
_EFFORT_MAX_TOKENS = {"instant": 320, "medium": 768, "high": 1536}


def _apply_effort(request: ChatCompletionRequest) -> ChatCompletionRequest:
    """Map the request's ``effort`` to a token budget (cost + latency control).

    Lower effort = shorter, faster answers. Omitted/unknown keeps the caller's
    ``max_tokens`` (fail-safe).
    """
    effort = getattr(request, "effort", None)
    if not effort:
        return request
    budget = _EFFORT_MAX_TOKENS.get(effort)
    if budget is None:
        return request
    return request.model_copy(update={"max_tokens": budget})


def build_grounded_request(
    query: str,
    citations: list[Citation],
    *,
    model: str,
    max_tokens: int,
) -> ChatCompletionRequest:
    """Assemble a grounded chat request from retrieved citations.

    Each citation becomes an untrusted ``tool`` (context) message; the model is
    instructed to answer only from that context and ``require_grounding`` is set.
    """
    messages: list[ChatMessage] = [ChatMessage(role="system", content=_GROUNDED_SYSTEM_PROMPT)]
    for citation in citations:
        if not citation.text:
            # Skip citations with no snippet: empty context is not evidence. If
            # none remain, the chat layer abstains (require_grounding + no tool).
            continue
        context = f"[source: {citation.canonical_file} | tier: {citation.tier}]\n{citation.text}"
        messages.append(ChatMessage(role="tool", content=context))
    messages.append(ChatMessage(role="user", content=query))
    return ChatCompletionRequest(
        model=model,
        messages=messages,
        max_tokens=max_tokens,
        require_grounding=True,
    )


class InferenceService:
    """Turn API requests into governed inference responses."""

    def __init__(self, provider: Provider, router: Router) -> None:
        self._provider = provider
        self._router = router

    async def chat_stream(self, request: ChatCompletionRequest) -> AsyncIterator[str]:
        """Stream a governed chat completion (guardrails + routing + fallback).

        Enforces the same abstention/injection policy as ``chat``, then streams
        token deltas from the first candidate that serves them. A provider without
        streaming falls back to a single ``chat`` call (yields the answer once).
        """
        request = _with_identity(_apply_effort(request))
        if request.require_grounding and not has_grounding_context(request):
            yield _ABSTENTION_TEXT
            return
        flagged = set(flag_injection(request))
        if flagged:
            _logger.warning("prompt_injection_dropped", extra={"count": len(flagged)})
            kept = [m for i, m in enumerate(request.messages) if i not in flagged]
            request = request.model_copy(update={"messages": kept})
            if request.require_grounding and not has_grounding_context(request):
                yield _ABSTENTION_TEXT
                return
        last_exc: Exception | None = None
        for model in self._router.resolve(request.model):
            try:
                stream = getattr(self._provider, "chat_stream", None)
                if stream is None:
                    response = await self._provider.chat(request, model)
                    if response.choices:
                        yield response.choices[0].message.content
                    return
                async for delta in stream(request, model):
                    yield delta
                return
            except UpstreamError as exc:
                last_exc = exc
                _logger.warning("stream_model_failed_falling_back", extra={"model": model})
        raise last_exc or UpstreamError("all candidate models failed")

    async def chat(
        self, request: ChatCompletionRequest, role: str | None = None
    ) -> ChatCompletionResponse:
        """Run a chat completion, abstaining or falling back as policy dictates.

        When ``role`` is given (council director/expert/gate) the model is resolved
        for that role — so experts answer on the fast tier while the Director keeps
        the reasoning model — otherwise the request's logical model is used.
        """
        request = _with_identity(_apply_effort(request))
        if request.require_grounding and not has_grounding_context(request):
            return self._abstention(request.model)

        flagged = set(flag_injection(request))
        if flagged:
            # Retrieved context is untrusted: DROP messages that look like
            # injection attempts rather than forwarding them to the model.
            _logger.warning("prompt_injection_dropped", extra={"count": len(flagged)})
            kept = [m for i, m in enumerate(request.messages) if i not in flagged]
            request = request.model_copy(update={"messages": kept})
            if request.require_grounding and not has_grounding_context(request):
                return self._abstention(request.model)

        candidates = (
            self._router.resolve_for_role(role)
            if role is not None
            else self._router.resolve(request.model)
        )
        last_exc: Exception | None = None
        for model in candidates:
            try:
                return await self._provider.chat(request, model)
            except UpstreamError as exc:
                last_exc = exc
                _logger.warning("model_failed_falling_back", extra={"model": model})
        raise last_exc or UpstreamError("all candidate models failed")

    async def chat_stream_for_role(
        self, request: ChatCompletionRequest, role: str, usage_out: dict[str, int] | None = None
    ) -> AsyncIterator[str]:
        """Stream a chat answer using the model for the given council role.

        Resolves the role (director/expert/gate) to its model candidates, then
        streams from the first that works. A provider without streaming falls back
        to a single ``chat`` call (yields the full answer once). When ``usage_out``
        is given it is populated with the call's token usage (cost audit). Raises
        when no upstream can serve it.
        """
        last_exc: Exception | None = None
        for model in self._router.resolve_for_role(role):
            try:
                stream = getattr(self._provider, "chat_stream", None)
                if stream is None:
                    # Provider cannot stream — fall back to a single completion.
                    response = await self._provider.chat(request, model)
                    if usage_out is not None and response.usage is not None:
                        usage_out.update(response.usage.model_dump())
                    if response.choices:
                        yield response.choices[0].message.content
                    return
                async for delta in stream(request, model, usage_out):
                    yield delta
                return
            except UpstreamError as exc:
                last_exc = exc
                _logger.warning("stream_model_failed_falling_back", extra={"model": model})
        raise last_exc or UpstreamError("all candidate models failed")

    async def embeddings(self, request: EmbeddingRequest) -> EmbeddingResponse:
        """Run an embeddings request with ordered fallback."""
        last_exc: Exception | None = None
        for model in self._router.resolve(request.model):
            try:
                return await self._provider.embeddings(request, model)
            except UpstreamError as exc:
                last_exc = exc
                _logger.warning("model_failed_falling_back", extra={"model": model})
        raise last_exc or UpstreamError("all candidate models failed")

    @staticmethod
    def _abstention(model: str) -> ChatCompletionResponse:
        return ChatCompletionResponse(
            id="chatcmpl-abstain",
            model=model,
            choices=[
                ChatChoice(
                    index=0,
                    message=ChatChoiceMessage(role="assistant", content=_ABSTENTION_TEXT),
                    finish_reason="stop",
                )
            ],
            grounded=False,
            abstained=True,
        )
