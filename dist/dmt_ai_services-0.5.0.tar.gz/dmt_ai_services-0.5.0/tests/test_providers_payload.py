"""Test the Azure chat payload is compatible across model families."""

from __future__ import annotations

from app.providers import _azure_chat_payload
from app.schemas import ChatCompletionRequest, ChatMessage


def _req(**over: object) -> ChatCompletionRequest:
    return ChatCompletionRequest(
        model="dmt-expert-fast",
        messages=[ChatMessage(role="user", content="hi")],
        **over,
    )


def test_max_tokens_is_remapped_to_max_completion_tokens() -> None:
    payload = _azure_chat_payload(_req(max_tokens=256))
    assert payload["max_completion_tokens"] == 256
    assert "max_tokens" not in payload


def test_non_default_sampling_is_dropped_for_gpt5_o_series_compat() -> None:
    payload = _azure_chat_payload(_req(temperature=0.2, top_p=0.9))
    # gpt-5.x / o-series reject non-default temperature/top_p; omit them (defaults).
    assert "temperature" not in payload
    assert "top_p" not in payload


def test_messages_and_model_free_body_are_preserved() -> None:
    payload = _azure_chat_payload(_req())
    assert payload["messages"] == [{"role": "user", "content": "hi"}]
    # The deployment is keyed in the URL, not the body.
    assert "model" not in payload
    assert "require_grounding" not in payload


def test_tool_role_grounding_is_forwarded_as_user_context() -> None:
    # gpt-5.x / o-series reject a 'tool' message that is not a reply to a tool_call;
    # the council injects grounding citations as 'tool' messages, so remap to 'user'.
    request = ChatCompletionRequest(
        model="dmt-expert-fast",
        messages=[
            ChatMessage(role="system", content="s"),
            ChatMessage(role="tool", content="[source: x] evidence"),
            ChatMessage(role="user", content="hi"),
        ],
    )
    payload = _azure_chat_payload(request)
    roles = [m["role"] for m in payload["messages"]]
    assert "tool" not in roles
    assert roles == ["system", "user", "user"]
    assert payload["messages"][1]["content"] == "[source: x] evidence"
