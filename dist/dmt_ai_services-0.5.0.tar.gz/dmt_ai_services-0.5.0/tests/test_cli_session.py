"""ChatSession tests — history folding, veto exit code, json mode, portability."""

import io
import json

import httpx

from app.cli.client import CouncilClient
from app.cli.config import resolve
from app.cli.session import ChatSession

DONE = {
    "id": "t1",
    "conversation_id": "conv-x",
    "model": "dmt-brain",
    "messages": [
        {
            "agent_id": "biz-valuation-expert",
            "content": "Rate is 42 AED/sqm.",
            "confidence": "medium",
            "abstained": False,
            "sources": ["rate_table.json"],
        }
    ],
    "synthesis": None,
    "veto": None,
    "meta": {"participants": ["biz-valuation-expert"], "total_tokens": 10},
}

VETO_DONE = {
    **DONE,
    "messages": [],
    "veto": {"gate": "compliance-data-governance", "reason": "provenance missing"},
}


def _session(handler, tmp_path, **kwargs):
    config = resolve(base_url="http://gw.test", api_key="k", color=False, transcript=True)
    object.__setattr__(config, "state_dir", tmp_path)
    client = CouncilClient(config, transport=httpx.MockTransport(handler))
    options = {"json_mode": False, "stream": False, "out": io.StringIO()}
    options.update(kwargs)
    return ChatSession(config, client, **options)


def _done_handler(payload):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=payload)

    return handler


def test_turn_folds_assistant_reply_into_history(tmp_path):
    session = _session(_done_handler(DONE), tmp_path)
    assert session.ask("what is the rate?") == 0
    roles = [m["role"] for m in session.messages]
    assert roles == ["user", "assistant"]
    assert session.messages[-1]["content"] == "Rate is 42 AED/sqm."
    assert session.conversation_id == "conv-x"


def test_veto_maps_to_exit_code_2(tmp_path):
    session = _session(_done_handler(VETO_DONE), tmp_path)
    assert session.ask("do the forbidden thing") == 2
    assert session.last_veto["gate"] == "compliance-data-governance"


def test_failed_turn_keeps_no_half_state(tmp_path):
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            503, json={"error": {"code": "upstream_not_configured", "message": "no upstream"}}
        )

    session = _session(handler, tmp_path)
    assert session.ask("anything") == 1
    assert session.messages == []  # the user turn is rolled back


def test_json_mode_emits_ndjson_events(tmp_path):
    out = io.StringIO()
    session = _session(_done_handler(DONE), tmp_path, json_mode=True, out=out)
    assert session.ask("rate?") == 0
    events = [json.loads(line) for line in out.getvalue().splitlines()]
    assert events[0]["event"] == "message_done"
    assert events[0]["meta"]["total_tokens"] == 10


def test_transcript_records_turn_with_auth_fingerprint(tmp_path):
    session = _session(_done_handler(DONE), tmp_path)
    session.ask("rate?")
    events = session.transcript.read_events()
    kinds = [e["kind"] for e in events]
    assert kinds == ["user", "assistant"]
    assert events[1]["auth"] == session.config.auth_fingerprint
    assert events[1]["meta"]["total_tokens"] == 10


def test_transcript_disabled_when_configured_off(tmp_path):
    config = resolve(base_url="http://gw.test", api_key="k", color=False, transcript=False)
    object.__setattr__(config, "state_dir", tmp_path)
    client = CouncilClient(config, transport=httpx.MockTransport(_done_handler(DONE)))
    session = ChatSession(config, client, json_mode=True, stream=False, out=io.StringIO())
    session.ask("rate?")
    assert session.transcript.read_events() == []


def test_sync_up_and_resume_roundtrip(tmp_path):
    """The portability loop: CLI -> shared store -> resumed CLI session."""
    store: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/v1/council/chat":
            return httpx.Response(200, json=DONE)
        if request.method == "PUT":
            conv_id = request.url.path.rsplit("/", 1)[-1]
            store[conv_id] = {"id": conv_id, **json.loads(request.content)}
            return httpx.Response(200, json=store[conv_id])
        if request.method == "GET":
            return httpx.Response(200, json=list(store.values()))
        return httpx.Response(405)

    session = _session(handler, tmp_path)
    session.ask("rate?")
    session.sync_up(title="pricing question")
    assert store["conv-x"]["title"] == "pricing question"

    resumed = _session(handler, tmp_path)
    resumed.load_from(store["conv-x"])
    assert resumed.conversation_id == "conv-x"
    assert [m["role"] for m in resumed.messages] == ["user", "assistant"]


def test_unary_message_done_renders_reply_body(tmp_path):
    """--no-stream: the reply text must reach the renderer from message_done,
    not just the metadata footer (Copilot PR #118 finding)."""
    out = io.StringIO()
    session = _session(_done_handler(DONE), tmp_path, out=out)
    assert session.ask("rate?") == 0
    text = out.getvalue()
    assert "Rate is 42 AED/sqm." in text  # the assistant body is visible
    assert "tokens" in text  # and the footer


def test_stream_mode_does_not_duplicate_body(tmp_path):
    """Streaming renders bodies via token/agent_message events; message_done
    must NOT re-print them (would double every reply)."""
    out = io.StringIO()
    session = _session(_done_handler(DONE), tmp_path, out=out, stream=True)
    session.ask("rate?")
    # In stream=True with a unary mock the client still only emits message_done,
    # so the body should NOT be rendered by session (no double).
    assert "Rate is 42 AED/sqm." not in out.getvalue()
