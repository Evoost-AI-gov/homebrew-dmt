"""Tests for enterprise streaming: upstream SSE parsing, role routing, live turns."""

from __future__ import annotations

import pytest

from app.providers import AzureOpenAIProvider, OpenAICompatibleProvider, _parse_upstream_sse
from app.routing import ROLE_TASKS, Router
from app.schemas import ChatCompletionRequest, ChatMessage

# --- Upstream SSE parsing ------------------------------------------------------


def test_parse_upstream_sse_extracts_delta() -> None:
    line = 'data: {"choices":[{"delta":{"content":"hello"}}]}'
    assert _parse_upstream_sse(line) == "hello"


def test_parse_upstream_sse_skips_done_and_junk() -> None:
    assert _parse_upstream_sse("data: [DONE]") is None
    assert _parse_upstream_sse("event: ping") is None
    assert _parse_upstream_sse("data: not-json") is None
    assert _parse_upstream_sse('data: {"choices":[]}') is None


# --- Role routing ---------------------------------------------------------------


def test_router_resolves_role_to_model() -> None:
    router = Router()
    # Roles resolve through task alias -> logical model -> deployment candidates.
    # On the default (Azure) table every chat route lands on dmt-brain.
    assert router.resolve_for_role("director") == ["dmt-brain"]
    assert router.resolve_for_role("expert") == ["dmt-brain"]
    # Unknown role falls back to the general chat model.
    assert router.resolve_for_role("unknown") == router.resolve("general")


def test_role_routing_defaults_are_distinct() -> None:
    # Director (reasoning) and expert (fast) map to distinct TASK tiers, even
    # though both tasks may resolve to the same deployment on a single-model setup.
    assert ROLE_TASKS["director"] != ROLE_TASKS["expert"]


# --- Provider streaming ----------------------------------------------------------


def _chat_request() -> ChatCompletionRequest:
    return ChatCompletionRequest(
        model="dmt-brain", messages=[ChatMessage(role="user", content="hi")]
    )


async def test_openai_provider_streams_deltas() -> None:
    import httpx

    sse_body = (
        'data: {"choices":[{"delta":{"content":"Hello"}}]}\n\n'
        'data: {"choices":[{"delta":{"content":" world"}}]}\n\n'
        "data: [DONE]\n\n"
    )

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text=sse_body, headers={"content-type": "text/event-stream"})

    provider = OpenAICompatibleProvider(base_url="http://x", transport=httpx.MockTransport(handler))
    chunks = [c async for c in provider.chat_stream(_chat_request(), "dmt-brain")]
    assert chunks == ["Hello", " world"]


async def test_azure_provider_streams_via_native_path() -> None:
    import httpx

    seen: dict = {}
    sse_body = 'data: {"choices":[{"delta":{"content":"hi"}}]}\n\ndata: [DONE]\n\n'

    def handler(request: httpx.Request) -> httpx.Response:
        seen["url"] = str(request.url)
        return httpx.Response(200, text=sse_body, headers={"content-type": "text/event-stream"})

    provider = AzureOpenAIProvider(
        endpoint="https://dmt.cognitiveservices.azure.com",
        api_key="k",
        transport=httpx.MockTransport(handler),
    )
    chunks = [c async for c in provider.chat_stream(_chat_request(), "dmt-brain")]
    assert chunks == ["hi"]
    assert "/openai/deployments/dmt-brain/chat/completions" in seen["url"]


async def test_stream_strips_reasoning_think_blocks() -> None:
    import httpx

    # A reasoning model emits <think>…</think> (split across chunks) before the answer.
    sse_body = (
        'data: {"choices":[{"delta":{"content":"<thi"}}]}\n\n'
        'data: {"choices":[{"delta":{"content":"nk>reasoning"}}]}\n\n'
        'data: {"choices":[{"delta":{"content":" trace</think>"}}]}\n\n'
        'data: {"choices":[{"delta":{"content":"Hello"}}]}\n\n'
        'data: {"choices":[{"delta":{"content":" there"}}]}\n\n'
        "data: [DONE]\n\n"
    )

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text=sse_body, headers={"content-type": "text/event-stream"})

    provider = AzureOpenAIProvider(
        endpoint="https://dmt.cognitiveservices.azure.com",
        api_key="k",
        transport=httpx.MockTransport(handler),
    )
    chunks = [c async for c in provider.chat_stream(_chat_request(), "dmt-brain")]
    assert "".join(chunks) == "Hello there"
    assert all("think" not in c.lower() and "reasoning" not in c.lower() for c in chunks)


async def test_stream_rejected_on_4xx() -> None:
    import httpx

    from app.errors import UpstreamRejectedError

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"error": "bad key"})

    provider = OpenAICompatibleProvider(base_url="http://x", transport=httpx.MockTransport(handler))
    with pytest.raises(UpstreamRejectedError):
        _ = [c async for c in provider.chat_stream(_chat_request(), "dmt-brain")]
