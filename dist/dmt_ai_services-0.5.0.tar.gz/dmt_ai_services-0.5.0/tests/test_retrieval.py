"""Tests for the online retrieval (RAG) read path."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.errors import RetrievalNotConfiguredError, UpstreamError
from app.main import create_app
from app.retrieval import (
    LocalEmbedder,
    NullEmbedder,
    RetrievalService,
    VectorIndex,
    build_embedder,
    load_index,
)
from app.schemas import (
    ChatChoice,
    ChatChoiceMessage,
    ChatCompletionRequest,
    ChatCompletionResponse,
    EmbeddingRequest,
    EmbeddingResponse,
    Usage,
)
from app.settings import Settings

AUTH = {"X-API-Key": "test-key"}

# Three orthogonal unit vectors make similarity deterministic and obvious.
_VECS = {
    "auth-1": [1.0, 0.0, 0.0],
    "ref-1": [0.0, 1.0, 0.0],
    "auth-2": [0.0, 0.0, 1.0],
}
_META = {
    "auth-1": ("plan_2030.md", "planning", "authoritative"),
    "ref-1": ("gehl_book.md", "urbanism", "reference"),
    "auth-2": ("adrec_law.md", "legal", "authoritative"),
}


def _write_index(tmp_path: Path) -> tuple[Path, Path]:
    emb = tmp_path / "embeddings.jsonl"
    chk = tmp_path / "chunks.jsonl"
    with emb.open("w", encoding="utf-8") as eh, chk.open("w", encoding="utf-8") as ch:
        for cid, vec in _VECS.items():
            canonical, domain, tier = _META[cid]
            eh.write(
                json.dumps(
                    {
                        "chunk_id": cid,
                        "canonical_file": canonical,
                        "domain": domain,
                        "tier": tier,
                        "embedding": vec,
                    }
                )
                + "\n"
            )
            ch.write(json.dumps({"chunk_id": cid, "text": f"text of {cid}"}) + "\n")
    return emb, chk


class StaticEmbedder:
    """Returns a fixed query vector regardless of input."""

    def __init__(self, vector: list[float]) -> None:
        self._vector = vector

    async def embed(self, text: str) -> list[float]:
        del text
        return self._vector


class FakeProvider:
    async def chat(self, request: ChatCompletionRequest, model: str) -> ChatCompletionResponse:
        # Echo back which sources it "used" to prove context was injected.
        tool_msgs = [m.content for m in request.messages if m.role == "tool"]
        return ChatCompletionResponse(
            id="chatcmpl-test",
            model=model,
            choices=[
                ChatChoice(
                    index=0,
                    message=ChatChoiceMessage(
                        role="assistant", content=f"used {len(tool_msgs)} sources"
                    ),
                    finish_reason="stop",
                )
            ],
            usage=Usage(),
        )

    async def embeddings(self, request: EmbeddingRequest, model: str) -> EmbeddingResponse:
        raise NotImplementedError


# --- unit tests: VectorIndex ---------------------------------------------------


def test_index_search_ranks_by_similarity(tmp_path: Path) -> None:
    emb, chk = _write_index(tmp_path)
    index = VectorIndex.load(emb, chk)
    hits = index.search([1.0, 0.0, 0.0], top_k=3, tier="all", min_score=0.0)
    assert hits[0].chunk_id == "auth-1"
    assert hits[0].score == pytest.approx(1.0)
    assert hits[0].text == "text of auth-1"


def test_index_tier_filter(tmp_path: Path) -> None:
    emb, chk = _write_index(tmp_path)
    index = VectorIndex.load(emb, chk)
    hits = index.search([0.0, 1.0, 0.0], top_k=3, tier="authoritative", min_score=0.0)
    assert all(h.tier == "authoritative" for h in hits)
    assert all(h.chunk_id != "ref-1" for h in hits)


def test_index_min_score_abstains(tmp_path: Path) -> None:
    emb, chk = _write_index(tmp_path)
    index = VectorIndex.load(emb, chk)
    # Query aligned with auth-1 (cosine 1.0): a threshold just below 1.0 keeps it,
    # a threshold above 1.0 drops every hit (retrieval abstention).
    hits = index.search([1.0, 0.0, 0.0], top_k=3, tier="all", min_score=0.99)
    assert [h.chunk_id for h in hits] == ["auth-1"]
    hits_none = index.search([1.0, 0.0, 0.0], top_k=3, tier="all", min_score=1.01)
    assert hits_none == []


def test_index_access_scope(tmp_path: Path) -> None:
    emb = tmp_path / "e.jsonl"
    emb.write_text(
        json.dumps(
            {
                "chunk_id": "scoped-1",
                "canonical_file": "secret.md",
                "domain": "legal",
                "tier": "authoritative",
                "access_scope": "tenant-a",
                "embedding": [1.0, 0.0, 0.0],
            }
        )
        + "\n",
        encoding="utf-8",
    )
    index = VectorIndex.load(emb, None)
    assert index.search([1.0, 0.0, 0.0], top_k=1, tier="all", min_score=0.0) == []
    allowed = index.search(
        [1.0, 0.0, 0.0], top_k=1, tier="all", min_score=0.0, access_scopes=frozenset({"tenant-a"})
    )
    assert allowed[0].chunk_id == "scoped-1"


async def test_retrieval_service_not_configured() -> None:
    service = RetrievalService(NullEmbedder(), None)
    assert service.configured is False
    with pytest.raises(RetrievalNotConfiguredError):
        await service.retrieve("hello")


async def test_retrieval_service_aclose_closes_embedder() -> None:
    class _ClosableEmbedder:
        closed = False

        async def embed(self, text: str) -> list[float]:
            del text
            return [1.0, 0.0, 0.0]

        async def aclose(self) -> None:
            self.closed = True

    embedder = _ClosableEmbedder()
    service = RetrievalService(embedder, None)
    await service.aclose()
    assert embedder.closed is True


def test_load_index_missing_path_returns_none() -> None:
    assert load_index("", "") is None
    assert load_index("/no/such/file.jsonl", "") is None


def test_index_dimension_mismatch_raises(tmp_path: Path) -> None:
    emb, chk = _write_index(tmp_path)  # 3-dimensional index
    index = VectorIndex.load(emb, chk)
    with pytest.raises(UpstreamError):
        index.search([1.0, 0.0], top_k=1, tier="all", min_score=0.0)  # 2-dim query


def test_build_embedder_local_returns_local_embedder() -> None:
    # retrieval_embed_local=true -> the in-process sovereign embedder (no egress).
    embedder = build_embedder(
        base_url="",
        model="intfloat/multilingual-e5-base",
        query_prefix="query: ",
        api_key="",
        timeout_s=15.0,
        local=True,
    )
    assert isinstance(embedder, LocalEmbedder)


def test_build_embedder_no_config_is_fail_closed() -> None:
    embedder = build_embedder(
        base_url="",
        model="m",
        query_prefix="",
        api_key="",
        timeout_s=15.0,
        local=False,
    )
    assert isinstance(embedder, NullEmbedder)


def test_index_coerces_unknown_tier(tmp_path: Path) -> None:
    emb = tmp_path / "e.jsonl"
    emb.write_text(
        json.dumps(
            {
                "chunk_id": "x",
                "canonical_file": "f.md",
                "domain": "d",
                "tier": "totally-unknown",
                "embedding": [1.0, 0.0, 0.0],
            }
        )
        + "\n",
        encoding="utf-8",
    )
    index = VectorIndex.load(emb, None)
    hit = index.search([1.0, 0.0, 0.0], top_k=1, tier="all", min_score=0.0)[0]
    assert hit.tier == "reference"  # unknown coerced to the less-privileged tier


def test_load_index_malformed_returns_none(tmp_path: Path) -> None:
    bad = tmp_path / "bad.jsonl"
    bad.write_text("this is not json\n", encoding="utf-8")
    assert load_index(str(bad), "") is None  # disabled, not a startup crash


# --- endpoint tests ------------------------------------------------------------


def _client(
    tmp_path: Path,
    *,
    with_retrieval: bool = True,
    embed_vector: list[float] | None = None,
) -> TestClient:
    settings = Settings(_env_file=None, app_env="development", api_keys="test-key")
    retrieval_service = None
    if with_retrieval:
        emb, chk = _write_index(tmp_path)
        index = VectorIndex.load(emb, chk)
        embedder = StaticEmbedder(embed_vector if embed_vector is not None else [1.0, 0.0, 0.0])
        retrieval_service = RetrievalService(embedder, index)
    else:
        retrieval_service = RetrievalService(NullEmbedder(), None)
    app = create_app(
        settings=settings, provider=FakeProvider(), retrieval_service=retrieval_service
    )
    return TestClient(app)


def test_retrieve_endpoint(tmp_path: Path) -> None:
    response = _client(tmp_path).post(
        "/v1/retrieve", json={"query": "plot ratio", "tier": "authoritative"}, headers=AUTH
    )
    assert response.status_code == 200
    body = response.json()
    assert body["citations"][0]["chunk_id"] == "auth-1"
    assert all(c["tier"] == "authoritative" for c in body["citations"])


def test_retrieve_requires_auth(tmp_path: Path) -> None:
    assert _client(tmp_path).post("/v1/retrieve", json={"query": "x"}).status_code == 401


def test_retrieve_not_configured(tmp_path: Path) -> None:
    response = _client(tmp_path, with_retrieval=False).post(
        "/v1/retrieve", json={"query": "x"}, headers=AUTH
    )
    assert response.status_code == 503
    assert response.json()["error"]["code"] == "retrieval_not_configured"


def test_answer_grounded(tmp_path: Path) -> None:
    response = _client(tmp_path).post(
        "/v1/answer", json={"query": "what is the plan", "model": "dmt-brain"}, headers=AUTH
    )
    assert response.status_code == 200
    body = response.json()
    assert body["abstained"] is False
    assert body["grounded"] is True
    assert len(body["citations"]) >= 1
    assert "sources" in body["answer"]


def test_answer_abstains_when_no_evidence(tmp_path: Path) -> None:
    # An equidistant query (~0.577 to each axis) with a high threshold -> no
    # citations pass -> the gateway abstains without calling the model.
    response = _client(tmp_path, embed_vector=[1.0, 1.0, 1.0]).post(
        "/v1/answer", json={"query": "unrelated", "min_score": 0.9}, headers=AUTH
    )
    assert response.status_code == 200
    body = response.json()
    assert body["abstained"] is True
    assert body["grounded"] is False
    assert body["citations"] == []


def test_answer_abstains_when_citations_have_no_text(tmp_path: Path) -> None:
    # Index loaded WITHOUT a chunks file -> citations carry no text -> not usable
    # evidence -> the answer route abstains and returns no citations.
    emb, _ = _write_index(tmp_path)
    index = VectorIndex.load(emb, None)
    settings = Settings(_env_file=None, app_env="development", api_keys="test-key")
    service = RetrievalService(StaticEmbedder([1.0, 0.0, 0.0]), index)
    app = create_app(settings=settings, provider=FakeProvider(), retrieval_service=service)
    response = TestClient(app).post("/v1/answer", json={"query": "x"}, headers=AUTH)
    assert response.status_code == 200
    body = response.json()
    assert body["abstained"] is True
    assert body["citations"] == []


def test_index_matrix_is_normalised(tmp_path: Path) -> None:
    emb = tmp_path / "e.jsonl"
    emb.write_text(
        json.dumps(
            {
                "chunk_id": "c1",
                "canonical_file": "f.md",
                "domain": "d",
                "tier": "authoritative",
                "embedding": [3.0, 4.0, 0.0],  # norm 5 -> should normalise to unit
            }
        )
        + "\n",
        encoding="utf-8",
    )
    index = VectorIndex.load(emb, None)
    hit = index.search([1.0, 0.0, 0.0], top_k=1, tier="all", min_score=0.0)[0]
    assert hit.score == pytest.approx(0.6)  # 3/5
