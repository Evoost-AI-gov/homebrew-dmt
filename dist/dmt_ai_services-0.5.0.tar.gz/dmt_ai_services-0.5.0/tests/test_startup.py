"""Startup lifespan: the sovereign token is pre-warmed so the first turn is fast."""

from __future__ import annotations

from types import SimpleNamespace

from app.main import _lifespan


async def test_lifespan_prewarms_the_provider_token() -> None:
    # The startup hook mints the Entra bearer up front so the first turn after a
    # deploy/restart skips the 401 -> refresh -> retry cold-start penalty.
    warmed: list[bool] = []
    provider = SimpleNamespace(warm=lambda: bool(warmed.append(True)))
    app = SimpleNamespace(state=SimpleNamespace(provider=provider))
    async with _lifespan(app):
        pass
    assert warmed == [True]


async def test_lifespan_tolerates_a_provider_without_warm() -> None:
    app = SimpleNamespace(state=SimpleNamespace(provider=SimpleNamespace()))
    async with _lifespan(app):
        pass  # no warm() -> startup proceeds without error
