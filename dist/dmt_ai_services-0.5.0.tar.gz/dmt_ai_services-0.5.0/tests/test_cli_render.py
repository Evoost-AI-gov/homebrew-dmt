"""Renderer backends — plain fallback is machine-safe; the rich backend renders
the Codex-style UX (boxed prompt echo, markdown content, badges, veto panel,
footer with tokens/elapsed) and degrades to plain text on a non-TTY."""

import io

import pytest

from app.cli import render
from app.cli.render import PlainRenderer, build_renderer

MSG = {
    "agent_id": "biz-valuation-expert",
    "content": "City-wide median **314.2 AED/sqm**.",
    "confidence": "high",
    "abstained": False,
    "sources": ["deal_rate_benchmarks@1"],
    "evidence": [{"chunk_id": "c1"}, {"chunk_id": "c2"}],
}


def _plain() -> tuple[PlainRenderer, io.StringIO]:
    out = io.StringIO()
    return build_renderer(color=False, out=out), out


def test_factory_plain_when_color_off():
    renderer, _ = _plain()
    assert isinstance(renderer, PlainRenderer)


def test_plain_full_turn_flow():
    renderer, out = _plain()
    renderer.user_prompt("rent benchmark?")
    renderer.turn_started(["biz-valuation-expert"])
    renderer.agent_started("biz-valuation-expert")
    renderer.token("biz-valuation-expert", "City-wide ")
    renderer.token("biz-valuation-expert", "median 314")
    renderer.message(MSG)
    renderer.synthesis_done({"total_tokens": 1234, "participants": ["a", "b"]}, "conv-1")
    text = out.getvalue()
    assert "you: rent benchmark?" in text
    assert "▶ valuation-expert" in text
    assert "City-wide median 314" in text
    assert "confidence: high" in text
    assert "sources: 1" in text
    assert "evidence: 2" in text
    assert "1,234 tokens" in text
    assert "2 agent(s)" in text
    assert "conversation conv-1" in text


def test_plain_veto_banner():
    renderer, out = _plain()
    renderer.veto("compliance-data-governance", "provenance missing")
    assert "GOVERNANCE VETO — compliance-data-governance" in out.getvalue()


def test_plain_no_ansi_when_color_off():
    renderer, out = _plain()
    renderer.turn_started(["director-program-orchestrator"])
    renderer.error("boom")
    assert "\x1b[" not in out.getvalue()


def test_plain_table_lists_rows():
    renderer, out = _plain()
    renderer.table(["agent", "kind"], [["director", "director"], ["valuation", "expert"]])
    text = out.getvalue()
    assert "agent" in text and "valuation" in text and "expert" in text


def test_plain_prompt_echo_prefix():
    renderer, out = _plain()
    renderer.user_prompt("hello council")
    assert out.getvalue().startswith("you: hello council")


@pytest.mark.skipif(not render._HAS_RICH, reason="rich extra not installed")
class TestRichRenderer:
    def _rich(self) -> tuple[render.RichRenderer, io.StringIO]:
        out = io.StringIO()
        return render.RichRenderer(color=True, out=out), out

    def test_factory_picks_rich_when_color_on(self):
        out = io.StringIO()
        assert isinstance(build_renderer(color=True, out=out), render.RichRenderer)

    def test_unary_message_renders_markdown_content_and_badges(self):
        renderer, out = self._rich()
        renderer.turn_started(["biz-valuation-expert"])
        renderer.message(MSG)  # no streamed tokens -> renders content directly
        renderer.synthesis_done({"total_tokens": 1234, "participants": ["a"]}, "conv-9")
        text = out.getvalue()
        assert "314.2 AED/sqm" in text  # markdown content rendered
        assert "▶ valuation-expert" in text
        assert "confidence: high" in text
        assert "sources: 1" in text
        assert "evidence: 2" in text
        assert "1,234 tokens" in text
        assert "conversation conv-9" in text

    def test_streamed_tokens_do_not_duplicate_content(self):
        renderer, out = self._rich()
        renderer.turn_started(["biz-valuation-expert"])
        renderer.agent_started("biz-valuation-expert")
        renderer.token("biz-valuation-expert", "streamed body")
        renderer.message({**MSG, "content": "streamed body"})
        renderer.end_turn()
        # The live region already displayed the content; message() adds badges,
        # never a second copy of the body.
        assert out.getvalue().count("streamed body") <= 1

    def test_synthesis_message_uses_synthesis_label(self):
        renderer, out = self._rich()
        renderer.message(MSG, synthesis=True)
        assert "synthesis" in out.getvalue()

    def test_veto_panel(self):
        renderer, out = self._rich()
        renderer.veto("compliance-data-governance", "provenance missing")
        text = out.getvalue()
        assert "GOVERNANCE VETO" in text
        assert "provenance missing" in text

    def test_abstain_badge(self):
        renderer, out = self._rich()
        renderer.message({**MSG, "abstained": True, "confidence": None})
        assert "abstained" in out.getvalue()

    def test_table(self):
        renderer, out = self._rich()
        renderer.table(["agent", "kind"], [["director", "director"]], title="roster")
        text = out.getvalue()
        assert "roster" in text and "director" in text

    def test_user_prompt_boxed(self):
        renderer, out = self._rich()
        renderer.user_prompt("rent benchmark?")
        text = out.getvalue()
        assert "you" in text and "rent benchmark?" in text

    def test_end_turn_without_stream_is_safe(self):
        renderer, _ = self._rich()
        renderer.end_turn()  # no live region -> no-op, no crash


def test_footer_shows_zero_tokens():
    """total_tokens=0 (fast streamed turns) must still render, not be dropped."""
    renderer, out = _plain()
    renderer.synthesis_done({"total_tokens": 0, "participants": []}, "conv-0")
    assert "0 tokens" in out.getvalue()


def test_plain_unary_renders_body():
    """Unary (--no-stream): no tokens streamed -> PlainRenderer.message renders
    the body itself so the reply isn't invisible."""
    renderer, out = _plain()
    renderer.turn_started(["biz-valuation-expert"])
    renderer.message(MSG)  # no agent_started/token first = unary
    text = out.getvalue()
    assert "314.2 AED/sqm" in text
    assert "▶ valuation-expert" in text


def test_plain_synthesis_started_label():
    renderer, out = _plain()
    renderer.turn_started(["a"])
    renderer.agent_started("director-program-orchestrator", synthesis=True)
    assert "synthesis" in out.getvalue()


def test_plain_color_true_but_piped_emits_no_ansi():
    """color=True but a non-TTY sink (StringIO/pipe) must stay machine-clean —
    ANSI is a terminal-only concern (Copilot PR #118 finding)."""
    out = io.StringIO()
    renderer = PlainRenderer(color=True, out=out)  # color ON, but not a TTY
    renderer.turn_started(["director-program-orchestrator"])
    renderer.error("boom")
    assert "\x1b[" not in out.getvalue()


def test_plain_agent_started_no_stray_whitespace_line():
    """agent_started must not emit a lone " \n" line before the body (Copilot
    PR #118 finding) — the header and the first token share one line."""
    renderer, out = _plain()
    renderer.turn_started(["biz-valuation-expert"])
    renderer.agent_started("biz-valuation-expert")
    renderer.token("biz-valuation-expert", "Hello")
    # After the header line, the next content is the token on the SAME logical
    # line (no standalone whitespace-only line between header and body).
    text = out.getvalue()
    assert "▶ valuation-expert" in text
    assert not any(line == " " for line in text.split("\n"))


def test_plain_banner_text_only():
    """PlainRenderer banner: text mark + status, no pixel art, machine-safe."""
    renderer, out = _plain()
    renderer.banner(
        ["ART"], title="DMT", subtitle="دائرة البلديات والنقل", status="endpoint x · auth none"
    )
    text = out.getvalue()
    assert "DMT" in text and "endpoint x" in text
    assert "\x1b[" not in text  # color=False sink stays clean


def test_banner_monogram_is_markup():
    from app.cli.banner import falcon_lines

    lines = falcon_lines()
    assert lines and all("[red]" in line for line in lines)
    assert len(lines) <= 8  # compact enough to sit beside the mark


def test_select_returns_none_when_not_a_tty():
    """The select widget must never block on a non-interactive sink (pipes,
    tests, --json) — the caller falls back to free text."""
    renderer, _ = _plain()
    assert renderer.select("What next?", ["a", "b"]) is None


def test_multi_select_returns_none_when_not_a_tty():
    renderer, _ = _plain()
    assert renderer.multi_select("roster", ["a", "b"]) is None


def test_status_line_no_ansi_off_tty():
    renderer, out = _plain()
    renderer.status_line("dmt-brain · 2 agents · 1,234 tokens")
    assert "1,234 tokens" in out.getvalue()
    assert "\x1b[" not in out.getvalue()


def test_help_detail_map_covers_commands():
    from app.cli.repl import _HELP_DETAIL

    assert "use" in _HELP_DETAIL and "sync" in _HELP_DETAIL
    assert all(len(v) < 120 for v in _HELP_DETAIL.values())  # one-liners


def test_plain_banner_draws_the_monogram():
    """Plain banner must show the block-letter DMT monogram (no colour), so the
    entry splash is recognisable even without the rich backend."""
    from app.cli.banner import falcon_lines

    renderer, out = _plain()
    renderer.banner(
        falcon_lines(),
        title="DMT",
        subtitle="دائرة البلديات والنقل",
        status="endpoint x · auth none",
    )
    text = out.getvalue()
    assert "██████" in text  # the monogram is drawn
    assert "DMT" in text
    assert "\x1b[" not in text  # machine-clean off a TTY


def test_banner_shows_entra_username_when_signed_in(monkeypatch, tmp_path):
    """The banner/status must show the cached Entra username, not 'auth none',
    when the user is signed in via dmt auth login (the MSAL cache)."""
    from app.cli.auth import AuthStatus

    monkeypatch.setenv("DMT_CONFIG_DIR", str(tmp_path))
    (tmp_path / "msal_cache.json").write_text("{}")
    signed = AuthStatus(signed_in=True, username="admin@evoost-ai.ae", tenant_id="organizations")
    monkeypatch.setattr("app.cli.repl.auth_status", lambda: signed)
    from app.cli.config import resolve
    from app.cli.repl import Repl

    session = type(
        "S",
        (),
        {
            "config": resolve(base_url="http://x", api_key=None, access_token=None),
            "conversation_id": "c1",
            "agents": ["director-program-orchestrator"],
            "delegate": False,
            "last_final": {},
        },
    )()
    repl = Repl.__new__(Repl)
    repl.session = session
    assert repl._auth_label() == "admin@evoost-ai.ae"


def test_banner_auth_none_when_signed_out(monkeypatch, tmp_path):
    from app.cli.auth import AuthStatus

    monkeypatch.setenv("DMT_CONFIG_DIR", str(tmp_path))
    monkeypatch.setattr("app.cli.repl.auth_status", lambda: AuthStatus(signed_in=False))
    from app.cli.config import resolve
    from app.cli.repl import Repl

    session = type(
        "S",
        (),
        {
            "config": resolve(base_url="http://x"),
            "conversation_id": "c1",
            "agents": ["director-program-orchestrator"],
            "delegate": False,
            "last_final": {},
        },
    )()
    repl = Repl.__new__(Repl)
    repl.session = session
    assert repl._auth_label() == "none"


@pytest.mark.skipif(not render._HAS_RICH, reason="rich extra not installed")
def test_rich_table_never_truncates_agent_ids():
    """The /agents roster must render full agent ids (no ellipsis) on a normal
    terminal: the agent column sizes to the longest id and the description
    wraps instead of being clipped."""
    from rich.console import Console

    out = io.StringIO()
    renderer = render.RichRenderer(color=True, out=out)
    renderer._console = Console(file=out, width=160)  # a real terminal's width
    long_id = "sustainability-livability-esg-expert"
    renderer.table(
        ["agent", "kind", "lens", "description"],
        [[long_id, "expert", "sovereign", "Owns Estidama Pearl, livability and ESG."]],
        title="governed roster",
    )
    text = out.getvalue()
    assert long_id in text
    assert "…" not in text


@pytest.mark.skipif(not render._HAS_RICH, reason="rich extra not installed")
def test_rich_banner_is_a_boxed_panel():
    """The entry banner is a Codex-style box: a rounded panel frame around the
    monogram + bilingual mark, with the status strip as the panel subtitle."""
    from app.cli.banner import falcon_lines

    buf = io.StringIO()
    renderer = render.RichRenderer(color=True, out=buf)
    renderer.banner(
        falcon_lines(),
        title="DMT",
        subtitle="دائرة البلديات والنقل",
        status="dmt-demo-9585 · auth admin@evoost-ai.ae",
    )
    text = buf.getvalue()
    assert "╭" in text and "╯" in text  # rounded panel frame
    assert "██████" in text  # monogram inside the box
    assert "dmt-demo-9585" in text  # status strip on the frame


@pytest.mark.skipif(not render._HAS_RICH, reason="rich extra not installed")
def test_rich_table_stacks_on_narrow_terminals_without_truncation():
    """Below the grid threshold the roster renders as stacked blocks: full ids,
    full descriptions wrapped at word boundaries, zero ellipsis anywhere."""
    from rich.console import Console

    out = io.StringIO()
    renderer = render.RichRenderer(color=True, out=out)
    renderer._console = Console(file=out, width=80)  # too narrow for the grid
    desc = "Business-domain expert on sustainability, livability and ESG posture."
    renderer.table(
        ["agent", "kind", "lens", "description"],
        [["sustainability-livability-esg-estidama-expert", "expert", "sovereign", desc]],
    )
    text = out.getvalue()
    assert "…" not in text
    assert "sustainability-livability-esg-estidama-expert" in text
    for word in desc.split():
        assert word in text  # every word survives the fold


@pytest.mark.skipif(not render._HAS_RICH, reason="rich extra not installed")
def test_rich_table_grid_keeps_full_description_on_wide_terminals():
    """On a wide terminal the grid renders the full description — wrapped at
    word boundaries, never ellipsized, never split mid-word."""
    from rich.console import Console

    out = io.StringIO()
    renderer = render.RichRenderer(color=True, out=out)
    renderer._console = Console(file=out, width=160)
    desc = (
        "Business-domain expert who defines the international-geopolitics "
        "scoring dimension for the DMT platform."
    )
    renderer.table(
        ["agent", "kind", "lens", "description"],
        [["geopolitical-risk-international-relations-analyst", "expert", "both", desc]],
    )
    text = " ".join(out.getvalue().splitlines())
    assert "…" not in text
    for word in desc.split():
        assert word in text
