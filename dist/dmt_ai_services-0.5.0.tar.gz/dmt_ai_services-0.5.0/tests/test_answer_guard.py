"""Tests for the deterministic post-generation answer guard.

The guard abstains instead of publishing a bad reader reply (wrong language or a
substance-free fragment) — the failure modes the SME re-certification surfaced
(g032 "R 38", g042/g043/g113 wrong-language). Pure stdlib, no model needed.
"""

from __future__ import annotations

import pytest

import ml.eval.build_answer_sheet as bas


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        # Substance floor — a bare code or a couple of words is not an answer.
        ("R 38", False),
        ("R **38**", False),
        ("yes", False),
        ("", False),
        # Real content passes.
        (
            "The Pearl Community Rating System requires the following credits for a design rating submission.",
            True,
        ),
    ],
)
def test_substance_floor(text: str, expected: bool) -> None:
    assert bas._passes_answer_guard(text, "en") is expected


@pytest.mark.parametrize(
    ("text", "lang", "expected"),
    [
        # English question answered in Arabic -> abstain (g042/g043).
        ("يعالج عقد الإيجار طويل الأجل وديعة التأمين الخاصة بأعمال المستثمر", "en", False),
        # English question, English answer -> pass.
        ("The long-term lease template retains the works security deposit.", "en", True),
        # Arabic question, Arabic answer -> pass.
        ("الضوابط الخمسة للحوكمة هي: الحتمية، والامتناع عن الاختراع، وتقليل البيانات", "ar", True),
        # Arabic question, English answer -> abstain.
        ("The five governance invariants are determinism and abstention.", "ar", False),
    ],
)
def test_language_alignment(text: str, lang: str, expected: bool) -> None:
    assert bas._passes_answer_guard(text, lang) is expected


def test_arabic_ratio_bounds() -> None:
    assert bas._arabic_ratio("hello world") == 0.0
    assert bas._arabic_ratio("مرحبا بالعالم") == 1.0
    assert bas._arabic_ratio("no letters 123") == 0.0
