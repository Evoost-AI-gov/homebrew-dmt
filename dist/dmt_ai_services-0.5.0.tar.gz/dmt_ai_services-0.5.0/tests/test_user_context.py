"""Tests for the per-user work-context store and routes."""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.council.user_context import UserContextStore


class TestUserContextStore:
    def test_default_context_for_new_user(self, tmp_path) -> None:
        store = UserContextStore(tmp_path / "ctx.json")
        ctx = store.get("user:1")
        assert ctx["role"] == ""
        assert ctx["pinned"] == []

    def test_upsert_merges_and_timestamps(self, tmp_path) -> None:
        store = UserContextStore(tmp_path / "ctx.json")
        store.upsert("user:1", {"role": "Urban Planner", "goal": "Mussafah"})
        store.upsert("user:1", {"module": "scenarios"})
        ctx = store.get("user:1")
        assert ctx["role"] == "Urban Planner"
        assert ctx["module"] == "scenarios"
        assert ctx["updated_at"] != ""

    def test_users_are_isolated(self, tmp_path) -> None:
        store = UserContextStore(tmp_path / "ctx.json")
        store.upsert("user:1", {"role": "Planner"})
        store.upsert("user:2", {"role": "Investor"})
        assert store.get("user:1")["role"] == "Planner"
        assert store.get("user:2")["role"] == "Investor"

    def test_activity_appends_and_caps(self, tmp_path) -> None:
        store = UserContextStore(tmp_path / "ctx.json")
        for i in range(60):
            store.record_activity("user:1", "viewed", f"Parcel {i}", ref=f"P-{i}", module="parcels")
        ctx = store.get("user:1")
        assert len(ctx["activity"]) == 50  # capped (data minimisation)
        assert ctx["module"] == "parcels"

    def test_persistence_across_instances(self, tmp_path) -> None:
        store = UserContextStore(tmp_path / "ctx.json")
        store.upsert("user:1", {"role": "Planner"})
        store2 = UserContextStore(tmp_path / "ctx.json")
        assert store2.get("user:1")["role"] == "Planner"


class TestUserContextRoutes:
    def _app(self, tmp_path) -> FastAPI:
        from app.council.user_context_routes import router
        from app.errors import AppError, app_error_handler

        app = FastAPI()
        app.state.user_context_store = UserContextStore(tmp_path / "ctx.json")
        app.add_exception_handler(AppError, app_error_handler)
        app.include_router(router, prefix="/v1")
        return app

    def test_context_not_configured_returns_400(self) -> None:
        from app.council.user_context_routes import router
        from app.errors import AppError, app_error_handler

        app = FastAPI()
        app.state.user_context_store = None
        app.add_exception_handler(AppError, app_error_handler)
        app.include_router(router, prefix="/v1")
        assert TestClient(app).get("/v1/me/context").status_code == 400

    def test_get_put_activity_roundtrip(self, tmp_path) -> None:
        client = TestClient(self._app(tmp_path))
        assert client.get("/v1/me/context").status_code == 200
        r = client.put("/v1/me/context", json={"role": "Investor", "module": "demand"})
        assert r.status_code == 200
        assert r.json()["role"] == "Investor"
        r2 = client.post(
            "/v1/me/context/activity",
            json={"kind": "viewed", "label": "Mussafah", "ref": "M-1", "module": "map"},
        )
        assert r2.status_code == 200
        assert r2.json()["activity"][-1]["label"] == "Mussafah"

    def test_not_mounted_when_no_store(self) -> None:
        # The store is only constructed when user_context_path is set; with an
        # empty path the settings default holds and /v1/me is not mounted.
        from app.settings import Settings

        assert Settings().user_context_path == ""
