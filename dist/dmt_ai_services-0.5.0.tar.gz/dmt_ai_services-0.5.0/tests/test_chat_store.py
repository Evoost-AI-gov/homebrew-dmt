"""Tests for the council chat-persistence store + endpoints."""

from __future__ import annotations

from fastapi.testclient import TestClient

from app.council.chat_store import ChatStore
from app.main import create_app
from app.settings import Settings

AUTH = {"X-API-Key": "test-key"}


def _client(tmp_path) -> TestClient:  # noqa: ANN001
    settings = Settings(
        _env_file=None,
        app_env="development",
        api_keys="test-key",
        allow_unauthenticated=False,
        chat_store_path=str(tmp_path / "chats.json"),
    )
    return TestClient(create_app(settings=settings))


# --- Store (unit) --------------------------------------------------------------


def test_conversation_upsert_and_list(tmp_path) -> None:  # noqa: ANN001
    store = ChatStore(tmp_path / "chats.json")
    store.upsert_conversation(
        "c1", title="First", messages=[{"id": "m1", "role": "user", "content": "hi"}]
    )
    store.upsert_conversation("c2", title="Second", messages=[])
    rows = store.list_conversations()
    assert {r["id"] for r in rows} == {"c1", "c2"}


def test_conversation_delete(tmp_path) -> None:  # noqa: ANN001
    store = ChatStore(tmp_path / "chats.json")
    store.upsert_conversation("c1", title="X", messages=[])
    assert store.delete_conversation("c1") is True
    assert store.delete_conversation("c1") is False


def test_project_lifecycle_and_unassign(tmp_path) -> None:  # noqa: ANN001
    store = ChatStore(tmp_path / "chats.json")
    proj = store.create_project("Mussafah")
    store.upsert_conversation("c1", title="X", messages=[], project_id=proj["id"])
    renamed = store.rename_project(proj["id"], "Mussafah PoC")
    assert renamed["name"] == "Mussafah PoC"
    assert store.delete_project(proj["id"]) is True
    # Conversations in the deleted project are unassigned, not deleted.
    assert store.list_conversations()[0]["project_id"] is None


def test_store_fail_closed_on_corrupt(tmp_path) -> None:  # noqa: ANN001
    path = tmp_path / "chats.json"
    path.write_text("not json", encoding="utf-8")
    store = ChatStore(path)
    assert store.list_conversations() == []


# --- Endpoints -------------------------------------------------------------------


def test_chats_roundtrip_via_http(tmp_path) -> None:  # noqa: ANN001
    client = _client(tmp_path)
    # Empty at first.
    assert client.get("/v1/chats", headers=AUTH).json() == []
    # Upsert a conversation.
    put = client.put(
        "/v1/chats/conv-1",
        headers=AUTH,
        json={"title": "Persist", "messages": [{"id": "m1", "role": "user", "content": "hi"}]},
    )
    assert put.status_code == 200
    assert put.json()["id"] == "conv-1"
    # It persisted.
    rows = client.get("/v1/chats", headers=AUTH).json()
    assert [r["title"] for r in rows] == ["Persist"]
    # Projects.
    proj = client.post("/v1/chats/projects", headers=AUTH, json={"name": "PoC"}).json()
    assert proj["name"] == "PoC"
    assert client.get("/v1/chats/projects", headers=AUTH).json()[0]["id"] == proj["id"]


def test_chats_disabled_without_store() -> None:
    settings = Settings(
        _env_file=None,
        app_env="development",
        api_keys="test-key",
        allow_unauthenticated=False,
    )
    client = TestClient(create_app(settings=settings))
    # Router not mounted -> 404 (the frontend then uses its local fallback).
    assert client.get("/v1/chats", headers=AUTH).status_code == 404


def test_chats_require_auth(tmp_path) -> None:  # noqa: ANN001
    client = _client(tmp_path)
    assert client.get("/v1/chats").status_code == 401


def test_concurrent_upserts_do_not_corrupt(tmp_path) -> None:  # noqa: ANN001
    """Concurrent PUTs (the council serves parallel requests) must never race."""
    import concurrent.futures

    store = ChatStore(tmp_path / "chats.json")

    def write(i: int) -> None:
        store.upsert_conversation(
            f"conv-{i}", title=f"T{i}", messages=[{"id": f"m{i}", "role": "user", "content": "x"}]
        )

    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(write, range(20)))
    assert len(store.list_conversations()) == 20  # all 20 survived, no lost writes
