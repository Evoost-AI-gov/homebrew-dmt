"""Per-expert answer-quality eval — the golden cases proving each expert is decision-grade.

Deterministic and offline (fake provider + governed grounding doubles, no network, no
model): every business-council expert runs its REAL turn and the answer is scored on the
government-grade bar — grounded & sourced, on-domain signals present, confidence correctly
calibrated to the weakest evidence, no invented figures, and the lens honoured in its voice.
A regression here fails the gate: this is the evidence that each expert is not just routed
correctly but answers to a quality standard.
"""

from __future__ import annotations

import pytest
from tests.expert_quality_data import EXPERT_CASES, ExpertCase, expected_confidence

from app.council.registry import CouncilRegistry
from app.council.schemas import CouncilChatMessage, CouncilChatRequest
from app.council.service import CouncilService
from app.inference import InferenceService
from app.routing import Router
from app.schemas import (
    ChatChoice,
    ChatChoiceMessage,
    ChatCompletionRequest,
    ChatCompletionResponse,
    Citation,
    Usage,
)


def _agent_md(case: ExpertCase) -> str:
    return (
        f'---\nname: {case.expert_name}\ndescription: "Expert persona."\n'
        f"tools: [read, search, execute]\n---\n\n# {case.expert_name}\n\n"
        f"You are the expert. Ground every claim in the cited evidence.\n"
    )


_DIRECTOR_MD = (
    '---\nname: Director (Program Orchestrator)\ndescription: "Synthesizes the council."\n'
    "tools: [read, search, agent]\n---\n\n# Director\n\nYou synthesize.\n"
)


class _ScriptedProvider:
    """Returns the scripted expert reply; records the request (for grounding checks)."""

    def __init__(self, reply: str) -> None:
        self.requests: list[ChatCompletionRequest] = []
        self._reply = reply

    async def chat(self, request: ChatCompletionRequest, model: str) -> ChatCompletionResponse:
        self.requests.append(request)
        return ChatCompletionResponse(
            id="chatcmpl-quality",
            model=model,
            choices=[
                ChatChoice(
                    index=0,
                    message=ChatChoiceMessage(role="assistant", content=self._reply),
                    finish_reason="stop",
                )
            ],
            usage=Usage(prompt_tokens=1, completion_tokens=1, total_tokens=2),
        )

    async def embeddings(self, request, model):  # noqa: ANN001, ANN202 - test double
        raise NotImplementedError


class _GroundedRetrieval:
    """Governed retrieval double: returns the case's citations (tier-aware)."""

    configured = True

    def __init__(self, citations: list[Citation]) -> None:
        self._citations = citations

    async def retrieve(self, query: str, **_kwargs) -> list[Citation]:  # noqa: ANN001, ANN202
        return list(self._citations)


def _citation(canonical_file: str, tier: str, score: float) -> Citation:
    return Citation(
        chunk_id=f"c-{canonical_file}-{score}",
        canonical_file=canonical_file,
        domain="dmt",
        tier=tier,  # type: ignore[arg-type]
        score=score,
        text=f"Governed evidence from {canonical_file}.",
    )


def _run_case(tmp_path, case: ExpertCase):  # noqa: ANN001
    (tmp_path / "director.agent.md").write_text(_DIRECTOR_MD, encoding="utf-8")
    (tmp_path / f"{case.expert_id}.agent.md").write_text(_agent_md(case), encoding="utf-8")
    registry = CouncilRegistry.from_directory(tmp_path)
    assert registry.get(case.expert_id) is not None, f"persona id mismatch for {case.expert_id}"
    provider = _ScriptedProvider(case.reply)
    service = CouncilService(
        registry=registry,
        inference=InferenceService(provider, Router()),
        retrieval=_GroundedRetrieval(
            [_citation(name, tier, score) for name, tier, score in case.citations]
        ),
        require_grounding=True,
    )
    request = CouncilChatRequest(
        agents=[case.expert_id],
        messages=[CouncilChatMessage(role="user", content=case.query)],
        stream=False,
        delegate=True,
    )
    return service, provider, request


@pytest.mark.asyncio
@pytest.mark.parametrize("case", EXPERT_CASES, ids=lambda c: c.expert_id)
async def test_expert_answer_is_decision_grade(tmp_path, case: ExpertCase) -> None:  # noqa: ANN001
    service, provider, request = _run_case(tmp_path, case)
    out = await service.run_turn(request)

    # The expert actually spoke (grounded, not abstained).
    message = out.messages[0]
    assert message.agent_id == case.expert_id
    assert not message.abstained, f"{case.expert_id} abstained on a grounded golden case"

    # Grounded: evidence was cited and reached the model context.
    assert message.sources, "answer carries no source citations"
    files = [name for name, _tier, _score in case.citations]
    assert any(
        any(t.role == "user" and any(name in t.content for name in files) for t in req.messages)
        for req in provider.requests
    ), "governed evidence was not injected into the model context"

    # On-domain: the answer speaks the domain language of the query.
    lowered = message.content.lower()
    for signal in case.domain_signals:
        assert signal.lower() in lowered, f"missing domain signal {signal!r}"

    # Confidence calibrated: inherits the weakest citation (never more certain than evidence).
    assert message.confidence == expected_confidence(case.weak_score)

    # No invented figures.
    for bad in case.invented:
        assert bad.lower() not in lowered, f"invented/ungrounded figure {bad!r} slipped in"


def test_every_business_expert_has_a_quality_case() -> None:
    # The golden set must cover the council — an expert with no case is unmeasured.
    ids = {c.expert_id for c in EXPERT_CASES}
    assert len(ids) == len(EXPERT_CASES), "duplicate expert ids in the golden set"
