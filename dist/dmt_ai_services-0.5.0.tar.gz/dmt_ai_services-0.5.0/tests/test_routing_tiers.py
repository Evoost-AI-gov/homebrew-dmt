"""Tests for the fast expert-tier model routing (council latency lever)."""

from __future__ import annotations

import pytest

from app.inference import InferenceService
from app.main import _build_routes
from app.routing import Router
from app.schemas import (
    ChatChoice,
    ChatChoiceMessage,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatMessage,
)
from app.settings import Settings


class _RecordingProvider:
    """A provider that records the deployment name it was asked to serve."""

    def __init__(self) -> None:
        self.models: list[str] = []

    async def chat(self, request: ChatCompletionRequest, model: str) -> ChatCompletionResponse:
        self.models.append(model)
        return ChatCompletionResponse(
            id="x",
            model=model,
            choices=[
                ChatChoice(
                    index=0,
                    message=ChatChoiceMessage(role="assistant", content="ok"),
                    finish_reason="stop",
                )
            ],
        )


def test_expert_role_prefers_the_fast_tier_with_strong_fallback() -> None:
    router = Router(
        routes={
            "dmt-brain": ["dmt-brain"],
            "general": ["fast-mini", "dmt-brain"],
            "fast": ["fast-mini", "dmt-brain"],
            "embed": ["dmt-embed"],
        }
    )
    # Experts (and gates) answer on the fast model; the Director keeps the strong one.
    assert router.resolve_for_role("expert") == ["fast-mini", "dmt-brain"]
    assert router.resolve_for_role("gate") == ["fast-mini", "dmt-brain"]
    assert router.resolve_for_role("director") == ["dmt-brain"]


def _settings(**over: object) -> Settings:
    return Settings(
        _env_file=None,
        app_env="development",
        api_keys="test-key",
        allow_unauthenticated=False,
        **over,
    )


def test_build_routes_wires_the_expert_tier_when_configured() -> None:
    routes = _build_routes(_settings(chat_model="dmt-brain", expert_chat_model="gpt-4o-mini"))
    assert routes["general"] == ["gpt-4o-mini", "dmt-brain"]
    assert routes["fast"] == ["gpt-4o-mini", "dmt-brain"]
    # The Director's tier is unchanged (strong reasoning model).
    assert routes["dmt-brain"] == ["dmt-brain"]


def test_build_routes_falls_back_to_the_single_model_when_unset() -> None:
    routes = _build_routes(_settings(chat_model="dmt-brain"))
    assert routes["general"] == ["dmt-brain"]
    assert routes["fast"] == ["dmt-brain"]


@pytest.mark.asyncio
async def test_unary_chat_routes_experts_to_the_fast_tier_by_role() -> None:
    # This anchors the latency fix: the non-streaming (delegate) composition must
    # route experts by role to the fast tier, not to the request's logical model.
    router = Router(routes={"dmt-brain": ["dmt-brain"], "general": ["fast-mini", "dmt-brain"]})
    provider = _RecordingProvider()
    service = InferenceService(provider, router)
    request = ChatCompletionRequest(
        model="dmt-brain", messages=[ChatMessage(role="user", content="hi")]
    )

    await service.chat(request, role="expert")
    await service.chat(request, role="director")
    await service.chat(request)  # no role -> resolves the request's logical model

    assert provider.models == ["fast-mini", "dmt-brain", "dmt-brain"]
