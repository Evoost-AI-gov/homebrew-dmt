"""Tests for the deterministic council graph (the visual 'who connected and why')."""

from __future__ import annotations

from app.council.graph import build_council_graph
from app.council.schemas import CouncilChatResponse, CouncilMessage, TurnMeta


def _msg(agent: str, sources: list[str], reply_to: list[str] | None = None) -> CouncilMessage:
    return CouncilMessage(
        agent_id=agent,
        content="...",
        sources=sources,
        confidence="medium",
        abstained=False,
        reply_to=reply_to or [],
    )


def _response(
    messages: list[CouncilMessage], synthesis: CouncilMessage | None
) -> CouncilChatResponse:
    return CouncilChatResponse(
        id="council-t1",
        conversation_id=None,
        model="dmt-brain",
        messages=messages,
        synthesis=synthesis,
        meta=TurnMeta(participants=[m.agent_id for m in messages], rounds=2),
    )


def test_grounding_creates_agent_to_source_edges() -> None:
    graph = build_council_graph(_response([_msg("valuation", ["rate_table.json"])], None))
    kinds = {(e["source"], e["target"], e["kind"]) for e in graph["edges"]}
    assert ("valuation", "rate_table.json", "cites") in kinds
    # Source appears as a node.
    assert any(n["id"] == "rate_table.json" and n["kind"] == "source" for n in graph["nodes"])


def test_co_citation_links_experts_sharing_a_source() -> None:
    graph = build_council_graph(
        _response(
            [_msg("valuation", ["rate_table.json"]), _msg("investment", ["rate_table.json"])],
            None,
        )
    )
    kinds = {(e["source"], e["target"], e["kind"], e["why"]) for e in graph["edges"]}
    # co_citation is an undirected link emitted once (alphabetical order).
    assert any(
        {s, t} == {"valuation", "investment"} and k == "co_cited" and "rate_table.json" in w
        for s, t, k, w in kinds
    )


def test_deliberation_and_synthesis_edges() -> None:
    synth = _msg("director-program-orchestrator", [])
    graph = build_council_graph(
        _response([_msg("valuation", ["a.md"]), _msg("investment", [], ["valuation"])], synth)
    )
    kinds = {(e["source"], e["target"], e["kind"]) for e in graph["edges"]}
    assert ("investment", "valuation", "deliberates") in kinds
    assert ("director-program-orchestrator", "valuation", "synthesizes") in kinds
    assert ("director-program-orchestrator", "investment", "synthesizes") in kinds
    # Director is a distinct node kind.
    assert any(
        n["id"] == "director-program-orchestrator" and n["kind"] == "director"
        for n in graph["nodes"]
    )


def test_empty_turn_has_no_edges() -> None:
    graph = build_council_graph(_response([], None))
    assert graph["edges"] == []
    assert graph["meta"]["node_count"] == 0


def test_deterministic_and_deduplicated() -> None:
    resp = _response(
        [_msg("valuation", ["a.md"]), _msg("valuation", ["a.md"]), _msg("investment", ["a.md"])],
        None,
    )
    first = build_council_graph(resp)
    second = build_council_graph(resp)
    assert first == second  # pure function, no nondeterminism
    # The duplicate valuation->a.md citation is not duplicated as an edge.
    cites = [e for e in first["edges"] if e["kind"] == "cites" and e["source"] == "valuation"]
    assert len(cites) == 1


def test_labels_use_display_names() -> None:
    graph = build_council_graph(
        _response([_msg("valuation", ["a.md"])], None),
        agent_names={"valuation": "Real Estate Valuation Expert"},
    )
    node = next(n for n in graph["nodes"] if n["id"] == "valuation")
    assert node["label"] == "Real Estate Valuation Expert"
