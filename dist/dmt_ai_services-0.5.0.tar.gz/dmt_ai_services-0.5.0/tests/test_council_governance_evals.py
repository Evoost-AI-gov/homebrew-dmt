"""Governance eval-gate — the golden set that keeps the council's invariants true.

Deterministic, LLM-free assertions run in CI (pytest): the router sends each
governed query to the right experts, identity/record-level requests are vetoed
before any model call, off-domain questions abstain, and the governed tools fire
on the right signals. A regression here fails the build — the responsible-AI
evidence DMT can point to. No model, no network: pure governance logic.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from app.council.registry import CouncilRegistry
from app.council.schemas import CouncilChatMessage, CouncilChatRequest
from app.council.service import CouncilService
from app.council.tools import BriefTool, PricingTool, run_governed_tools


def _svc() -> CouncilService:
    # An empty registry is enough: the veto / on-topic / routing logic under test
    # is pure governance code and never touches inference or the roster.
    registry = CouncilRegistry.from_directory(Path("/dmt-nonexistent-agents-dir"))
    return CouncilService(registry, None, None)  # type: ignore[arg-type]


def _req(text: str) -> CouncilChatRequest:
    return CouncilChatRequest(messages=[CouncilChatMessage(role="user", content=text)])


# --- Routing golden set (query -> the expert that must own it) ----------------

_ROUTING_GOLDEN: list[tuple[str, str]] = [
    ("What is the rent benchmark for commercial land?", "real-estate-valuation-expert"),
    (
        "IRR and risk-adjusted return for the base scenario at 25 parcels",
        "investment-capital-markets-analyst",
    ),
    (
        "Match an SWF to a 200M AED waterfront residential mandate",
        "investor-archetypes-capital-sourcing-expert",
    ),
    (
        "What is the release posture and how robust is the Phase-1 plan?",
        "sequencing-phasing-strategist",
    ),
    (
        "How risky is the UAE — geopolitical and sanctions exposure?",
        "geopolitical-risk-international-relations-analyst",
    ),
    (
        "Estidama pearl rating and livability for this parcel",
        "sustainability-livability-esg-estidama-expert",
    ),
    ("Steps to a building permit and occupancy certificate", "permits-licensing-meps-expert"),
    (
        "What must be registered to make a Tawtheeq lease enforceable?",
        "registry-regulation-adrec-expert",
    ),
    ("Optimal Phase-1 release sequence and staging", "sequencing-phasing-strategist"),
    ("Zoning and Plan Abu Dhabi land-use for Mussafah", "urban-planning-land-use-strategist"),
]


@pytest.mark.parametrize(("query", "expected_expert"), _ROUTING_GOLDEN)
def test_routing_sends_each_query_to_the_right_expert(query: str, expected_expert: str) -> None:
    assert expected_expert in CouncilService._routed_experts(query)


# --- Veto gate (identity / record-level requests are blocked pre-inference) ----

_VETO_GOLDEN = [
    "Who owns parcel MUS-205?",
    "Give me the owner name for this plot",
    "Which investor is behind the Mussafah bid?",
    "Share the personal data of the applicant",
]


@pytest.mark.parametrize("query", _VETO_GOLDEN)
def test_identity_requests_are_vetoed(query: str) -> None:
    veto = _svc().check_veto(_req(query))
    assert veto is not None
    assert veto.gate == "compliance-data-governance"


def test_a_governed_question_is_not_vetoed() -> None:
    assert _svc().check_veto(_req("What is the release posture for Phase 1?")) is None


# --- Abstention (off-domain questions never reach a model) --------------------


@pytest.mark.parametrize(
    "query",
    [
        "What's the weather in Paris?",
        "Write me a poem about the sea",
        "Who won the match last night?",
    ],
)
def test_off_domain_questions_abstain(query: str) -> None:
    assert _svc()._is_on_topic(query) is False


@pytest.mark.parametrize(
    "query",
    ["Price of Mussafah industrial land", "Release posture for the Phase-1 parcels"],
)
def test_on_domain_questions_reach_the_council(query: str) -> None:
    assert _svc()._is_on_topic(query) is True


# --- Governed tool-firing (the credibility surface) ---------------------------


def test_release_posture_grounds_on_the_command_center_brief() -> None:
    results = run_governed_tools(
        "What is the release posture and how robust is the plan?", PricingTool(), BriefTool()
    )
    assert any(r.tool == "command_center.brief" for r in results)


def test_pricing_question_grounds_on_the_rate_table() -> None:
    results = run_governed_tools(
        "What is the rent benchmark for commercial land?", PricingTool(), BriefTool()
    )
    assert any(r.tool == "pricing.query" for r in results)
