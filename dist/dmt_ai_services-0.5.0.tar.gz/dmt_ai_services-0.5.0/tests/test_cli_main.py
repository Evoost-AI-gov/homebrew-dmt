"""Entry-point argument handling — flags must work before AND after the
subcommand (the claude/codex ordering users expect)."""

from app.cli.main import _parser


def test_global_flags_after_subcommand():
    args = _parser().parse_args(
        ["ask", "rent?", "--no-color", "--no-transcript", "--delegate", "--effort", "high"]
    )
    assert args.command == "ask"
    assert args.no_color is True
    assert args.no_transcript is True
    assert args.delegate is True
    assert args.effort == "high"


def test_global_flags_before_subcommand_still_apply():
    args = _parser().parse_args(["--no-color", "chat"])
    assert args.command == "chat"
    assert args.no_color is True


def test_defaults_are_repl():
    args = _parser().parse_args([])
    assert args.command is None  # bare `dmt` -> interactive REPL
    assert args.no_color is False


def test_auth_subcommands():
    assert _parser().parse_args(["auth", "login"]).auth_command == "login"
    assert _parser().parse_args(["auth", "login", "--device-code"]).device_code is True
    assert _parser().parse_args(["auth", "status"]).auth_command == "status"
    assert _parser().parse_args(["auth", "logout"]).auth_command == "logout"


def test_ask_joins_question_words():
    args = _parser().parse_args(["ask", "what", "is", "the", "rate?"])
    assert args.question == ["what", "is", "the", "rate?"]
