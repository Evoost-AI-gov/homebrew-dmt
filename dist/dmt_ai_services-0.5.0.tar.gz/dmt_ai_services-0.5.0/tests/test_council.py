"""Tests for the Council Chat runtime (ADR-0003, F1)."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from app.council.persona import compile_persona
from app.council.registry import CouncilRegistry
from app.council.schemas import CouncilChatMessage, CouncilChatRequest
from app.council.service import CouncilService
from app.main import create_app
from app.providers import NullProvider
from app.schemas import (
    ChatChoice,
    ChatChoiceMessage,
    ChatCompletionRequest,
    ChatCompletionResponse,
    Citation,
    Usage,
)
from app.settings import Settings

AUTH = {"X-API-Key": "test-key"}

_DIRECTOR_MD = """---
name: Director (Program Orchestrator)
description: "Top-level orchestrator. Routes across the council and synthesizes."
tools: [read, search, agent]
---

# Director — Program Orchestrator

You are the Director. You frame, route, and synthesize into a decision-grade answer.
"""

_VALUATION_MD = """---
name: Real Estate Valuation Expert
description: "Valuation authority. Grounds every price in evidence."
tools: [read, search, execute]
---

# Real Estate Valuation Expert

You are the valuation authority. Ground every price in `rate_table.json` and the
pricing service; below the 3-deal disclosure floor, abstain.
"""


class FakeProvider:
    """Records the request it received and returns a canned answer."""

    def __init__(self, content: str = "A grounded valuation answer.") -> None:
        self.requests: list[ChatCompletionRequest] = []
        self._content = content

    async def chat(self, request: ChatCompletionRequest, model: str) -> ChatCompletionResponse:
        self.requests.append(request)
        return ChatCompletionResponse(
            id="chatcmpl-test",
            model=model,
            choices=[
                ChatChoice(
                    index=0,
                    message=ChatChoiceMessage(role="assistant", content=self._content),
                    finish_reason="stop",
                )
            ],
            usage=Usage(prompt_tokens=1, completion_tokens=1, total_tokens=2),
        )

    async def embeddings(self, request, model):  # noqa: ANN001, ANN202 - test double
        raise NotImplementedError


def _write_agents(dir_path) -> None:  # noqa: ANN001 - pytest tmp_path
    (dir_path / "director.agent.md").write_text(_DIRECTOR_MD, encoding="utf-8")
    (dir_path / "biz-valuation-expert.agent.md").write_text(_VALUATION_MD, encoding="utf-8")


def _client(tmp_path, provider=None, **overrides) -> TestClient:  # noqa: ANN001
    _write_agents(tmp_path)
    settings = Settings(
        _env_file=None,
        app_env="development",
        api_keys="test-key",
        allow_unauthenticated=False,
        council_agents_dir=str(tmp_path),
        **overrides,
    )
    app = create_app(settings=settings, provider=provider or FakeProvider())
    return TestClient(app)


# --- Persona compiler -------------------------------------------------------


def test_compile_persona_identity_and_tools() -> None:
    agent = compile_persona(_VALUATION_MD, source_path="biz-valuation-expert.agent.md")
    assert agent.agent_id == "real-estate-valuation-expert"
    assert agent.display_name == "Real Estate Valuation Expert"
    assert agent.kind == "expert"
    assert "retrieval.query" in agent.tool_grants
    assert "pricing.query" in agent.tool_grants  # inferred from rate_table/pricing hints


def test_compile_persona_infers_director_kind() -> None:
    agent = compile_persona(_DIRECTOR_MD, source_path="director.agent.md")
    assert agent.kind == "director"
    assert agent.model_tier == "director"


def test_compile_persona_rejects_tool_outside_allowlist() -> None:
    with pytest.raises(ValueError, match="allow-list"):
        compile_persona(_VALUATION_MD, tool_grants=("shell.exec",))


def test_system_prompt_carries_governance_rules() -> None:
    agent = compile_persona(_VALUATION_MD, source_path="biz-valuation-expert.agent.md")
    prompt = agent.compose_system_prompt()
    assert "advisory" in prompt
    assert "abstain" in prompt.lower()


# --- Registry ---------------------------------------------------------------


def test_registry_empty_when_dir_missing(tmp_path) -> None:  # noqa: ANN001
    registry = CouncilRegistry.from_directory(tmp_path / "nope")
    assert not registry.configured
    assert registry.list() == []


def test_registry_loads_and_orders(tmp_path) -> None:  # noqa: ANN001
    _write_agents(tmp_path)
    registry = CouncilRegistry.from_directory(tmp_path)
    assert registry.configured
    roster = registry.list()
    assert roster[0].kind == "director"  # Director first
    assert registry.director() is not None
    assert registry.get("real-estate-valuation-expert") is not None


# --- HTTP surface -----------------------------------------------------------


def test_roster_endpoint_lists_agents(tmp_path) -> None:  # noqa: ANN001
    client = _client(tmp_path)
    resp = client.get("/v1/council/agents", headers=AUTH)
    assert resp.status_code == 200
    ids = [a["agent_id"] for a in resp.json()["data"]]
    assert "real-estate-valuation-expert" in ids
    assert "director-program-orchestrator" in ids


def test_roster_requires_auth(tmp_path) -> None:  # noqa: ANN001
    client = _client(tmp_path)
    assert client.get("/v1/council/agents").status_code == 401


def test_council_chat_unary_routes_to_expert(tmp_path) -> None:  # noqa: ANN001
    provider = FakeProvider()
    client = _client(tmp_path, provider=provider)
    resp = client.post(
        "/v1/council/chat",
        headers=AUTH,
        json={
            "agents": ["real-estate-valuation-expert"],
            "messages": [{"role": "user", "content": "What is the pricing disclosure floor?"}],
            "stream": False,
        },
    )
    assert resp.status_code == 200
    body = resp.json()
    # A requested expert always answers; with no routing keyword it is a
    # single-expert fan-out, and the Director still synthesizes the council reply.
    assert body["messages"][0]["agent_id"] == "real-estate-valuation-expert"
    assert body["synthesis"]["agent_id"] == "director-program-orchestrator"
    # The expert persona was sent as the system prompt of its own call.
    assert provider.requests[0].messages[0].role == "system"
    assert "valuation authority" in provider.requests[0].messages[0].content.lower()


def test_council_chat_defaults_to_director(tmp_path) -> None:  # noqa: ANN001
    client = _client(tmp_path)
    resp = client.post(
        "/v1/council/chat",
        headers=AUTH,
        json={
            "messages": [{"role": "user", "content": "Hello, what is the price?"}],
            "stream": False,
        },
    )
    assert resp.json()["messages"][0]["agent_id"] == "director-program-orchestrator"


def test_council_chat_unknown_agent_falls_back_to_director(tmp_path) -> None:  # noqa: ANN001
    client = _client(tmp_path)
    resp = client.post(
        "/v1/council/chat",
        headers=AUTH,
        json={
            "agents": ["not-a-real-agent"],
            "messages": [{"role": "user", "content": "Hi, what is the price?"}],
            "stream": False,
        },
    )
    assert resp.json()["messages"][0]["agent_id"] == "director-program-orchestrator"


def test_council_chat_streams_sse(tmp_path) -> None:  # noqa: ANN001
    client = _client(tmp_path)
    with client.stream(
        "POST",
        "/v1/council/chat",
        headers=AUTH,
        json={"messages": [{"role": "user", "content": "Hi, what is the price?"}], "stream": True},
    ) as resp:
        assert resp.status_code == 200
        assert resp.headers["content-type"].startswith("text/event-stream")
        raw = "".join(resp.iter_text())
    assert "event: agent_started" in raw
    assert "event: token" in raw
    assert "event: message_done" in raw


def test_council_chat_unconfigured_registry_400(tmp_path) -> None:  # noqa: ANN001
    # No agents written -> empty registry -> fail-closed 400.
    settings = Settings(
        _env_file=None,
        app_env="development",
        api_keys="test-key",
        allow_unauthenticated=False,
        council_agents_dir=str(tmp_path / "empty"),
    )
    client = TestClient(create_app(settings=settings, provider=FakeProvider()))
    resp = client.post(
        "/v1/council/chat",
        headers=AUTH,
        json={"messages": [{"role": "user", "content": "Hi, what is the price?"}], "stream": False},
    )
    assert resp.status_code == 400


def test_council_chat_fail_closed_without_upstream(tmp_path) -> None:  # noqa: ANN001
    # Retrieval off + no upstream -> the provider raises a clear 503.
    client = _client(tmp_path, provider=NullProvider())
    resp = client.post(
        "/v1/council/chat",
        headers=AUTH,
        json={"messages": [{"role": "user", "content": "Hi, what is the price?"}], "stream": False},
    )
    assert resp.status_code == 503


# --- Grounding / abstention / confidence (service-level, fake retrieval) -----


class FakeRetrieval:
    """In-memory retrieval double returning a fixed set of citations."""

    configured = True

    def __init__(self, citations: list[Citation]) -> None:
        self._citations = citations

    async def retrieve(self, query: str, **_kwargs) -> list[Citation]:  # noqa: ANN001, ANN202
        return self._citations


def _citation(score: float, name: str = "estidama_pbrs.md", text: str = "evidence") -> Citation:
    return Citation(
        chunk_id=f"c-{score}",
        canonical_file=name,
        domain="sustainability",
        tier="authoritative",
        score=score,
        text=text,
    )


def _service(tmp_path, citations, provider=None) -> CouncilService:  # noqa: ANN001
    _write_agents(tmp_path)
    registry = CouncilRegistry.from_directory(tmp_path)
    from app.inference import InferenceService
    from app.routing import Router

    inference = InferenceService(provider or FakeProvider(), Router())
    return CouncilService(
        registry=registry,
        inference=inference,
        retrieval=FakeRetrieval(citations),
        require_grounding=True,
    )


def _req(agent: str | None = None, query: str = "Tell me about Estidama.") -> CouncilChatRequest:
    return CouncilChatRequest(
        agents=[agent] if agent else [],
        messages=[CouncilChatMessage(role="user", content=query)],
        stream=False,
    )


async def test_grounded_turn_cites_sources_and_confidence(tmp_path) -> None:  # noqa: ANN001 E501
    # Query has no routing keyword -> the requested expert answers alone (single).
    service = _service(tmp_path, [_citation(0.9), _citation(0.6, "plan_ad_2030.md")])
    out = await service.run_turn(
        _req("real-estate-valuation-expert", query="Tell me more about the price.")
    )
    message = out.messages[0]
    assert message.agent_id == "real-estate-valuation-expert"
    assert not message.abstained
    # Confidence inherits the weakest cited input (0.6 -> medium).
    assert message.confidence == "medium"
    assert set(message.sources) == {"estidama_pbrs.md", "plan_ad_2030.md"}


async def test_grounding_gate_abstains_without_evidence(tmp_path) -> None:  # noqa: ANN001
    provider = FakeProvider()
    service = _service(tmp_path, [], provider=provider)
    out = await service.run_turn(_req())
    assert out.messages[0].abstained
    assert out.model == "abstained"
    assert out.messages[0].sources == []
    # The model was never called (hard grounding gate).
    assert provider.requests == []


async def test_confidence_high_and_low_bands(tmp_path) -> None:  # noqa: ANN001
    high = await _service(tmp_path, [_citation(0.95)]).run_turn(_req(query="what is the price"))
    assert high.messages[0].confidence == "high"
    low = await _service(tmp_path, [_citation(0.2)]).run_turn(_req(query="what is the price"))
    assert low.messages[0].confidence == "low"


async def test_grounded_turn_injects_tool_context(tmp_path) -> None:  # noqa: ANN001
    provider = FakeProvider()
    service = _service(tmp_path, [_citation(0.9)], provider=provider)
    await service.run_turn(_req(query="Tell me more about the price, please."))
    request = provider.requests[0]
    # system persona + one tool (evidence) + the user turn, grounding required.
    assert request.messages[0].role == "system"
    assert any(m.role == "tool" for m in request.messages)
    assert request.require_grounding is True


# --- F2: routing, fan-out, synthesis, veto -----------------------------------


def test_route_experts_matches_domain_keyword(tmp_path) -> None:  # noqa: ANN001
    service = _service(tmp_path, [_citation(0.9)])
    # "price" routes to pricing.query, which the valuation expert holds.
    selected = service.route_experts(_req("real-estate-valuation-expert", "What is the price?"))
    assert [a.agent_id for a in selected] == ["real-estate-valuation-expert"]


def test_route_experts_no_roster_returns_empty(tmp_path) -> None:  # noqa: ANN001
    service = _service(tmp_path, [_citation(0.9)])
    assert service.route_experts(_req()) == []  # no active experts -> Director alone


def test_route_experts_delegate_routes_across_full_roster(tmp_path) -> None:  # noqa: ANN001
    # Director-delegation: no explicit roster + delegate=true -> the Director picks
    # the relevant experts itself ("price" -> the valuation expert).
    service = _service(tmp_path, [_citation(0.9)])
    request = CouncilChatRequest(
        agents=[],
        messages=[CouncilChatMessage(role="user", content="What is the price?")],
        delegate=True,
    )
    selected = service.route_experts(request)
    assert "real-estate-valuation-expert" in [a.agent_id for a in selected]


def test_routed_experts_maps_keywords_to_expert_ids() -> None:
    # The deterministic router maps domain keywords to the owning expert ids.
    assert "registry-regulation-adrec-expert" in CouncilService._routed_experts(
        "How do I register a Tawtheeq lease?"
    )
    assert "permits-licensing-meps-expert" in CouncilService._routed_experts(
        "Steps to a building permit and occupancy certificate?"
    )
    assert "real-estate-valuation-expert" in CouncilService._routed_experts(
        "What is the pricing benchmark?"
    )


def test_route_experts_caps_fanout(tmp_path) -> None:  # noqa: ANN001
    # Add a second pricing-capable expert so the roster has two candidates.
    (tmp_path / "biz-investment-analyst.agent.md").write_text(
        _VALUATION_MD.replace("Real Estate Valuation Expert", "Investment Analyst"),
        encoding="utf-8",
    )
    service = _service(tmp_path, [_citation(0.9)])
    selected = service.route_experts(
        _req("real-estate-valuation-expert", "What is the price and value?")
    )
    assert len(selected) <= 3  # cost-governance cap


async def test_fanout_produces_synthesis(tmp_path) -> None:  # noqa: ANN001
    provider = FakeProvider()
    service = _service(tmp_path, [_citation(0.9), _citation(0.4, "weak.md")], provider=provider)
    out = await service.run_turn(_req("real-estate-valuation-expert", "What is the price?"))
    assert out.synthesis is not None
    assert out.synthesis.agent_id == "director-program-orchestrator"
    # Synthesis inherits the weakest confidence (low from the 0.4 citation).
    assert out.synthesis.confidence == "low"
    # Two model calls: the expert turn + the Director synthesis.
    assert len(provider.requests) == 2


async def test_synthesis_suppresses_reasoning_for_low_latency(tmp_path) -> None:  # noqa: ANN001
    # The Director synthesis carries the qwen3 /no_think soft switch so dmt-brain skips
    # chain-of-thought on a pure reconciliation task (measured ~16s -> ~2s). Experts run
    # on the fast tier and must NOT carry it.
    provider = FakeProvider()
    service = _service(tmp_path, [_citation(0.9)], provider=provider)
    await service.run_turn(_req("real-estate-valuation-expert", "What is the price?"))
    synthesis_request = provider.requests[-1]
    assert synthesis_request.messages[-1].content.rstrip().endswith("/no_think")
    expert_request = provider.requests[0]
    assert "/no_think" not in expert_request.messages[-1].content


async def test_stream_fanout_emits_experts_then_synthesis_then_final(tmp_path) -> None:  # noqa: ANN001
    # Progressive delivery: experts stream as they finish, then the Director's synthesis
    # streams live (start -> token(s) -> message), then the assembled response last.
    provider = FakeProvider()
    service = _service(tmp_path, [_citation(0.9)], provider=provider)
    kinds: list[str] = []
    final = None
    async for kind, payload in service.stream_fanout_turn(
        _req("real-estate-valuation-expert", "What is the price?")
    ):
        kinds.append(kind)
        if kind == "final":
            final = payload
    assert (
        kinds.index("expert")
        < kinds.index("synthesis_start")
        < kinds.index("synthesis_token")
        < kinds.index("synthesis")
        < kinds.index("final")
    )
    assert kinds[-1] == "final"
    assert final is not None and final.synthesis is not None
    assert final.synthesis.agent_id == "director-program-orchestrator"
    # The streamed synthesis still reports token usage (cost audit preserved).
    assert final.meta.total_tokens > 0


async def test_stream_fanout_veto_yields_veto_then_blocked_final(tmp_path) -> None:  # noqa: ANN001
    provider = FakeProvider()
    service = _service(tmp_path, [_citation(0.9)], provider=provider)
    events = [
        (kind, payload)
        async for kind, payload in service.stream_fanout_turn(_req(query="Who owns this parcel?"))
    ]
    assert [k for k, _ in events] == ["veto", "final"]
    assert events[-1][1].model == "blocked"
    assert provider.requests == []  # blocked before any model call


async def test_veto_blocks_before_any_model_call(tmp_path) -> None:  # noqa: ANN001
    provider = FakeProvider()
    service = _service(tmp_path, [_citation(0.9)], provider=provider)
    out = await service.run_turn(_req(query="Who owns this parcel?"))
    assert out.veto is not None
    assert out.veto.gate == "compliance-data-governance"
    assert out.model == "blocked"
    assert provider.requests == []  # no model call happened


async def test_off_topic_abstains_without_a_model_call(tmp_path) -> None:  # noqa: ANN001
    # An off-domain question ("a bacteria") abstains instantly — no LLM call, so
    # it is fast and never invents off-corpus content.
    provider = FakeProvider()
    service = _service(tmp_path, [_citation(0.9)], provider=provider)
    out = await service.run_turn(_req(query="que es una bacteria"))
    assert out.veto is None
    assert out.messages[0].abstained
    assert "outside this platform's domain" in out.messages[0].content
    assert provider.requests == []  # the guard ran before any model call


async def test_followup_inherits_thread_topic_not_off_topic(tmp_path) -> None:  # noqa: ANN001
    # A context-light follow-up ("Explain that in more detail") after an on-topic turn
    # must NOT abstain as off-domain — it inherits the conversation's topic.
    provider = FakeProvider()
    service = _service(tmp_path, [_citation(0.9)], provider=provider)
    request = CouncilChatRequest(
        agents=["real-estate-valuation-expert"],
        messages=[
            CouncilChatMessage(
                role="user", content="What is the price benchmark for Mussafah land?"
            ),
            CouncilChatMessage(role="assistant", content="The benchmark is grounded evidence."),
            CouncilChatMessage(role="user", content="Explain that in more detail"),
        ],
        stream=False,
    )
    out = await service.run_turn(request)
    # The turn proceeded past the on-topic gate to a real (grounded) answer.
    assert provider.requests, "the follow-up was wrongly rejected as off-domain"
    answer = out.synthesis.content if out.synthesis else out.messages[0].content
    assert "outside this platform's domain" not in answer


async def test_synthesis_abstains_when_all_experts_abstain(tmp_path) -> None:  # noqa: ANN001
    class AbstainingProvider(FakeProvider):
        async def chat(self, request, model):  # noqa: ANN001, ANN202
            from app.schemas import ChatChoice, ChatChoiceMessage, ChatCompletionResponse

            self.requests.append(request)
            return ChatCompletionResponse(
                id="x",
                model=model,
                choices=[
                    ChatChoice(
                        index=0,
                        message=ChatChoiceMessage(role="assistant", content=""),
                        finish_reason="stop",
                    )
                ],
                abstained=True,
            )

    provider = AbstainingProvider()
    service = _service(tmp_path, [_citation(0.9)], provider=provider)
    out = await service.run_turn(_req("real-estate-valuation-expert", "What is the price?"))
    # All experts abstained -> the Director abstains WITHOUT a synthesis model call.
    assert out.synthesis is not None and out.synthesis.abstained
    assert len(provider.requests) == 1  # only the expert turn, no synthesis call


def test_council_chat_streams_multi_agent_sse(tmp_path) -> None:  # noqa: ANN001
    client = _client(tmp_path)
    with client.stream(
        "POST",
        "/v1/council/chat",
        headers=AUTH,
        json={
            "agents": ["real-estate-valuation-expert"],
            "messages": [{"role": "user", "content": "What is the price?"}],
            "stream": True,
        },
    ) as resp:
        raw = "".join(resp.iter_text())
    assert "event: turn_started" in raw
    assert "event: agent_message" in raw
    assert "event: synthesis_started" in raw
    assert "event: message_done" in raw


# --- F3: deliberation + turn metadata ----------------------------------------


def _two_experts(tmp_path) -> None:  # noqa: ANN001
    """Write a second, distinct expert (investment) alongside valuation."""
    (tmp_path / "biz-investment-analyst.agent.md").write_text(
        """---
name: Investment & Capital Markets Analyst
description: "IRR, yield, risk-adjusted return."
tools: [read, search, execute]
---

# Investment & Capital Markets Analyst

You own IRR, yield and risk-adjusted return. Ground in `GET /v1/recommendation`.
""",
        encoding="utf-8",
    )


async def test_deliberation_adds_reply_to_reactions(tmp_path) -> None:  # noqa: ANN001
    _write_agents(tmp_path)
    _two_experts(tmp_path)
    registry = CouncilRegistry.from_directory(tmp_path)
    provider = FakeProvider(content="A grounded view.")
    from app.inference import InferenceService
    from app.routing import Router

    service = CouncilService(
        registry=registry,
        inference=InferenceService(provider, Router()),
        retrieval=FakeRetrieval([_citation(0.9)]),
        require_grounding=True,
    )
    # "price" (valuation) + "return"/"yield" (investment) route to both domains.
    request = CouncilChatRequest(
        agents=["real-estate-valuation-expert", "investment-capital-markets-analyst"],
        messages=[CouncilChatMessage(role="user", content="price and return?")],
        stream=False,
        deliberate=True,
    )
    out = await service.run_turn(request)
    reactions = [m for m in out.messages if m.reply_to]
    # Both experts spoke in round 1 and reacted to each other in the deliberation round.
    assert out.meta.rounds == 2
    assert reactions, "expected at least one deliberation reaction with reply_to"
    for reaction in reactions:
        assert reaction.agent_id != reaction.reply_to[0]


async def test_deliberation_off_for_single_expert(tmp_path) -> None:  # noqa: ANN001
    service = _service(tmp_path, [_citation(0.9)])
    out = await service.run_turn(_req("real-estate-valuation-expert", "What is the price?"))
    assert out.meta.rounds == 1  # one expert -> no deliberation round


async def test_turn_meta_reports_participants_and_tokens(tmp_path) -> None:  # noqa: ANN001
    service = _service(tmp_path, [_citation(0.9)])
    out = await service.run_turn(_req("real-estate-valuation-expert", "What is the price?"))
    assert "real-estate-valuation-expert" in out.meta.participants
    assert "director-program-orchestrator" in out.meta.participants
    # FakeProvider reports 1 prompt + 1 completion token per call.
    assert out.meta.total_tokens >= 2


def test_director_prompt_answers_directly() -> None:
    """The Director, when it is the speaker, must answer — not narrate orchestration."""
    agent = compile_persona(_DIRECTOR_MD, source_path="director.agent.md")
    assert agent.kind == "director"
    prompt = agent.compose_system_prompt()
    assert "answer the user directly" in prompt
    assert "Do NOT narrate your routing" in prompt


def test_expert_prompt_unchanged_by_director_rule() -> None:
    agent = compile_persona(_VALUATION_MD, source_path="biz-valuation-expert.agent.md")
    assert "answer the user directly" not in agent.compose_system_prompt()


async def test_single_speaker_stream_reports_real_token_usage(tmp_path) -> None:  # noqa: ANN001
    """The single-speaker streaming path must carry the turn's real token usage
    into meta (the CLI footer), not the hardcoded 0 that showed '0 tokens'."""
    service = _service(tmp_path, [_citation(0.9)])
    request = _req(query="Tell me about the price.")  # no agents -> Director alone (F1)
    events = [
        (kind, delta, message) async for kind, delta, message in service.stream_single_turn(request)
    ]
    assert any(k == "done" for k, _, _ in events)
    # The streamed turn recorded the model call's usage (FakeProvider: 1+1=2).
    usage = service.current_usage()
    assert usage["total_tokens"] >= 2
    assert usage["prompt_tokens"] >= 1
