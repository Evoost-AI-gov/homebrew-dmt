"""InputReader — codex-style input: history persistence, non-TTY passthrough,
multi-line assembly. The raw-termios interactive path is exercised via a fake
stdin only where feasible; the contract (history + non-TTY fallback) is pinned."""

from app.cli.input import InputReader


def test_non_interactive_reads_a_line(monkeypatch, tmp_path):
    reader = InputReader(history_path=tmp_path / "h", interactive=False)
    monkeypatch.setattr("builtins.input", lambda prompt: "hello council")
    assert reader.read("dmt ❯ ") == "hello council"


def test_non_interactive_eof_returns_none(monkeypatch, tmp_path):
    reader = InputReader(history_path=tmp_path / "h", interactive=False)

    def _eof(_prompt):
        raise EOFError

    monkeypatch.setattr("builtins.input", _eof)
    assert reader.read("dmt ❯ ") is None


def test_history_persists_across_instances(tmp_path):
    path = tmp_path / "input_history"
    r1 = InputReader(history_path=path, interactive=True)
    r1._push_history("first question")
    r1._push_history("second question")
    r2 = InputReader(history_path=path, interactive=True)
    assert r2._history[-2:] == ["first question", "second question"]


def test_history_ignores_blank_and_caps(tmp_path):
    path = tmp_path / "input_history"
    r = InputReader(history_path=path, interactive=True)
    for i in range(600):
        r._push_history(f"q{i}")
    r2 = InputReader(history_path=path, interactive=True)
    assert len(r2._history) == 500  # capped


def test_history_failure_is_silent(tmp_path):
    # A read-only history file must never break input.
    path = tmp_path / "sub" / "input_history"
    r = InputReader(history_path=path, interactive=True)
    r._push_history("q")  # parent may not exist; should not raise


def test_fuzzy_match_subsequence(tmp_path):
    r = InputReader(history_path=tmp_path / "h", interactive=True)
    r._history = ["rent benchmark Mussafah", "IRR on commercial", "rent benchmark Dubai"]
    assert "rent benchmark Mussafah" in r._match("rentmu")
    assert len(r._match("rent")) == 2
    assert r._match("zzz") == []


def test_fuzzy_match_empty_returns_recent(tmp_path):
    r = InputReader(history_path=tmp_path / "h", interactive=True)
    r._history = ["one", "two", "three"]
    assert r._match("") == ["three", "two", "one"]  # most recent first
