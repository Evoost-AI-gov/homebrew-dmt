"""SSE parser tests — chunk boundaries, multi-line data, keepalives."""

from app.cli.sse import SseParser


def test_single_frame():
    parser = SseParser()
    events = parser.feed('event: token\ndata: {"delta": "hi"}\n\n')
    assert len(events) == 1
    assert events[0].event == "token"
    assert events[0].data == '{"delta": "hi"}'


def test_frame_split_across_chunks():
    parser = SseParser()
    assert parser.feed("event: tok") == []
    assert parser.feed('en\ndata: {"a"') == []
    events = parser.feed(": 1}\n\n")
    assert len(events) == 1
    assert events[0].event == "token"
    assert events[0].data == '{"a": 1}'


def test_multiple_frames_one_chunk():
    parser = SseParser()
    events = parser.feed("event: a\ndata: 1\n\nevent: b\ndata: 2\n\n")
    assert [e.event for e in events] == ["a", "b"]
    assert [e.data for e in events] == ["1", "2"]


def test_multiline_data_joined():
    parser = SseParser()
    events = parser.feed("event: token\ndata: line1\ndata: line2\n\n")
    assert events[0].data == "line1\nline2"


def test_keepalive_comments_ignored():
    parser = SseParser()
    assert parser.feed(": ping\n\n") == []
    events = parser.feed("event: a\ndata: 1\n\n")
    assert len(events) == 1


def test_default_event_is_message():
    parser = SseParser()
    events = parser.feed("data: hello\n\n")
    assert events[0].event == "message"


def test_close_flushes_trailing_frame():
    parser = SseParser()
    parser.feed("event: done\ndata: {}")
    events = parser.close()
    assert len(events) == 1
    assert events[0].event == "done"
    assert parser.close() == []
