"""Entra auth tests — login/logout/status with a fake MSAL (no real dependency,
no network): the CLI must behave identically with the library stubbed."""

import json
import sys
import time
import types
from pathlib import Path

import pytest

from app.cli import auth
from app.cli.auth import AuthError


class _FakeCache:
    def __init__(self):
        self._data = ""
        self.has_state_changed = False

    def deserialize(self, text):
        self._data = text

    def serialize(self):
        return self._data


class _FakeApp:
    """Minimal PublicClientApplication stub."""

    interactive_result: dict | None = None
    silent_result: dict | None = None
    accounts: list = []

    def __init__(self, *args, **kwargs):
        self._cache = kwargs.get("token_cache")

    def _acquired(self, result):
        if self._cache is not None and result and "access_token" in result:
            self._cache.has_state_changed = True
        return result

    def get_accounts(self):
        return list(type(self).accounts)

    def acquire_token_silent(self, scopes, account=None):
        return self._acquired(type(self).silent_result)

    def acquire_token_interactive(self, scopes, prompt=None, port=None):
        return self._acquired(type(self).interactive_result)

    def initiate_device_flow(self, scopes):
        return {"user_code": "ABC123", "message": "go to https://microsoft.com/devicelogin"}

    def acquire_token_by_device_flow(self, flow):
        return self._acquired(type(self).interactive_result)


@pytest.fixture()
def fake_msal(monkeypatch, tmp_path):
    module = types.ModuleType("msal")
    module.SerializableTokenCache = _FakeCache
    module.PublicClientApplication = _FakeApp
    monkeypatch.setitem(sys.modules, "msal", module)
    monkeypatch.setenv("DMT_CONFIG_DIR", str(tmp_path))
    _FakeApp.accounts = []
    _FakeApp.interactive_result = None
    _FakeApp.silent_result = None
    return tmp_path


def test_status_signed_out(fake_msal):
    assert auth.status().signed_in is False


def test_login_device_code_persists_cache(fake_msal, capsys):
    _FakeApp.interactive_result = {
        "access_token": "tok",
        "id_token_claims": {"preferred_username": "user@dmt.gov.ae"},
    }
    _FakeApp.accounts = []  # app stub; status reads accounts after login

    auth.login(device_code=True)
    assert "devicelogin" in capsys.readouterr().out  # the flow prompt is shown
    assert (fake_msal / "msal_cache.json").exists()


def test_login_failure_raises_auth_error(fake_msal):
    _FakeApp.interactive_result = {"error": "access_denied", "error_description": "user cancelled"}
    with pytest.raises(AuthError, match="user cancelled"):
        auth.login(device_code=True)


def test_acquire_token_silent_none_when_signed_out(fake_msal):
    assert auth.acquire_token_silent(None) is None


def test_acquire_token_silent_returns_token(fake_msal):
    _FakeApp.accounts = [{"username": "user@dmt.gov.ae"}]
    _FakeApp.silent_result = {"access_token": "fresh-tok"}
    (fake_msal / "msal_cache.json").write_text("{}")
    assert auth.acquire_token_silent(None) == "fresh-tok"


def test_acquire_token_silent_never_raises(fake_msal, monkeypatch):
    def boom():
        raise RuntimeError("msal exploded")

    monkeypatch.setattr(auth, "_load_cache", boom)
    assert auth.acquire_token_silent(None) is None


def test_logout_removes_cache(fake_msal):
    cache = fake_msal / "msal_cache.json"
    cache.write_text("{}")
    assert auth.logout() is True
    assert not cache.exists()
    assert auth.logout() is False


def test_missing_msal_dependency_is_actionable(monkeypatch, tmp_path):
    monkeypatch.setitem(sys.modules, "msal", None)
    monkeypatch.setenv("DMT_CONFIG_DIR", str(tmp_path))
    with pytest.raises(AuthError, match="dmt-ai-services\\[cli\\]"):
        auth.login(device_code=True)


def test_cache_file_permissions_are_owner_only(fake_msal):
    _FakeApp.interactive_result = {"access_token": "tok"}
    auth.login(device_code=True)
    mode = (fake_msal / "msal_cache.json").stat().st_mode
    assert oct(mode & 0o777) == "0o600"


def test_status_reads_cached_account(fake_msal):
    expires = int(time.time()) + 3600
    cache = fake_msal / "msal_cache.json"
    cache.write_text(json.dumps({"AccessToken": {"k": {"expires_on": str(expires)}}}))
    _FakeApp.accounts = [{"username": "user@dmt.gov.ae", "realm": "tenant-1"}]
    # The fake app re-reads the file through _load_cache; the serialized cache
    # round-trips through the fake's in-memory store.
    info = auth.status()
    assert info.signed_in is True
    assert info.username == "user@dmt.gov.ae"
    assert info.tenant_id == "tenant-1"


def test_cache_path_under_config_dir(fake_msal):
    assert auth.cache_path().parent == Path(fake_msal)
