"""Follow-up suggestion chips — deterministic, contextual, always with an
explicit free-text opt-out."""

from app.cli.suggest import FREE_TEXT, suggest


def test_empty_turn_offers_only_free_text():
    assert suggest({}) == [FREE_TEXT]


def test_valuation_agent_suggests_irr_followup():
    final = {
        "messages": [{"agent_id": "biz-valuation-expert", "content": "…"}],
        "synthesis": None,
        "veto": None,
    }
    chips = suggest(final)
    assert "Model the IRR / yield on that benchmark" in chips
    assert chips[-1] == FREE_TEXT


def test_veto_surfaces_why_blocked_first():
    final = {
        "messages": [{"agent_id": "biz-valuation-expert", "content": "…"}],
        "synthesis": None,
        "veto": {"gate": "compliance-data-governance", "reason": "x"},
    }
    chips = suggest(final)
    assert chips[0] == "Why was that blocked by governance?"


def test_abstention_surfaces_scope_question():
    final = {
        "messages": [{"agent_id": "biz-market-intelligence", "content": "", "abstained": True}],
        "synthesis": None,
        "veto": None,
    }
    assert "What CAN you answer from the governed sources?" in suggest(final)


def test_synthesis_agent_also_informs_chips():
    final = {
        "messages": [{"agent_id": "biz-sequencing-strategist", "content": "…"}],
        "synthesis": {"agent_id": "director-program-orchestrator", "content": "…"},
        "veto": None,
    }
    chips = suggest(final)
    assert any("Sequence" in c for c in chips)


def test_caps_at_three_plus_free_text():
    final = {
        "messages": [
            {"agent_id": "biz-valuation-expert", "content": ""},
            {"agent_id": "biz-sequencing-strategist", "content": ""},
            {"agent_id": "biz-urban-planning-strategist", "content": ""},
            {"agent_id": "biz-sustainability-esg", "content": ""},
        ],
        "synthesis": None,
        "veto": None,
    }
    chips = suggest(final)
    assert len(chips) == 4  # 3 contextual + free-text
    assert chips[-1] == FREE_TEXT


def test_no_duplicates():
    final = {
        "messages": [
            {"agent_id": "biz-valuation-expert", "content": ""},
            {"agent_id": "valuation-expert", "content": ""},  # same short key
        ],
        "synthesis": None,
        "veto": None,
    }
    chips = suggest(final)
    assert chips.count("Model the IRR / yield on that benchmark") == 1
