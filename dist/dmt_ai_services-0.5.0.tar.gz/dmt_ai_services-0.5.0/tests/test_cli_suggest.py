"""Follow-up suggestion chips — deterministic, contextual, always with an
explicit free-text opt-out."""

from app.cli.suggest import FREE_TEXT, suggest


def test_empty_turn_offers_only_free_text():
    assert suggest({}) == [FREE_TEXT]


def test_valuation_agent_suggests_irr_followup():
    final = {
        "messages": [{"agent_id": "biz-valuation-expert", "content": "…"}],
        "synthesis": None,
        "veto": None,
    }
    chips = suggest(final)
    assert "Model the IRR / yield on that benchmark" in chips
    assert chips[-1] == FREE_TEXT


def test_veto_surfaces_why_blocked_first():
    final = {
        "messages": [{"agent_id": "biz-valuation-expert", "content": "…"}],
        "synthesis": None,
        "veto": {"gate": "compliance-data-governance", "reason": "x"},
    }
    chips = suggest(final)
    assert chips[0] == "Why was that blocked by governance?"


def test_abstention_surfaces_scope_question():
    final = {
        "messages": [{"agent_id": "biz-market-intelligence", "content": "", "abstained": True}],
        "synthesis": None,
        "veto": None,
    }
    assert "What CAN you answer from the governed sources?" in suggest(final)


def test_synthesis_agent_also_informs_chips():
    final = {
        "messages": [{"agent_id": "biz-sequencing-strategist", "content": "…"}],
        "synthesis": {"agent_id": "director-program-orchestrator", "content": "…"},
        "veto": None,
    }
    chips = suggest(final)
    assert any("Sequence" in c for c in chips)


def test_caps_at_three_plus_free_text():
    final = {
        "messages": [
            {"agent_id": "biz-valuation-expert", "content": ""},
            {"agent_id": "biz-sequencing-strategist", "content": ""},
            {"agent_id": "biz-urban-planning-strategist", "content": ""},
            {"agent_id": "biz-sustainability-esg", "content": ""},
        ],
        "synthesis": None,
        "veto": None,
    }
    chips = suggest(final)
    assert len(chips) == 4  # 3 contextual + free-text
    assert chips[-1] == FREE_TEXT


def test_no_duplicates():
    final = {
        "messages": [
            {"agent_id": "biz-valuation-expert", "content": ""},
            {"agent_id": "valuation-expert", "content": ""},  # same short key
        ],
        "synthesis": None,
        "veto": None,
    }
    chips = suggest(final)
    assert chips.count("Model the IRR / yield on that benchmark") == 1


def test_director_next_actions_become_selectable_chips():
    """The Director's proposed Next Actions lead the picker (governed, turn-
    specific) — not just the generic chips."""
    final = {
        "messages": [],
        "synthesis": {
            "agent_id": "director-program-orchestrator",
            "content": (
                "## Decision\nProceed with caution.\n\n"
                "## Next Actions\n"
                "1. Request H3-grid data augmentation for low-confidence parcels.\n"
                "2. Validate Pearl 3+ PCRS feasibility with `biz-government-affairs`.\n"
            ),
        },
        "veto": None,
    }
    chips = suggest(final)
    assert chips[0] == "Request H3-grid data augmentation for low-confidence parcels."
    assert chips[1] == "Validate Pearl 3+ PCRS feasibility with biz-government-affairs."
    assert chips[-1] == FREE_TEXT


def test_next_actions_strip_inline_code_and_stop_at_blank_line():
    final = {
        "messages": [],
        "synthesis": {
            "agent_id": "director-program-orchestrator",
            "content": (
                "Next Actions\n\n"
                "- Screen the geopolitical angle with `biz-geopolitical-risk`.\n"
                "\n"
                "## Risks\n- This section must NOT leak into chips.\n"
            ),
        },
        "veto": None,
    }
    chips = suggest(final)
    assert chips[0] == "Screen the geopolitical angle with biz-geopolitical-risk."
    assert not any("Risks" in c for c in chips)


def test_no_next_actions_falls_back_to_deterministic_chips():
    final = {
        "messages": [{"agent_id": "biz-valuation-expert", "content": "A plain answer."}],
        "synthesis": None,
        "veto": None,
    }
    chips = suggest(final)
    assert chips[0] == "Model the IRR / yield on that benchmark"


def test_next_actions_numbered_without_periods():
    """The Director's real output numbers items as '1 Action' (no period) — the
    parser must capture that form, not just '1.' / '1)'."""
    final = {
        "messages": [],
        "synthesis": {
            "agent_id": "director-program-orchestrator",
            "content": (
                "Next Actions\n\n"
                "1 Request H3-grid data augmentation for low-confidence parcels.\n"
                "2 Validate Pearl 3+ PCRS feasibility with biz-government-affairs.\n"
            ),
        },
        "veto": None,
    }
    chips = suggest(final)
    assert chips[0] == "Request H3-grid data augmentation for low-confidence parcels."
    assert chips[1] == "Validate Pearl 3+ PCRS feasibility with biz-government-affairs."
