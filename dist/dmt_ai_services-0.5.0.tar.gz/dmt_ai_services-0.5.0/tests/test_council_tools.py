"""Tests for the governed read-only tools (pricing benchmark)."""

from __future__ import annotations

from app.council.tools import BriefTool, PricingTool, run_governed_tools


class TestPricingTool:
    def test_configured_and_categories(self) -> None:
        tool = PricingTool()
        assert tool.configured
        assert "commercial" in tool.all_categories()

    def test_category_lookup_returns_governed_band(self) -> None:
        result = PricingTool().lookup(category="commercial")
        assert result.found
        assert "median=314.2" in result.text
        assert result.confidence == "high"
        assert "IC-approved" in result.source

    def test_district_category_is_most_specific(self) -> None:
        result = PricingTool().lookup(category="commercial", district="al_bateen")
        assert result.found
        assert "Al Bateen" in result.text

    def test_disclosure_floor_never_reveals_thin_band(self) -> None:
        # A fabricated category with < min deals would abstain; an unknown one
        # returns not-found (never invents).
        result = PricingTool().lookup(category="nonexistent_category")
        assert not result.found

    def test_unconfigured_tool_abstains(self, tmp_path) -> None:
        result = PricingTool(tmp_path / "missing.json").lookup(category="commercial")
        assert not result.found


class TestRunGovernedTools:
    def test_pricing_signal_triggers_pricing(self) -> None:
        results = run_governed_tools(
            "What is the rent benchmark for commercial land?", PricingTool()
        )
        assert results and results[0].tool == "pricing.query"

    def test_district_and_category_detected(self) -> None:
        results = run_governed_tools(
            "How much is industrial rent in Mohamed Bin Zayed City?", PricingTool()
        )
        assert results and "industrial" in results[0].text.lower()

    def test_no_pricing_signal_no_tool(self) -> None:
        assert run_governed_tools("What is the zoning for this plot?", PricingTool()) == []

    def test_result_below_floor_is_not_returned(self) -> None:
        # A query that matches pricing but no band clears the floor -> no result.
        results = run_governed_tools("price of a plot on the moon", PricingTool())
        assert results == []


class TestConflictDetection:
    def test_detects_a_sharp_divergence(self, tmp_path) -> None:
        # A district band that contradicts the category-wide band is flagged.
        import json

        table = {
            "provenance": {"min_deals_per_band": 1},
            "groups": {
                "category": {
                    "commercial": {"n": 10, "rent_aed_sqm": {"p50": 300.0}, "confidence": "high"}
                },
                "district_category": {
                    "al_bateen|commercial": {
                        "n": 5,
                        "rent_aed_sqm": {"p50": 600.0},
                        "confidence": "medium",
                    }
                },
            },
        }
        p = tmp_path / "rate_table.json"
        p.write_text(json.dumps(table))
        from app.council.tools import PricingTool

        conflicts = PricingTool(p).conflicts()
        assert len(conflicts) == 1
        assert conflicts[0]["district"] == "al_bateen"
        assert conflicts[0]["divergence"] > 0.6

    def test_no_conflict_when_consistent(self, tmp_path) -> None:
        import json

        table = {
            "provenance": {"min_deals_per_band": 1},
            "groups": {
                "category": {
                    "commercial": {"n": 10, "rent_aed_sqm": {"p50": 300.0}, "confidence": "high"}
                },
                "district_category": {
                    "al_bateen|commercial": {
                        "n": 5,
                        "rent_aed_sqm": {"p50": 310.0},
                        "confidence": "medium",
                    }
                },
            },
        }
        p = tmp_path / "rate_table.json"
        p.write_text(json.dumps(table))
        from app.council.tools import PricingTool

        assert PricingTool(p).conflicts() == []


_BRIEF = {
    "generated_at": "2026-08-29T07:27:41+00:00",
    "headline_confidence": "low",
    "cost": {
        "available": True,
        "name": "Abu Dhabi Construction Cost Index (Global-Input Proxy)",
        "level": 100.9,
        "change_pct": 0.87,
    },
    "posture": {
        "available": True,
        "posture": "stage",
        "calendar": "2026–2028",
        "basis": "evidence",
    },
    "robustness": {
        "available": True,
        "scenario_label": "Pessimistic",
        "at_risk_count": 23,
        "phase1_parcel_count": 25,
        "revenue_at_risk_pct": 94.5,
        "headroom_materials_pct": 9.3,
        "headroom_energy_pct": 22.2,
        "headroom_financing_bp": 111.0,
    },
    "tripwires": [
        {"label": "Energy & fuel", "tripped_posture": "stage", "pct_to_trip": 33, "armed": True},
        {"label": "Financing", "tripped_posture": "stage", "pct_to_trip": 67, "armed": True},
    ],
}


def _brief_file(tmp_path):
    import json

    p = tmp_path / "command_center_brief.json"
    p.write_text(json.dumps(_BRIEF))
    return p


class TestBriefTool:
    def test_default_snapshot_is_configured(self) -> None:
        assert BriefTool().configured

    def test_summary_cites_posture_robustness_and_earliest_tripwire(self, tmp_path) -> None:
        result = BriefTool(_brief_file(tmp_path)).summary()
        assert result is not None and result.found
        assert result.tool == "command_center.brief"
        assert "stage" in result.text
        assert "23 of 25" in result.text
        assert "94.5%" in result.text
        # Earliest tripwire = the lowest pct_to_trip (Energy at 33%), not Financing at 67%.
        assert "Energy & fuel" in result.text and "33%" in result.text
        assert result.confidence == "low"
        assert "2026-08-29" in result.source

    def test_unconfigured_brief_abstains(self, tmp_path) -> None:
        assert BriefTool(tmp_path / "missing.json").summary() is None


class TestRunGovernedToolsBrief:
    def test_brief_signal_triggers_brief(self, tmp_path) -> None:
        results = run_governed_tools(
            "What is the release posture and how robust is the plan?",
            None,
            BriefTool(_brief_file(tmp_path)),
        )
        assert results and results[0].tool == "command_center.brief"

    def test_no_brief_signal_no_brief(self, tmp_path) -> None:
        results = run_governed_tools(
            "What is the zoning for this plot?", None, BriefTool(_brief_file(tmp_path))
        )
        assert results == []

    def test_unconfigured_returns_empty(self, tmp_path) -> None:
        from app.council.tools import PricingTool

        assert PricingTool(tmp_path / "missing.json").conflicts() == []
