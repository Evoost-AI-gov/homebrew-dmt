"""Tests for the OpenAI-compatible upstream provider using a mock transport."""

from __future__ import annotations

import json

import httpx
import pytest

from app.errors import UpstreamError, UpstreamRejectedError
from app.providers import OpenAICompatibleProvider
from app.schemas import ChatCompletionRequest, EmbeddingRequest


def _provider(handler: object, max_retries: int = 2) -> OpenAICompatibleProvider:
    return OpenAICompatibleProvider(
        base_url="http://upstream.local",
        max_retries=max_retries,
        transport=httpx.MockTransport(handler),
    )


async def test_provider_chat_maps_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/v1/chat/completions"
        body = json.loads(request.content)
        # Null fields (e.g. message.name) must be dropped so strict upstreams
        # (llama.cpp) do not 500, and the internal flag must not be forwarded.
        assert "require_grounding" not in body
        assert all("name" not in message for message in body["messages"])
        return httpx.Response(
            200,
            json={
                "id": "up-1",
                "choices": [
                    {"message": {"role": "assistant", "content": "hi"}, "finish_reason": "stop"}
                ],
                "usage": {"prompt_tokens": 3, "completion_tokens": 2, "total_tokens": 5},
            },
        )

    provider = _provider(handler)
    request = ChatCompletionRequest(model="dmt-brain", messages=[{"role": "user", "content": "hi"}])
    response = await provider.chat(request, "qwen3:8b")
    assert response.model == "qwen3:8b"
    assert response.choices[0].message.content == "hi"
    assert response.usage.total_tokens == 5


async def test_provider_embeddings_maps_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/v1/embeddings"
        return httpx.Response(
            200,
            json={"data": [{"index": 0, "embedding": [0.1, 0.2]}], "model": "nomic"},
        )

    provider = _provider(handler)
    request = EmbeddingRequest(model="embed", input=["x"])
    response = await provider.embeddings(request, "nomic-embed-text")
    assert response.data[0].embedding == [0.1, 0.2]


async def test_provider_rejects_4xx_without_retry() -> None:
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        return httpx.Response(400, json={"error": "bad"})

    provider = _provider(handler, max_retries=3)
    request = ChatCompletionRequest(model="dmt-brain", messages=[{"role": "user", "content": "hi"}])
    with pytest.raises(UpstreamRejectedError):
        await provider.chat(request, "qwen3:8b")
    assert calls["n"] == 1  # 4xx is not retried and is not a fallback trigger


async def test_provider_invalid_json_on_2xx_raises() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=b"not-json")

    provider = _provider(handler)
    request = ChatCompletionRequest(model="dmt-brain", messages=[{"role": "user", "content": "hi"}])
    with pytest.raises(UpstreamError):
        await provider.chat(request, "qwen3:8b")


async def test_provider_retries_5xx_then_fails() -> None:
    calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        return httpx.Response(503, json={"error": "unavailable"})

    provider = _provider(handler, max_retries=2)
    request = ChatCompletionRequest(model="dmt-brain", messages=[{"role": "user", "content": "hi"}])
    with pytest.raises(UpstreamError):
        await provider.chat(request, "qwen3:8b")
    assert calls["n"] == 3  # initial try + 2 retries
