"""CouncilClient tests — auth headers, SSE streaming, error envelope, chats."""

import json

import httpx
import pytest

from app.cli.client import CliError, CouncilClient, ServerError
from app.cli.config import resolve

TURN_RESPONSE = {
    "id": "turn-1",
    "conversation_id": "conv-1",
    "model": "dmt-brain",
    "messages": [
        {
            "agent_id": "director-program-orchestrator",
            "content": "Hola.",
            "confidence": "high",
            "abstained": False,
        }
    ],
    "synthesis": None,
    "veto": None,
    "meta": {"participants": ["director-program-orchestrator"], "total_tokens": 42},
}


def _config(**overrides):
    base = {"base_url": "http://gw.test", "color": False, "transcript": False}
    base.update(overrides)
    return resolve(**base)


def _client(handler, **overrides) -> CouncilClient:
    transport = httpx.MockTransport(handler)
    return CouncilClient(_config(**overrides), transport=transport)


def test_unary_chat_yields_single_done_event():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["x-api-key"] == "test-key"
        body = json.loads(request.content)
        assert body["stream"] is False
        assert body["agents"] == ["director-program-orchestrator"]
        return httpx.Response(200, json=TURN_RESPONSE)

    with _client(handler, api_key="test-key") as client:
        events = list(
            client.chat(
                messages=[{"role": "user", "content": "hola"}],
                agents=["director-program-orchestrator"],
                conversation_id="conv-1",
                stream=False,
            )
        )
    assert [e.kind for e in events] == ["message_done"]
    assert events[0].payload["messages"][0]["confidence"] == "high"


def test_stream_chat_parses_sse_events():
    sse_body = (
        'event: turn_started\ndata: {"agents": ["director-program-orchestrator"]}\n\n'
        'event: agent_started\ndata: {"agent_id": "director-program-orchestrator"}\n\n'
        'event: token\ndata: {"agent_id": "d", "delta": "Hel"}\n\n'
        'event: token\ndata: {"agent_id": "d", "delta": "lo"}\n\n'
        f"event: message_done\ndata: {json.dumps(TURN_RESPONSE)}\n\n"
    )

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text=sse_body, headers={"Content-Type": "text/event-stream"})

    with _client(handler, api_key="k") as client:
        events = list(
            client.chat(
                messages=[{"role": "user", "content": "hi"}],
                agents=[],
                conversation_id=None,
                stream=True,
            )
        )
    kinds = [e.kind for e in events]
    assert kinds == ["turn_started", "agent_started", "token", "token", "message_done"]
    assert events[2].payload["delta"] == "Hel"


def test_bearer_token_preferred_over_api_key():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["authorization"] == "Bearer tok-123"
        assert "x-api-key" not in request.headers
        return httpx.Response(200, json={"status": "ok"})

    with _client(handler, api_key="k", access_token="tok-123") as client:
        assert client.health()["status"] == "ok"


def test_cached_entra_token_preferred_over_api_key():
    """Documented precedence: explicit token → cached Entra sign-in → API key."""

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["authorization"] == "Bearer cached-tok"
        assert "x-api-key" not in request.headers
        return httpx.Response(200, json={"status": "ok"})

    transport = httpx.MockTransport(handler)
    with CouncilClient(
        _config(api_key="k"), transport=transport, token_provider=lambda: "cached-tok"
    ) as client:
        assert client.health()["status"] == "ok"


def test_api_key_used_when_signed_out():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["x-api-key"] == "k"
        assert "authorization" not in request.headers
        return httpx.Response(200, json={"status": "ok"})

    transport = httpx.MockTransport(handler)
    with CouncilClient(
        _config(api_key="k"), transport=transport, token_provider=lambda: None
    ) as client:
        assert client.health()["status"] == "ok"


def test_token_provider_used_when_no_explicit_credentials():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["authorization"] == "Bearer cached-tok"
        return httpx.Response(200, json={"status": "ok"})

    transport = httpx.MockTransport(handler)
    with CouncilClient(
        _config(), transport=transport, token_provider=lambda: "cached-tok"
    ) as client:
        assert client.health()["status"] == "ok"


def test_error_envelope_maps_to_server_error_with_auth_hint():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            401, json={"error": {"code": "unauthorized", "message": "missing key"}}
        )

    with _client(handler) as client, pytest.raises(ServerError) as excinfo:
        client.health()
    assert excinfo.value.status == 401
    assert "dmt auth login" in str(excinfo.value)


def test_rate_limit_hint():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(429, json={"error": {"code": "rate_limited", "message": "slow down"}})

    with _client(handler, api_key="k") as client, pytest.raises(ServerError) as excinfo:
        client.health()
    assert "rate limited" in str(excinfo.value)


def test_connect_error_is_cli_error():
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("refused")

    with _client(handler, api_key="k") as client, pytest.raises(CliError, match="cannot reach"):
        client.health()


def test_chats_roundtrip():
    stored: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "GET":
            return httpx.Response(200, json=list(stored.values()))
        if request.method == "PUT":
            conv_id = request.url.path.rsplit("/", 1)[-1]
            stored[conv_id] = {"id": conv_id, **json.loads(request.content)}
            return httpx.Response(200, json=stored[conv_id])
        if request.method == "DELETE":
            stored.pop(request.url.path.rsplit("/", 1)[-1], None)
            return httpx.Response(204)
        return httpx.Response(405)

    with _client(handler, api_key="k") as client:
        client.upsert_chat(
            "c1", title="demo", messages=[{"id": "m0", "role": "user", "content": "hi"}]
        )
        assert client.list_chats()[0]["title"] == "demo"
        client.delete_chat("c1")
        assert client.list_chats() == []


def test_roster_returns_data_list():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"data": [{"agent_id": "director", "kind": "director"}]})

    with _client(handler, api_key="k") as client:
        roster = client.roster()
    assert roster[0]["agent_id"] == "director"


def test_council_404_surfaces_a_clear_message():
    """A 404 on /v1/council/* (gateway up, no agents dir) must read as a clear
    'no council configured' error, not a raw 404 (hit live against :8000)."""

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"detail": "Not Found"})

    with _client(handler, api_key="k") as client, pytest.raises(ServerError) as excinfo:
        client.roster()
    assert "no council configured" in str(excinfo.value)
    assert "public demo" in str(excinfo.value)  # points at the prod gateway
