"""Tests for the sovereign Azure OpenAI provider (native REST + api-key)."""

from __future__ import annotations

import httpx
import pytest

from app.errors import UpstreamRejectedError
from app.providers import AzureOpenAIProvider
from app.schemas import ChatCompletionRequest, ChatMessage, EmbeddingRequest


def _chat_request() -> ChatCompletionRequest:
    return ChatCompletionRequest(
        model="dmt-brain", messages=[ChatMessage(role="user", content="hi")]
    )


def _ok_transport(recorded: dict) -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        recorded["url"] = str(request.url)
        recorded["api_key"] = request.headers.get("api-key")
        recorded["authorization"] = request.headers.get("authorization")
        if "chat/completions" in request.url.path:
            return httpx.Response(
                200,
                json={
                    "id": "chatcmpl-az",
                    "choices": [
                        {
                            "index": 0,
                            "message": {"role": "assistant", "content": "grounded answer"},
                            "finish_reason": "stop",
                        }
                    ],
                    "usage": {"prompt_tokens": 3, "completion_tokens": 4, "total_tokens": 7},
                },
            )
        return httpx.Response(
            200,
            json={"data": [{"index": 0, "embedding": [0.1, 0.2]}], "usage": {"total_tokens": 2}},
        )

    return httpx.MockTransport(handler)


def _provider(transport: httpx.MockTransport) -> AzureOpenAIProvider:
    return AzureOpenAIProvider(
        endpoint="https://dmt.cognitiveservices.azure.com",
        api_key="test-key",
        transport=transport,
    )


def _bearer_provider(transport: httpx.MockTransport) -> AzureOpenAIProvider:
    return AzureOpenAIProvider(
        endpoint="https://dmt.cognitiveservices.azure.com",
        bearer_token="expired-token",
        transport=transport,
    )


async def test_chat_refreshes_bearer_token_on_401() -> None:
    # First call 401s (expired token); the provider refreshes and retries once.
    calls: list[str | None] = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(request.headers.get("authorization"))
        if len(calls) == 1:
            return httpx.Response(401, json={"error": {"message": "expired"}})
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-az",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": "ok"},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {"total_tokens": 1},
            },
        )

    provider = _bearer_provider(httpx.MockTransport(handler))

    # Stub the CLI refresh to mint a fresh token without hitting az.
    def _fake_refresh() -> bool:
        provider._set_bearer("fresh-token")
        return True

    provider._refresh_bearer_token = _fake_refresh  # type: ignore[method-assign]
    out = await provider.chat(_chat_request(), "dmt-brain")
    assert out.choices[0].message.content == "ok"
    assert calls[0] == "Bearer expired-token"
    assert calls[1] == "Bearer fresh-token"


def test_refresh_mints_via_managed_identity(monkeypatch) -> None:  # noqa: ANN001
    # On an Azure host the token is minted via DefaultAzureCredential (no CLI).
    provider = _bearer_provider(httpx.MockTransport(lambda r: httpx.Response(200, json={})))
    monkeypatch.setattr(provider, "_mint_via_azure_identity", lambda: "mi-token")
    assert provider._refresh_bearer_token() is True
    assert provider._headers["Authorization"] == "Bearer mi-token"


def test_refresh_returns_false_without_identity_or_cli(monkeypatch) -> None:  # noqa: ANN001
    # No managed identity and no az CLI -> fail closed (no silent token).
    provider = _bearer_provider(httpx.MockTransport(lambda r: httpx.Response(200, json={})))
    monkeypatch.setattr(provider, "_mint_via_azure_identity", lambda: "")
    monkeypatch.setattr("shutil.which", lambda _name: None)
    assert provider._refresh_bearer_token() is False


async def test_chat_uses_native_deployment_path_and_api_key() -> None:
    recorded: dict = {}
    provider = _provider(_ok_transport(recorded))
    out = await provider.chat(_chat_request(), "dmt-brain")
    # Native Azure path: /openai/deployments/{dep}/chat/completions?api-version=...
    assert "/openai/deployments/dmt-brain/chat/completions" in recorded["url"]
    assert "api-version=2024-10-21" in recorded["url"]
    # api-key auth, never Bearer.
    assert recorded["api_key"] == "test-key"
    assert recorded["authorization"] is None
    assert out.choices[0].message.content == "grounded answer"
    assert out.usage.total_tokens == 7


async def test_embeddings_native_path() -> None:
    recorded: dict = {}
    provider = _provider(_ok_transport(recorded))
    out = await provider.embeddings(EmbeddingRequest(model="dmt-embed", input="text"), "dmt-embed")
    assert "/openai/deployments/dmt-embed/embeddings" in recorded["url"]
    assert out.data[0].embedding == [0.1, 0.2]


def test_requires_https() -> None:
    with pytest.raises(ValueError, match="https"):
        AzureOpenAIProvider(endpoint="http://x", api_key="k")


async def test_4xx_is_rejected_not_retried() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"error": {"message": "bad key"}})

    provider = _provider(httpx.MockTransport(handler))
    with pytest.raises(UpstreamRejectedError):
        await provider.chat(_chat_request(), "dmt-brain")


def test_factory_builds_azure_when_kind_azure() -> None:
    from app.main import _build_provider
    from app.settings import Settings

    azure = _build_provider(
        Settings(
            _env_file=None,
            upstream_base_url="https://dmt.cognitiveservices.azure.com",
            upstream_api_key="k",
            upstream_kind="azure",
        )
    )
    assert isinstance(azure, AzureOpenAIProvider)
    openai = _build_provider(
        Settings(
            _env_file=None,
            upstream_base_url="http://127.0.0.1:11434",
            upstream_kind="openai",
        )
    )
    from app.providers import OpenAICompatibleProvider

    assert isinstance(openai, OpenAICompatibleProvider)


def test_strip_reasoning_removes_think_blocks() -> None:
    from app.providers import _strip_reasoning

    assert _strip_reasoning("<think>reasoning</think>Answer.") == "Answer."
    assert _strip_reasoning("<think>truncated") == ""
    assert _strip_reasoning("clean") == "clean"


async def test_chat_strips_think_from_content() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": "x",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": "<think>t</think>Final."},
                        "finish_reason": "stop",
                    }
                ],
            },
        )

    provider = _provider(httpx.MockTransport(handler))
    out = await provider.chat(_chat_request(), "dmt-brain")
    assert out.choices[0].message.content == "Final."


async def test_bearer_token_auth_takes_precedence() -> None:
    recorded: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        recorded["authorization"] = request.headers.get("authorization")
        recorded["api_key"] = request.headers.get("api-key")
        return httpx.Response(
            200,
            json={
                "id": "x",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": "ok"},
                        "finish_reason": "stop",
                    }
                ],
            },
        )

    provider = AzureOpenAIProvider(
        endpoint="https://dmt.cognitiveservices.azure.com",
        bearer_token="entra-token",
        transport=httpx.MockTransport(handler),
    )
    await provider.chat(_chat_request(), "dmt-brain")
    assert recorded["authorization"] == "Bearer entra-token"
    assert recorded["api_key"] is None


def test_requires_exactly_one_auth() -> None:
    with pytest.raises(ValueError, match="exactly one"):
        AzureOpenAIProvider(endpoint="https://x", api_key="k", bearer_token="t")
    with pytest.raises(ValueError, match="exactly one"):
        AzureOpenAIProvider(endpoint="https://x")
