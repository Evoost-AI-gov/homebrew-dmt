"""Tests for the Entra ID bearer-token authentication path in require_api_key."""

from __future__ import annotations

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.security import _validate_entra_jwt
from app.settings import Settings

AUD = "api://22a5d74d-160b-4221-98c3-a14bf66522da"


def _make_key_pair():
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return private_key


def _settings(audience: str = AUD) -> Settings:
    return Settings(entra_audience=audience)


def _prod_settings(**overrides: object) -> Settings:
    """Production-mode Settings for the auth tests.

    The production validator requires allow_unauthenticated off, at least one
    API key, and an upstream base URL — provide all three so construction is
    environment-independent (the local dev env sets allow_unauthenticated=true,
    and CI provides no upstream), which is what made these tests flaky.
    """
    base = {
        "allow_unauthenticated": False,
        "api_keys": "k1",
        "upstream_base_url": "http://upstream.test",
    }
    return Settings(**{**base, **overrides})


class TestAcceptedAudiences:
    def test_expands_app_id_uri_to_include_bare_guid(self) -> None:
        from app.security import _accepted_audiences

        assert _accepted_audiences("api://abc-123") == ["api://abc-123", "abc-123"]

    def test_expands_bare_guid_to_include_app_id_uri(self) -> None:
        from app.security import _accepted_audiences

        assert _accepted_audiences("abc-123") == ["abc-123", "api://abc-123"]


class TestEntraValidationGuards:
    def test_no_audience_configured_returns_none(self) -> None:
        # Entra not configured -> always fall through to the API key.
        assert _validate_entra_jwt("any.token.here", Settings()) is None

    def test_malformed_token_returns_none(self) -> None:
        assert _validate_entra_jwt("not-a-jwt", _settings()) is None

    def test_non_microsoft_issuer_returns_none(self) -> None:
        token = jwt.encode(
            {"iss": "https://issuer.example.com/", "aud": AUD, "exp": 9_999_999_999},
            "secret",
            algorithm="HS256",
        )
        assert _validate_entra_jwt(token, _settings()) is None

    def test_unsigned_or_garbage_segment_returns_none(self) -> None:
        # A syntactically-plausible token that cannot be verified -> None, never raise.
        assert _validate_entra_jwt("a.b.c", _settings()) is None


class TestRequireApiKeyWithEntra:
    """require_api_key must accept a valid Entra bearer OR a valid API key."""

    def _app(self, settings: Settings) -> FastAPI:
        from app.errors import AppError, app_error_handler
        from app.security import require_api_key

        app = FastAPI()
        app.state.settings = settings
        # The real app maps AppError (incl. UnauthorizedError) to a 401/4xx JSON
        # response; register the same handler so the dependency can raise it.
        app.add_exception_handler(AppError, app_error_handler)

        @app.get("/whoami")
        def whoami(identity: str = pytest.importorskip("fastapi").Depends(require_api_key)):
            return {"identity": identity}

        return app

    def test_api_key_still_works(self) -> None:
        settings = _prod_settings(api_keys="k1", entra_audience=AUD, app_env="production")
        client = TestClient(self._app(settings))
        resp = client.get("/whoami", headers={"X-API-Key": "k1"})
        assert resp.status_code == 200

    def test_invalid_bearer_falls_through_to_401(self) -> None:
        settings = _prod_settings(api_keys="k1", entra_audience=AUD, app_env="production")
        client = TestClient(self._app(settings))
        resp = client.get("/whoami", headers={"Authorization": "Bearer garbage.token.here"})
        assert resp.status_code == 401

    def test_no_credentials_401(self) -> None:
        settings = _prod_settings(api_keys="k1", entra_audience=AUD, app_env="production")
        client = TestClient(self._app(settings))
        assert client.get("/whoami").status_code == 401


class TestGoogleSignIn:
    def test_google_issuer_rejected_when_not_configured(self) -> None:
        # google_client_id empty -> a Google id_token is not accepted.
        token = jwt.encode(
            {
                "iss": "https://accounts.google.com",
                "aud": "some-client.apps.googleusercontent.com",
                "sub": "123",
                "exp": 9_999_999_999,
            },
            "secret",
            algorithm="HS256",
        )
        assert _validate_entra_jwt(token, Settings()) is None

    def test_unknown_issuer_returns_none(self) -> None:
        token = jwt.encode(
            {"iss": "https://evil.example.com", "aud": AUD, "exp": 9_999_999_999},
            "secret",
            algorithm="HS256",
        )
        assert _validate_entra_jwt(token, _prod_settings(entra_audience=AUD)) is None
