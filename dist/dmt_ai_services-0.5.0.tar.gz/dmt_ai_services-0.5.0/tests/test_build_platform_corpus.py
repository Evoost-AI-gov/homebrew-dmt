"""Tests for the DMT platform-knowledge corpus builder.

These run hermetically: the workspace root and corpus paths are pointed at a
``tmp_path`` fixture so no real workspace document or the live corpus is ever
touched. They pin the governance-relevant behaviours — provenance/tier tagging,
the fail-closed secret and size guards, the malformed-JSON guard, and the
idempotent merge that must never drop other domains' chunks.
"""

from __future__ import annotations

import json
from pathlib import Path

import ml.retrieval.build_platform_corpus as bpc
import pytest

_MD = "# Heading\n\n" + ("Some governed platform text. " * 20) + "\n"


@pytest.fixture()
def platform_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect the builder's workspace + corpus paths at a temp workspace."""
    workspace = tmp_path / "ws"
    corpus = tmp_path / "corpus"
    corpus.mkdir()
    (workspace / "_docs").mkdir(parents=True)
    (workspace / "_docs" / "ARCHITECTURE.md").write_text(_MD, encoding="utf-8")
    monkeypatch.setattr(bpc, "WORKSPACE_ROOT", workspace)
    monkeypatch.setattr(bpc, "CHUNKS_PATH", corpus / "retrieval_chunks.jsonl")
    monkeypatch.setattr(bpc, "MANIFEST_PATH", corpus / "platform_corpus_manifest.json")
    monkeypatch.setattr(
        bpc,
        "_GLOBS",
        (("platform_architecture", "architecture", "_docs/ARCHITECTURE.md"),),
    )
    return workspace


def _build() -> dict:
    return bpc.build()


def test_produces_chunks_with_provenance(platform_env: Path) -> None:
    manifest = _build()
    assert manifest["platform_chunks"] >= 1
    assert manifest["documents"][0]["domain"] == "platform_architecture"
    assert manifest["documents"][0]["tier"] == "authoritative"
    assert manifest["documents"][0]["license"] == "internal-first-party"
    chunks = [
        json.loads(line)
        for line in bpc.CHUNKS_PATH.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert all(c["chunk_id"].startswith("platform_architecture.md::chunk_") for c in chunks)
    assert all(c["tier"] == "authoritative" for c in chunks)
    assert all(c["source_files"] == ["_docs/ARCHITECTURE.md"] for c in chunks)
    assert all(len(c["sha256"]) == 64 for c in chunks)


def test_secret_content_is_skipped_fail_closed(platform_env: Path) -> None:
    (platform_env / "_docs" / "ARCHITECTURE.md").write_text(
        _MD + "\napi_key = sk_live_4eC39HqLyjWDarjtT1zdp7dc\n", encoding="utf-8"
    )
    manifest = _build()
    assert manifest["platform_chunks"] == 0
    assert manifest["skipped_files_fail_closed"] == ["_docs/ARCHITECTURE.md"]


def test_oversized_source_is_skipped_fail_closed(platform_env: Path, monkeypatch) -> None:
    monkeypatch.setattr(bpc, "MAX_SOURCE_BYTES", 10)
    manifest = _build()
    assert manifest["platform_chunks"] == 0
    assert manifest["skipped_files_fail_closed"] == ["_docs/ARCHITECTURE.md"]


def test_per_source_tier_override(platform_env: Path, monkeypatch) -> None:
    (platform_env / "_docs" / "std.md").write_text(_MD, encoding="utf-8")
    monkeypatch.setattr(
        bpc,
        "_GLOBS",
        (
            ("platform_architecture", "architecture", "_docs/ARCHITECTURE.md"),
            ("ai_governance_reference", "ai_standard", "_docs/std.md", "reference"),
        ),
    )
    manifest = _build()
    tiers = {d["domain"]: d["tier"] for d in manifest["documents"]}
    assert tiers["platform_architecture"] == "authoritative"
    assert tiers["ai_governance_reference"] == "reference"


def test_malformed_json_is_skipped_fail_closed(platform_env: Path, monkeypatch) -> None:
    (platform_env / "_docs" / "bad.json").write_text("{ not json", encoding="utf-8")
    monkeypatch.setattr(bpc, "_GLOBS", (("platform_services", "data_layers", "_docs/bad.json"),))
    manifest = _build()
    assert manifest["skipped_files_fail_closed"] == ["_docs/bad.json"]


def test_idempotent_merge_preserves_other_domains(platform_env: Path) -> None:
    foreign = {
        "chunk_id": "foreign.md::chunk_0000",
        "canonical_file": "foreign.md",
        "domain": "regulation",
        "tier": "authoritative",
        "source_files": ["x"],
        "text": "foreign",
        "char_count": 7,
        "sha256": "0" * 64,
    }
    bpc.CHUNKS_PATH.write_text(json.dumps(foreign) + "\n", encoding="utf-8")
    _build()
    first_total = manifest_total()
    _build()  # second run must not duplicate or drop the foreign chunk
    second_total = manifest_total()
    assert first_total == second_total
    ids = [
        json.loads(line)["chunk_id"]
        for line in bpc.CHUNKS_PATH.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert ids.count("foreign.md::chunk_0000") == 1
    assert len(ids) == len(set(ids))


def manifest_total() -> int:
    return json.loads(bpc.MANIFEST_PATH.read_text(encoding="utf-8"))["corpus_chunks_total"]


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("token sk_live_4eC39HqLyjWDarjtT1zdp7dc here", True),
        ("key sk_test_51HqLyjWDarjtT1zdp7dc ok", True),
        ("api key sk-A3f9xK2mP7qR4t8W1yZ5 seen", True),
        ("see risk-management-framework section", False),
        ("the sk-analysis and sk-completion tokens", False),
        ("password: supersecretvalue", True),
        ("plain prose with no secrets", False),
    ],
)
def test_secret_detection_matrix(text: str, expected: bool) -> None:
    assert bool(bpc._SECRET_PATTERNS.search(text)) is expected
