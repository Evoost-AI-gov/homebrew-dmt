"""Tests for external-capture agents (F5): allowlist, tagging, confidence cap."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from app.council.external import EXTERNAL_TIER, ExternalCapture
from app.council.registry import CouncilRegistry
from app.council.schemas import CouncilChatMessage, CouncilChatRequest, CouncilMessage
from app.council.service import CouncilService
from app.errors import InvalidRequestError
from app.main import create_app
from app.settings import Settings

AUTH = {"X-API-Key": "test-key"}

_DIRECTOR_MD = """---
name: Director (Program Orchestrator)
description: "Routes and synthesizes."
tools: [read, search, agent]
---

# Director

You are the Director.
"""


# --- ExternalCapture (unit) ---------------------------------------------------


def test_capture_disabled_without_allowlist() -> None:
    assert not ExternalCapture(frozenset()).configured


def test_capture_blocks_non_allowlisted_host() -> None:
    capture = ExternalCapture(frozenset({"example.com"}))
    with pytest.raises(InvalidRequestError, match="allowlist"):
        capture._check_url("https://evil.com/story")


def test_capture_blocks_non_https() -> None:
    capture = ExternalCapture(frozenset({"example.com"}))
    with pytest.raises(InvalidRequestError, match="https"):
        capture._check_url("http://example.com/story")


def test_capture_allows_subdomain_of_allowlisted() -> None:
    capture = ExternalCapture(frozenset({"example.com"}))
    assert capture._check_url("https://news.example.com/a") == "news.example.com"


async def test_capture_fetch_tags_external_unverified() -> None:
    capture = ExternalCapture(frozenset({"example.com"}))

    # Stub the network: intercept httpx via a transport-less fake.
    import httpx

    class _FakeResponse:
        content = b"market news excerpt"

        def raise_for_status(self) -> None:
            return None

    class _FakeClient:
        def __init__(self, *a, **k):  # noqa: ANN002, ANN003
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *a):  # noqa: ANN002
            return False

        async def get(self, url, follow_redirects=True):  # noqa: ANN001, ANN201
            return _FakeResponse()

    original = httpx.AsyncClient
    httpx.AsyncClient = _FakeClient  # type: ignore[assignment]
    try:
        result = await capture.fetch("https://example.com/story")
    finally:
        httpx.AsyncClient = original  # type: ignore[assignment]
    assert result["tier"] == EXTERNAL_TIER
    assert result["url"] == "https://example.com/story"
    assert "market news" in result["excerpt"]


# --- Synthesis confidence cap on external sources -----------------------------


async def test_synthesis_caps_confidence_when_external_used(tmp_path) -> None:  # noqa: ANN001
    (tmp_path / "director.agent.md").write_text(_DIRECTOR_MD, encoding="utf-8")
    registry = CouncilRegistry.from_directory(tmp_path)

    from app.inference import InferenceService
    from app.routing import Router

    class FakeProvider:
        async def chat(self, request, model):  # noqa: ANN001, ANN202
            from app.schemas import ChatChoice, ChatChoiceMessage, ChatCompletionResponse, Usage

            return ChatCompletionResponse(
                id="x",
                model=model,
                choices=[
                    ChatChoice(
                        index=0,
                        message=ChatChoiceMessage(role="assistant", content="Synth."),
                        finish_reason="stop",
                    )
                ],
                usage=Usage(prompt_tokens=1, completion_tokens=1, total_tokens=2),
            )

        async def embeddings(self, request, model):  # noqa: ANN001, ANN202
            raise NotImplementedError

    service = CouncilService(
        registry=registry,
        inference=InferenceService(FakeProvider(), Router()),
        retrieval=None,
        require_grounding=False,
    )
    contributions = [
        CouncilMessage(
            agent_id="external-scout",
            content="External market note.",
            sources=["https://example.com/news"],
            confidence="high",  # even a "high" external source must be capped
            abstained=False,
        )
    ]
    synthesis = await service._synthesize(
        CouncilChatRequest(
            agents=[],
            messages=[CouncilChatMessage(role="user", content="external news?")],
            stream=False,
        ),
        contributions,
        [],
    )
    assert synthesis.confidence == "low"  # external content never exceeds low


# --- Endpoint ------------------------------------------------------------------


def test_external_endpoint_disabled_without_allowlist(tmp_path) -> None:  # noqa: ANN001
    (tmp_path / "agents").mkdir()
    (tmp_path / "agents" / "director.agent.md").write_text(_DIRECTOR_MD, encoding="utf-8")
    settings = Settings(
        _env_file=None,
        app_env="development",
        api_keys="test-key",
        allow_unauthenticated=False,
        council_agents_dir=str(tmp_path / "agents"),
    )
    client = TestClient(create_app(settings=settings))
    resp = client.post(
        "/v1/council/external/fetch", headers=AUTH, json={"url": "https://example.com/x"}
    )
    assert resp.status_code == 400  # external capture not configured
