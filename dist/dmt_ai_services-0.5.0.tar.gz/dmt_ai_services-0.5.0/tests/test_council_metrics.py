"""Tests for the council per-turn metrics log + per-expert KPI aggregation."""

from __future__ import annotations

from types import SimpleNamespace

from app.council.metrics import CouncilMetricsStore


def _msg(agent_id: str, *, sources=(), abstained=False, confidence="low"):
    return SimpleNamespace(
        agent_id=agent_id, sources=list(sources), abstained=abstained, confidence=confidence
    )


def _response(messages, *, participants=None, synthesis_conf="low", veto=None, tokens=100):
    return SimpleNamespace(
        id="t",
        messages=messages,
        meta=SimpleNamespace(participants=participants or [], total_tokens=tokens),
        synthesis=SimpleNamespace(confidence=synthesis_conf) if synthesis_conf else None,
        veto=SimpleNamespace(gate=veto) if veto else None,
    )


def _roster():
    return [
        SimpleNamespace(agent_id="valuation", display_name="Valuation", kind="expert"),
        SimpleNamespace(agent_id="market", display_name="Market", kind="expert"),
        SimpleNamespace(agent_id="director", display_name="Director", kind="director"),
    ]


class TestCouncilMetricsStore:
    def test_empty_store_is_unavailable(self, tmp_path) -> None:
        store = CouncilMetricsStore(tmp_path / "m.jsonl")
        agg = store.aggregate(_roster())
        assert agg["available"] is False
        assert agg["council"]["total_turns"] == 0

    def test_records_and_aggregates_per_expert_kpis(self, tmp_path) -> None:
        store = CouncilMetricsStore(tmp_path / "m.jsonl")
        # Turn 1: valuation confirms with evidence; market abstains.
        store.record(
            _response(
                [
                    _msg("valuation", sources=["rate_table@1"], confidence="medium"),
                    _msg("market", abstained=True, confidence=None),
                ],
                participants=["valuation", "market", "director"],
            )
        )
        # Turn 2: valuation confirms again; market speaks (no evidence, not abstained).
        store.record(
            _response(
                [
                    _msg("valuation", sources=["command_center_brief@x"], confidence="low"),
                    _msg("market", sources=[], confidence="low"),
                ],
                participants=["valuation", "market", "director"],
            )
        )
        agg = store.aggregate(_roster())
        assert agg["available"] is True
        assert agg["council"]["total_turns"] == 2
        # Experts are sorted by interventions (both spoke twice here).
        by_id = {e["agent_id"]: e for e in agg["experts"]}
        assert "director" not in by_id  # experts only
        val = by_id["valuation"]
        assert val["interventions"] == 2
        assert val["participation_pct"] == 100.0
        assert val["confirmation_pct"] == 100.0  # grounded + not abstained both turns
        assert val["abstention_pct"] == 0.0
        mkt = by_id["market"]
        assert mkt["interventions"] == 2
        assert mkt["abstention_pct"] == 50.0  # abstained once of two
        assert mkt["confirmation_pct"] == 0.0  # never grounded-and-confirmed

    def test_veto_turn_is_counted(self, tmp_path) -> None:
        store = CouncilMetricsStore(tmp_path / "m.jsonl")
        store.record(_response([], synthesis_conf=None, veto="compliance-data-governance"))
        agg = store.aggregate(_roster())
        assert agg["council"]["total_turns"] == 1
        assert agg["council"]["veto_count"] == 1

    def test_deliberation_counts_one_intervention_per_turn(self, tmp_path) -> None:
        # A deliberation round adds a second message for the same expert in one turn;
        # that is still a single participation, never >100% participation.
        store = CouncilMetricsStore(tmp_path / "m.jsonl")
        store.record(
            _response(
                [
                    _msg("valuation", sources=["rate_table@1"]),
                    _msg("valuation", sources=["rate_table@1"]),  # deliberation reaction
                ],
                participants=["valuation", "director"],
            )
        )
        agg = store.aggregate(_roster())
        val = next(e for e in agg["experts"] if e["agent_id"] == "valuation")
        assert val["interventions"] == 1
        assert val["participation_pct"] == 100.0
        assert agg["council"]["avg_experts_per_turn"] == 1.0
