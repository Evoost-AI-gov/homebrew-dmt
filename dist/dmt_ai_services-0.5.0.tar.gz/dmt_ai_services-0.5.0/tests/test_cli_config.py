"""CLI config resolution — precedence, profiles, validation."""

import pytest

from app.cli.config import ConfigError, resolve

_BASE_ENV = ("DMT_BASE_URL", "DMT_API_KEY", "DMT_ACCESS_TOKEN", "DMT_PROFILE", "DMT_MODEL")


@pytest.fixture(autouse=True)
def clean_env(monkeypatch, tmp_path):
    for name in _BASE_ENV:
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("DMT_CONFIG_DIR", str(tmp_path / "cfg"))
    monkeypatch.setenv("DMT_STATE_DIR", str(tmp_path / "state"))
    return tmp_path


def test_defaults():
    config = resolve()
    assert config.base_url == "http://127.0.0.1:8000"
    assert config.model == "dmt-brain"
    assert config.api_key is None
    assert config.auth_fingerprint == "none"


def test_profile_from_file(clean_env):
    cfg_dir = clean_env / "cfg"
    cfg_dir.mkdir(parents=True)
    (cfg_dir / "config.toml").write_text(
        '[profiles.demo]\nbase_url = "http://127.0.0.1:8001"\nmodel = "dmt-brain"\n'
    )
    config = resolve(profile="demo")
    assert config.base_url == "http://127.0.0.1:8001"
    assert config.profile == "demo"


def test_flag_beats_env_beats_profile(monkeypatch, clean_env):
    cfg_dir = clean_env / "cfg"
    cfg_dir.mkdir(parents=True)
    (cfg_dir / "config.toml").write_text('[profiles.p]\nbase_url = "http://file:1"\n')
    monkeypatch.setenv("DMT_BASE_URL", "http://env:2")
    assert resolve(profile="p").base_url == "http://env:2"
    assert resolve(profile="p", base_url="http://flag:3").base_url == "http://flag:3"


def test_unknown_profile_raises():
    # No config file at all + an explicit profile name = a config error.
    with pytest.raises(ConfigError, match="cannot load profile"):
        resolve(profile="nope")


def test_profile_missing_from_existing_file_raises(clean_env):
    cfg_dir = clean_env / "cfg"
    cfg_dir.mkdir(parents=True)
    (cfg_dir / "config.toml").write_text('[profiles.demo]\nbase_url = "http://x:1"\n')
    with pytest.raises(ConfigError, match="unknown profile"):
        resolve(profile="nope")
    # The defined profile still resolves.
    assert resolve(profile="demo").base_url == "http://x:1"


def test_trailing_slash_stripped():
    assert resolve(base_url="http://x:1/").base_url == "http://x:1"


def test_bad_url_rejected():
    with pytest.raises(ConfigError, match="http"):
        resolve(base_url="ftp://nope")


def test_no_color_env(monkeypatch):
    monkeypatch.setenv("NO_COLOR", "1")
    assert resolve().color is False
    assert resolve(color=True).color is True  # explicit flag wins


def test_api_key_fingerprint_is_not_the_secret():
    config = resolve(api_key="test-secret-key")
    fp = config.auth_fingerprint
    assert fp != "none"
    assert "test-secret-key" not in fp
    assert len(fp) == 16
