"""Tests for the Semantica-backed Personal Graph service + routes."""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.council.graph_service import PersonalGraphService


class TestPersonalGraphService:
    def test_record_activity_grows_graph(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        out = svc.record_activity("user:1", "viewed", "Mussafah M-1", "M-1", "map")
        assert "M-1" in out["nodes"]
        assert out["nodes"]["M-1"]["kind"] == "parcel"

    def test_module_edge_links_entity_to_module(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        out = svc.record_activity("user:1", "viewed", "Mixed-use A", "S-2", "scenarios")
        assert "module:scenarios" in out["nodes"]
        assert any("->in->module:scenarios" in k for k in out["edges"])

    def test_users_are_isolated(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        svc.record_activity("user:1", "viewed", "A", "A", "map")
        assert svc.to_frontend("user:2")["nodes"] == {}

    def test_persistence_across_instances(self, tmp_path) -> None:
        p = tmp_path / "g.json"
        PersonalGraphService(p).record_activity("user:1", "viewed", "A", "A", "map")
        assert "A" in PersonalGraphService(p).to_frontend("user:1")["nodes"]

    def test_record_decision_is_auditable(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        decision_id = svc.record_decision(
            "user:1", "release", "Mussafah first release", "demand signal", "shortlist", 0.8
        )
        assert decision_id


class TestPersonalGraphRoutes:
    def _app(self, tmp_path) -> FastAPI:
        from app.council.graph_routes import router
        from app.errors import AppError, app_error_handler

        app = FastAPI()
        app.state.settings = __import__("app.settings", fromlist=["Settings"]).Settings()
        app.state.graph_service = PersonalGraphService(tmp_path / "g.json")
        app.add_exception_handler(AppError, app_error_handler)
        app.include_router(router, prefix="/v1")
        return app

    def test_get_empty_graph(self, tmp_path) -> None:
        resp = TestClient(self._app(tmp_path)).get("/v1/me/graph")
        assert resp.status_code == 200
        assert resp.json()["nodes"] == {}

    def test_record_and_read_back(self, tmp_path) -> None:
        client = TestClient(self._app(tmp_path))
        r = client.post(
            "/v1/me/graph/activity",
            json={"kind": "viewed", "label": "Mussafah M-1", "ref": "M-1", "module": "map"},
        )
        assert r.status_code == 200
        assert "M-1" in client.get("/v1/me/graph").json()["nodes"]

    def test_record_decision(self, tmp_path) -> None:
        client = TestClient(self._app(tmp_path))
        r = client.post(
            "/v1/me/graph/decision",
            json={
                "category": "release",
                "scenario": "Mussafah",
                "reasoning": "demand",
                "outcome": "shortlist",
                "confidence": 0.8,
            },
        )
        assert r.status_code == 201
        assert r.json()["decision_id"]


class TestGraphIntelligence:
    def test_insights_ranks_hubs(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        svc.record_activity("u", "viewed", "Mussafah M-1", "M-1", "map")
        svc.record_activity("u", "compared", "Mixed-use A", "S-2", "scenarios")
        svc.record_activity("u", "viewed", "Mussafah M-2", "M-2", "map")
        out = svc.insights("u")
        assert out["node_count"] >= 4
        assert out["hubs"] and out["hubs"][0]["label"]  # most-connected first

    def test_trace_decision_returns_the_id(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        d = svc.record_decision("u", "release", "Mussafah", "demand", "shortlist", 0.8)
        assert svc.trace_decision("u", d)["decision_id"] == d

    def test_similar_decisions_returns_a_list(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        svc.record_decision("u", "release", "Mussafah", "demand", "shortlist", 0.8)
        assert isinstance(svc.similar_decisions("u", "release"), list)

    def test_insights_on_empty_graph(self, tmp_path) -> None:
        assert PersonalGraphService(tmp_path / "g.json").insights("u")["hubs"] == []


class TestGraphFullSurface:
    def test_insights_breaks_down_kinds_and_cluster(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        svc.record_activity("u", "viewed", "M-1", "M-1", "map")
        svc.record_activity("u", "viewed", "M-2", "M-2", "map")
        svc.record_activity("u", "compared", "S-A", "S-A", "scenarios")
        ins = svc.insights("u")
        assert ins["kinds"].get("parcel") == 2
        assert ins["largest_cluster"] >= 2
        assert ins["hubs"]

    def test_explore_node_returns_neighbours(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        svc.record_activity("u", "viewed", "M-1", "M-1", "map")
        out = svc.explore_node("u", "M-1", hops=2)
        assert out["node"]["label"] == "M-1"
        assert any(n["label"] == "map" for n in out["neighbors"])

    def test_explore_unknown_node_is_safe(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        assert svc.explore_node("u", "nope")["node"] is None


class TestChunkLevelEvidence:
    def test_decision_links_to_the_exact_chunk(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        svc.record_decision(
            "u",
            "council-turn",
            "Price for Mussafah commercial?",
            "Valuation",
            "median 314 AED/sqm",
            0.85,
            evidence=[
                {
                    "source": "deal_rate.md::chunk_0003",
                    "label": "deal_rate.md",
                    "confidence": "authoritative",
                }
            ],
        )
        out = svc.to_frontend("u")
        ev = [n for n in out["nodes"].values() if n["kind"] == "evidence"]
        assert ev and any("chunk_0003" in n["id"] for n in ev)


class TestTemporal:
    def test_activity_stamps_valid_from(self, tmp_path) -> None:
        import json

        p = tmp_path / "g.json"
        svc = PersonalGraphService(p)
        svc.record_activity("u", "viewed", "Mussafah M-1", "M-1", "map")
        raw = json.loads(p.read_text())
        node = [n for n in raw["u"]["nodes"] if n["id"] == "M-1"][0]
        assert node.get("valid_from")
