"""Tests for the temporal model (point-in-time) and the pricing conflict surface."""

from __future__ import annotations

import json

from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.council.graph_service import PersonalGraphService
from app.council.tools import PricingTool


class TestTemporalSnapshot:
    def test_point_in_time_filters_by_validity(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        svc.record_activity("u", "viewed", "Mussafah M-1", "P-1", "parcels")
        # The entity exists now but not in the past.
        assert svc.snapshot("u", "2099-01-01T00:00:00+00:00")["node_count"] >= 2
        assert svc.snapshot("u", "2020-01-01T00:00:00+00:00")["node_count"] == 0

    def test_snapshot_keeps_only_edges_with_live_endpoints(self, tmp_path) -> None:
        svc = PersonalGraphService(tmp_path / "g.json")
        svc.record_activity("u", "viewed", "Mussafah M-1", "P-1", "parcels")
        snap = svc.snapshot("u", "2099-01-01T00:00:00+00:00")
        live = {n["id"] for n in snap["nodes"]}
        assert all(e["source"] in live and e["target"] in live for e in snap["edges"])


class TestTemporalRoute:
    def _app(self, tmp_path) -> FastAPI:
        from app.council.graph_routes import router
        from app.errors import AppError, app_error_handler

        app = FastAPI()
        app.state.settings = __import__("app.settings", fromlist=["Settings"]).Settings()
        app.state.graph_service = PersonalGraphService(tmp_path / "g.json")
        app.add_exception_handler(AppError, app_error_handler)
        app.include_router(router, prefix="/v1")
        return app

    def test_as_of_returns_point_in_time_snapshot(self, tmp_path) -> None:
        client = TestClient(self._app(tmp_path))
        client.post(
            "/v1/me/graph/activity",
            json={"kind": "viewed", "label": "M-1", "ref": "M-1", "module": "map"},
        )
        future = client.get("/v1/me/graph", params={"as_of": "2099-01-01T00:00:00Z"})
        past = client.get("/v1/me/graph", params={"as_of": "2020-01-01T00:00:00Z"})
        assert future.status_code == 200 and future.json()["node_count"] >= 1
        assert past.status_code == 200 and past.json()["node_count"] == 0


def _rate_table(tmp_path, divergent: bool) -> str:
    """A minimal governed rate table; divergent adds a contradicting district band."""
    table = {
        "provenance": {"min_deals_per_band": 1},
        "groups": {
            "category": {
                "residential": {"n": 10, "rent_aed_sqm": {"p50": 100}, "confidence": "high"}
            },
            "district_category": {
                "mussafah|residential": {"n": 5, "rent_aed_sqm": {"p50": 200 if divergent else 105}}
            },
        },
    }
    path = tmp_path / "rate_table.json"
    path.write_text(json.dumps(table))
    return str(path)


class TestPricingConflicts:
    def test_detects_a_divergent_band(self, tmp_path) -> None:
        tool = PricingTool(_rate_table(tmp_path, divergent=True))
        conflicts = tool.conflicts()
        assert len(conflicts) == 1
        assert conflicts[0]["district"] == "mussafah"
        assert conflicts[0]["divergence"] > 0.6

    def test_no_conflict_when_consistent(self, tmp_path) -> None:
        tool = PricingTool(_rate_table(tmp_path, divergent=False))
        assert tool.conflicts() == []

    def test_conflicts_endpoint_flags_divergence(self, tmp_path) -> None:
        from app.council.pricing_routes import router

        app = FastAPI()
        app.state.pricing_tool = PricingTool(_rate_table(tmp_path, divergent=True))
        app.include_router(router, prefix="/v1")
        resp = TestClient(app).get("/v1/pricing/conflicts")
        assert resp.status_code == 200
        body = resp.json()
        assert body["configured"] is True
        assert body["count"] == 1

    def test_conflicts_endpoint_unconfigured(self, tmp_path) -> None:
        from app.council.pricing_routes import router

        app = FastAPI()
        app.state.pricing_tool = None
        app.include_router(router, prefix="/v1")
        resp = TestClient(app).get("/v1/pricing/conflicts")
        assert resp.status_code == 200
        assert resp.json() == {"configured": False, "conflicts": []}


class TestCouncilCoverage:
    def _service(self, tmp_path, pricing: PricingTool | None):  # noqa: ANN202
        from app.council.registry import CouncilRegistry
        from app.council.service import CouncilService

        return CouncilService(
            registry=CouncilRegistry.from_directory(""),
            inference=None,  # type: ignore[arg-type]
            retrieval=None,
            pricing=pricing,
        )

    def test_coverage_lists_domains_and_conflicts(self, tmp_path) -> None:
        svc = self._service(tmp_path, PricingTool(_rate_table(tmp_path, divergent=True)))
        cov = svc.coverage()
        assert cov["domain_count"] > 0
        assert cov["pricing_grounded"] is True
        assert cov["pricing_conflicts"][0]["district"] == "mussafah"
        # Every domain lists its owning experts; the pricing domain is grounded.
        pricing_domain = next(d for d in cov["domains"] if "price" in d["keywords"])
        assert pricing_domain["grounding"] == "governed"
        assert pricing_domain["confidence"] == "high"
        assert all("experts" in d for d in cov["domains"])

    def test_coverage_ungrounded_without_pricing(self, tmp_path) -> None:
        svc = self._service(tmp_path, None)
        cov = svc.coverage()
        assert cov["pricing_grounded"] is False
        assert cov["pricing_conflicts"] == []
        pricing_domain = next(d for d in cov["domains"] if "price" in d["keywords"])
        assert pricing_domain["grounding"] == "retrieval"
