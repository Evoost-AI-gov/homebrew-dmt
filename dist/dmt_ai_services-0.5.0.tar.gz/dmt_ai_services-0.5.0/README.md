# dmt-ai-services

AI inference gateway for the DMT Land Intelligence Platform — an
OpenAI-compatible FastAPI front door to the sovereign model server
(Ollama / vLLM / TGI on AKS). It applies DMT's governance controls
(authentication, rate limiting, routing with fallback, grounding/abstention and
prompt-injection screening) in front of the model, so every surface calls one
governed, auditable endpoint.

Part of the DMT polyrepo. Owned by `@Evoost-AI-gov/ai-brain`.

- `app/` — the online inference gateway (this document).
- `ml/` — the offline AI/ML pipeline (retrieval/RAG corpus + LoRA training). See
  [`ml/README.md`](ml/README.md).

## Requirements

- Python 3.13

## Getting started

```bash
cp .env.example .env
pip install -e ".[dev]"
uvicorn app.main:app --reload
```

Health check: `GET http://localhost:8000/health`

## API surface

All `/v1` routes require an `X-API-Key` header and are rate limited.

| Method & path | Purpose |
| ------------- | ------- |
| `GET /health` | Liveness probe |
| `GET /ready` | Readiness probe |
| `GET /v1/models` | List logical models the gateway can route to |
| `POST /v1/chat/completions` | OpenAI-compatible chat completion |
| `POST /v1/embeddings` | OpenAI-compatible embeddings |
| `POST /v1/retrieve` | Retrieve ranked, cited evidence from the governed corpus |
| `POST /v1/answer` | Retrieve evidence and answer only from it (or abstain) |

### Governance extensions

- **`require_grounding`** (chat request): when `true` and no retrieved context
  (a `tool` message) is present, the gateway **abstains** — it returns
  `abstained: true`, `grounded: false` and never calls the model. This is the
  online half of the hallucination-control strategy.
- **Online retrieval (RAG)**: `POST /v1/retrieve` embeds the query with the same
  model used to build the index, searches the **tier-aware** corpus
  (`authoritative` | `reference` | `all`), and returns cited chunks above a score
  threshold — or an empty list (a retrieval abstention). `POST /v1/answer` chains
  retrieval → grounded answer: it injects the hits as untrusted `tool` context,
  answers only from them with citations, or **abstains** when nothing matches.
  Both are **fail-closed**: without an index + query embedder configured they
  return `503 retrieval_not_configured`. The offline index is built by
  [`ml/retrieval/`](ml/retrieval).
- **Routing with fallback**: a request names a *logical* model (e.g. `dmt-brain`,
  `general`, `fast`, `translate`, `embed`); the gateway resolves it to ordered
  concrete upstream tags and falls back to the next candidate on a genuine
  upstream failure (5xx / network) — never on a configuration error.
- **Prompt-injection screening**: `tool` (retrieved-context) messages are treated
  as untrusted data and screened; suspicious content is flagged in the logs.

## Security posture

- **Fail-closed configuration.** In `production` the app refuses to start unless
  authentication (`DMT_AI_API_KEYS`) and an upstream (`DMT_AI_UPSTREAM_BASE_URL`)
  are set and `DMT_AI_ALLOW_UNAUTHENTICATED` is false.
- **Constant-time API-key checks**; keys are never logged (only a short SHA-256
  key id is used for rate-limit accounting).
- **Hardened response headers** (`nosniff`, `frame-ancestors 'none'`, HSTS,
  restrictive CSP, `no-store`) on every response.
- **No bodies in logs.** Structured JSON access logs carry a request id, method,
  path, status and duration only; a `mask_pii` helper redacts any free-text.
- **Fail-closed upstream.** With no upstream configured, inference returns
  `503 upstream_not_configured` rather than guessing.

See [SECURITY.md](SECURITY.md) for the full model.

## Terminal client (`dmt` CLI)

An enterprise terminal client for the governed council chat — the same
conversation DMT can run in the web assistant, from a shell (claude/codex-style).
It talks **only** to the governed `/v1/council` + `/v1/chats` surface: same
roster, same veto gates, same confidence/abstention/evidence contract — so a
conversation moves between browser and terminal with no semantic change.

```bash
pip install -e ".[cli]"        # adds the `dmt` command (+ MSAL for Entra login)

dmt auth login                 # browser sign-in (Entra ID public client, PKCE)
dmt auth login --device-code   # headless: code at microsoft.com/devicelogin
dmt auth status                # who am I signed in as
dmt                            # interactive REPL
dmt ask "rent benchmark for commercial land in Mussafah?" --delegate
```

**Sign-in, not API keys.** `dmt auth login` acquires an Entra bearer token as a
public client (the gateway validates it exactly like the web SPA's tokens) and
caches it at `~/.config/dmt/msal_cache.json` (0600) with silent refresh.
Precedence: `--token`/`DMT_ACCESS_TOKEN` → cached Entra sign-in →
`--api-key`/`DMT_API_KEY` (service-to-service). The app registration needs
"Allow public client flows" + a `http://localhost` redirect (Mobile & desktop
platform); override with `DMT_ENTRA_CLIENT_ID` / `DMT_ENTRA_SCOPE` /
`DMT_ENTRA_AUTHORITY` for a dedicated CLI registration.

**Portability.** `/sync` pushes the transcript to the shared `/v1/chats` store
(the same one the web assistant syncs against); `/chats` + `/resume <id>` pull
any stored conversation into the terminal. Start in the CLI, continue in the
browser — or the reverse.

**Governance in the terminal.** Every turn shows per-agent confidence,
abstention and source counts; a governance veto renders as a banner and exits
**2** (0 ok, 1 error). Local JSONL transcripts (`~/.local/state/dmt/`, opt out
with `--no-transcript`) carry the conversation id + a non-reversible auth
fingerprint for correlation with gateway audit logs. `--json` emits NDJSON
events for scripting.

**Profiles & the demo VM.** Named profiles live in `~/.config/dmt/config.toml`
(no secrets in the file):

```toml
[profiles.demo]
base_url = "http://127.0.0.1:18001"   # ssh -L 18001:127.0.0.1:8001 <demo-vm>
```

then `dmt --profile demo`. REPL commands: `/agents /use /delegate /deliberate
/effort /new /sync /chats /resume /export /status /help /quit`.

## Quality gates

```bash
ruff check . && ruff format --check .
pytest --cov=app
```

CI runs the same gates on every PR (`.github/workflows/ci.yml`).
