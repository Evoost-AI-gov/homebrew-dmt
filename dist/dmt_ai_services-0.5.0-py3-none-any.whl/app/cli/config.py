"""CLI configuration resolution: defaults < profile file < environment < flags.

Profiles live in ``~/.config/dmt/config.toml`` (override with ``DMT_CONFIG_DIR``)::

    [profiles.demo]
    base_url = "http://127.0.0.1:8001"   # e.g. an SSH tunnel to the demo VM
    model = "dmt-brain"

Secrets are NEVER read from the file: API keys / bearer tokens come from the
environment (``DMT_API_KEY`` / ``DMT_ACCESS_TOKEN``) or flags only, so a profile
file can be committed or synced without leaking credentials.
"""

from __future__ import annotations

import hashlib
import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_BASE_URL = "http://127.0.0.1:8000"
DEFAULT_MODEL = "dmt-brain"
DEFAULT_TIMEOUT_S = 120.0

_ENV_BASE_URL = "DMT_BASE_URL"
_ENV_API_KEY = "DMT_API_KEY"
_ENV_ACCESS_TOKEN = "DMT_ACCESS_TOKEN"  # noqa: S105 — env var NAME, not a secret
_ENV_PROFILE = "DMT_PROFILE"
_ENV_MODEL = "DMT_MODEL"
_ENV_CONFIG_DIR = "DMT_CONFIG_DIR"
_ENV_STATE_DIR = "DMT_STATE_DIR"


@dataclass(frozen=True)
class CliConfig:
    """Resolved CLI settings. ``api_key_id``/``token_id`` are non-reversible
    fingerprints (matching the gateway's own key-id convention) so status output
    and transcripts never carry the secret."""

    base_url: str
    model: str = DEFAULT_MODEL
    api_key: str | None = field(default=None, repr=False)
    access_token: str | None = field(default=None, repr=False)
    profile: str = "default"
    timeout_s: float = DEFAULT_TIMEOUT_S
    color: bool = True
    transcript: bool = True
    state_dir: Path = Path.home() / ".local" / "state" / "dmt"

    @property
    def auth_fingerprint(self) -> str:
        """Short SHA-256 id of the configured credential, or 'none' (dev mode)."""
        secret = self.api_key or self.access_token
        if not secret:
            return "none"
        return hashlib.sha256(secret.encode()).hexdigest()[:16]


def config_dir() -> Path:
    override = os.environ.get(_ENV_CONFIG_DIR)
    return Path(override) if override else Path.home() / ".config" / "dmt"


def _load_profile(name: str) -> dict[str, str]:
    path = config_dir() / "config.toml"
    if not path.exists():
        if name != "default":
            raise ConfigError(f"no config file at {path} — cannot load profile '{name}'")
        return {}
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise ConfigError(f"cannot parse {path}: {exc}") from exc
    profiles = data.get("profiles", {})
    if name not in profiles:
        available = ", ".join(sorted(profiles)) or "(none defined)"
        raise ConfigError(f"unknown profile '{name}' in {path}; available: {available}")
    profile = profiles[name]
    return {k: v for k, v in profile.items() if isinstance(v, str)}


class ConfigError(Exception):
    """A configuration problem (bad profile, bad URL). Exit code 1."""


def resolve(
    *,
    base_url: str | None = None,
    model: str | None = None,
    api_key: str | None = None,
    access_token: str | None = None,
    profile: str | None = None,
    timeout_s: float | None = None,
    color: bool | None = None,
    transcript: bool | None = None,
) -> CliConfig:
    """Resolve the effective config. Precedence: flag > env > profile > default."""
    profile_name = profile or os.environ.get(_ENV_PROFILE) or "default"
    file_values = _load_profile(profile_name)

    resolved_url = base_url or os.environ.get(_ENV_BASE_URL) or file_values.get("base_url")
    resolved_model = model or os.environ.get(_ENV_MODEL) or file_values.get("model")
    resolved_key = api_key or os.environ.get(_ENV_API_KEY) or None
    resolved_token = access_token or os.environ.get(_ENV_ACCESS_TOKEN) or None

    url = (resolved_url or DEFAULT_BASE_URL).rstrip("/")
    if not url.startswith(("http://", "https://")):
        raise ConfigError(f"base URL must start with http:// or https:// (got '{url}')")

    state_override = os.environ.get(_ENV_STATE_DIR)
    no_color = os.environ.get("NO_COLOR") is not None
    return CliConfig(
        base_url=url,
        model=resolved_model or DEFAULT_MODEL,
        api_key=resolved_key,
        access_token=resolved_token,
        profile=profile_name,
        timeout_s=DEFAULT_TIMEOUT_S if timeout_s is None else timeout_s,
        color=(not no_color) if color is None else color,
        transcript=True if transcript is None else transcript,
        state_dir=Path(state_override) if state_override else CliConfig.state_dir,
    )
