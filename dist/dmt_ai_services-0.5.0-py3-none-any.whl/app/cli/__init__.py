"""DMT Council CLI — the enterprise terminal client for the governed council chat.

Talks to the same governed ``/v1/council`` surface as the web assistant, so a
conversation can move between the browser and the terminal without changing
semantics: same roster, same veto gates, same confidence/abstention contract.
"""

__version__ = "0.4.0"
