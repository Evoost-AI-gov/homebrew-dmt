"""API-key authentication and rate-limit enforcement dependencies.

Auth is service-to-service via the ``X-API-Key`` header. Keys are compared in
constant time and never logged; only a short, non-reversible key id derived via
SHA-256 is used for rate-limit accounting.
"""

from __future__ import annotations

import hashlib
import hmac

from fastapi import Request

from app.errors import RateLimitedError, UnauthorizedError
from app.settings import Settings


def _key_id(api_key: str) -> str:
    """Return a short, non-reversible identifier for an API key."""
    return hashlib.sha256(api_key.encode()).hexdigest()[:16]


def _matches(candidate: str, accepted: frozenset[str]) -> bool:
    """Constant-time membership test of ``candidate`` in ``accepted``."""
    result = False
    for key in accepted:
        if hmac.compare_digest(candidate, key):
            result = True
    return result


def _accepted_audiences(configured: str) -> list[str]:
    """Return both ``aud`` forms that name the configured resource app.

    Entra emits the token ``aud`` as either the App ID URI (``api://<id>``) or the
    bare client-id GUID depending on the API app's ``requestedAccessTokenVersion``;
    accepting both removes a config footgun without admitting any foreign audience.
    """
    audiences = [configured]
    if configured.startswith("api://"):
        bare = configured[len("api://") :]
        if bare:
            audiences.append(bare)
    elif configured:
        audiences.append(f"api://{configured}")
    return audiences


def require_api_key(request: Request) -> str:
    """Authenticate the caller and return its key id.

    In non-production environments with ``allow_unauthenticated`` enabled, the
    check is bypassed and a fixed dev identity is returned. Otherwise a valid
    ``X-API-Key`` header is required, OR a valid Entra ID bearer JWT (workforce
    sign-in) when Entra auth is configured.
    """
    settings: Settings = request.app.state.settings
    if settings.allow_unauthenticated and not settings.is_production:
        return "dev"
    # Workforce sign-in: a valid Entra ID bearer token identifies the user.
    bearer = request.headers.get("authorization", "")
    if bearer.startswith("Bearer "):
        user = _validate_entra_jwt(bearer[7:], settings)
        if user is not None:
            return user
    provided = request.headers.get("x-api-key", "")
    if not provided or not _matches(provided, settings.api_key_set):
        raise UnauthorizedError("missing or invalid API key")
    return _key_id(provided)


def _validate_entra_jwt(token: str, settings: Settings) -> str | None:
    """Validate a signed-in user's token (Entra ID or Google); return the user id.

    Entra: the app registration is multi-tenant, so the issuer tenant varies per
    user — we validate the signature against the token's own issuer tenant's keys
    (any Entra tenant accepted). Google: we validate the id_token against
    accounts.google.com's keys with the configured client id as audience.

    Only Microsoft's and Google's public signing keys are fetched (sovereign: no
    user data leaves the boundary; this is public-key signature verification).
    Returns None (fall through to API key) when unconfigured or invalid.
    """
    try:
        import jwt  # PyJWT[crypto]
        from jwt import PyJWKClient
    except ImportError:
        return None
    try:
        # Read the unverified claims only to route to the correct issuer's keys.
        unverified = jwt.decode(token, options={"verify_signature": False})
        iss = unverified.get("iss", "")

        if "login.microsoftonline.com" in iss:
            if not settings.entra_audience:
                return None
            oidc = f"{iss.rstrip('/')}/.well-known/openid-configuration"
            audience: str | list[str] = _accepted_audiences(settings.entra_audience)
        elif iss in ("https://accounts.google.com", "accounts.google.com"):
            if not settings.google_client_id:
                return None
            oidc = "https://accounts.google.com/.well-known/openid-configuration"
            audience = settings.google_client_id
        else:
            return None

        import json
        import urllib.request

        with urllib.request.urlopen(oidc, timeout=5) as resp:  # noqa: S310
            jwks_uri = json.load(resp)["jwks_uri"]
        signing_key = PyJWKClient(jwks_uri).get_signing_key_from_jwt(token).key
        claims = jwt.decode(
            token,
            signing_key,
            algorithms=["RS256"],
            audience=audience,
            options={"require": ["exp", "iss", "aud"]},
        )
        # Identity = stable per-user id (oid for Entra, sub for Google).
        return f"user:{claims.get('oid', claims.get('sub', 'unknown'))}"
    except Exception:  # noqa: BLE001
        return None


def enforce_rate_limit(request: Request) -> None:
    """Reject the request if the caller exceeded its per-minute quota."""
    settings: Settings = request.app.state.settings
    if not settings.rate_limit_enabled:
        return
    if settings.allow_unauthenticated and not settings.is_production:
        identity = "dev"
    else:
        provided = request.headers.get("x-api-key", "")
        identity = _key_id(provided) if provided else "anonymous"
    if not request.app.state.rate_limiter.allow(identity):
        raise RateLimitedError("rate limit exceeded")
